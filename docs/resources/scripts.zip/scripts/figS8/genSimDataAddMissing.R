##


dataset<-commandArgs()[4]

#noCompleteData<-as.numeric(commandArgs()[5])

#dataset<-"SIM1"

#path<-paste("C:/Users/nrajh/work/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,sep="")
#path<-paste("K:/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,sep="")
#setwd(path)

#noCompleteData<-68 # out of 280 - 212 in real data with missing

dataPath<-"/home/nrajh/code/bayesnetty/AlexClarkData/analyses/processed-data/"

dataset0<-"AC3" #"AC" "SV3"

tmet0<-read.table(paste(dataPath,dataset0,"/tmet-",dataset0,".dat",sep=""), header=TRUE)
texp0<-read.table(paste(dataPath,dataset0,"/texp-",dataset0,".dat",sep=""), header=TRUE)
bmet0<-read.table(paste(dataPath,dataset0,"/bmet-",dataset0,".dat",sep=""), header=TRUE)
bexp0<-read.table(paste(dataPath,dataset0,"/bexp-",dataset0,".dat",sep=""), header=TRUE)
info0<-read.table(paste(dataPath,dataset0,"/indivInfo-cts.dat",sep=""), header=TRUE)
snps0<-read.table(paste(dataPath,dataset0,"/snpDataFiltered-SNPs-cts.dat",sep=""), header=TRUE)

simData<-read.table(paste0("sim-data-",dataset,"-cts.dat"), header=TRUE)
simDataSNPs<-read.table(paste0("sim-data-",dataset,"-SNPs-cts.dat"), header=TRUE)

noIndivs<-dim(simData)[1]

tmet.new<-as.data.frame(matrix(0, nrow=noIndivs, ncol=dim(tmet0)[2]))
colnames(tmet.new)<-colnames(tmet0)
tmet.new[,1:2]<-1:noIndivs

texp.new<-as.data.frame(matrix(0, nrow=noIndivs, ncol=dim(texp0)[2]))
colnames(texp.new)<-colnames(texp0)
texp.new[,1:2]<-1:noIndivs

bmet.new<-as.data.frame(matrix(0, nrow=noIndivs, ncol=dim(bmet0)[2]))
colnames(bmet.new)<-colnames(bmet0)
bmet.new[,1:2]<-1:noIndivs

bexp.new<-as.data.frame(matrix(0, nrow=noIndivs, ncol=dim(bexp0)[2]))
colnames(bexp.new)<-colnames(bexp0)
bexp.new[,1:2]<-1:noIndivs

info.new<-as.data.frame(matrix(0, nrow=noIndivs, ncol=dim(info0)[2]))
colnames(info.new)<-colnames(info0)
info.new[,1:2]<-1:noIndivs

snps.new<-as.data.frame(matrix(0, nrow=noIndivs, ncol=dim(snps0)[2]))
colnames(snps.new)<-colnames(snps0)
snps.new[,1:2]<-1:noIndivs


#fill in columns for new sim'd data
for(i in 3:ncol(tmet.new))
{
 colName<-paste("t_",colnames(tmet.new)[i],sep="")
 colNum<-which(colName==colnames(simData))
 tmet.new[,i]<-simData[,colNum]
}

#fill in columns for new sim'd data
for(i in 3:ncol(texp.new))
{
 colName<-paste("t_",colnames(texp.new)[i],sep="")
 colNum<-which(colName==colnames(simData))
 texp.new[,i]<-simData[,colNum]
}

#fill in columns for new sim'd data
for(i in 3:ncol(bmet.new))
{
 colName<-paste("b_",colnames(bmet.new)[i],sep="")
 colNum<-which(colName==colnames(simData))
 bmet.new[,i]<-simData[,colNum]
}

#fill in columns for new sim'd data
for(i in 3:ncol(bexp.new))
{
 colName<-paste("b_",colnames(bexp.new)[i],sep="")
 colNum<-which(colName==colnames(simData))
 bexp.new[,i]<-simData[,colNum]
}

#fill in columns for new sim'd data
for(i in 3:ncol(info.new))
{
 colNum<-which(colnames(info.new)[i]==colnames(simData))
 info.new[,i]<-simData[,colNum]
}

#fill in columns for new sim'd data
for(i in 3:ncol(snps.new))
{
 colNum<-which(colnames(snps.new)[i]==colnames(simDataSNPs))
 if(length(colNum)>0) snps.new[,i]<-simDataSNPs[,colNum] else snps.new[,i]<-NA
}

##write full data
write.table(tmet.new, paste("tmet-",dataset,"-FULL.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(texp.new, paste("texp-",dataset,"-FULL.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(bmet.new, paste("bmet-",dataset,"-FULL.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(bexp.new, paste("bexp-",dataset,"-FULL.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(info.new, paste("indivInfo-",dataset,"-cts-FULL.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(snps.new, paste("snpDataFiltered-",dataset,"-SNPs-cts-FULL.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)

##add missing stuff
tmet.new[is.na(tmet0)]<-NA
texp.new[is.na(texp0)]<-NA
bmet.new[is.na(bmet0)]<-NA
bexp.new[is.na(bexp0)]<-NA
info.new[is.na(info0)]<-NA
snps.new[is.na(snps0)]<-NA



##write data
write.table(tmet.new, paste("tmet-",dataset,".dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(texp.new, paste("texp-",dataset,".dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(bmet.new, paste("bmet-",dataset,".dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(bexp.new, paste("bexp-",dataset,".dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(info.new, paste("indivInfo-",dataset,"-cts.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(snps.new, paste("snpDataFiltered-",dataset,"-SNPs-cts.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)

