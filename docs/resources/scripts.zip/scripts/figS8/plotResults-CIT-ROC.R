##

home<-1    # 0 = at work, 1 = at home, 2 = linux
png<-2

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path0<-"/home/nrajh/code/bayesnetty/AlexClarkData/analyses/sims-resubmission/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path0<-"K:/code/bayesnetty/AlexClarkData/analyses/sims-resubmission/"
} else {
 path0<-"C:/Users/richa/work/code/bayesnetty/AlexClarkData/analyses/sims-resubmission/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

setwd(figpath)

tInfo<-read.table(paste0(path0,"results-CIT/tMetCITRes",1,".dat"), header=TRUE)[,1:3]
bInfo<-read.table(paste0(path0,"results-CIT/bMetCITRes",1,".dat"), header=TRUE)[,1:3]

#meth->expr
tcellCIT<-read.table(paste0(path0,"results-summaries/tcellCITPval1.dat"), header=FALSE)
bcellCIT<-read.table(paste0(path0,"results-summaries/bcellCITPval1.dat"), header=FALSE)

tcellBN<-read.table(paste0(path0,"results-summaries/tcellBNPval1.dat"), header=FALSE)
bcellBN<-read.table(paste0(path0,"results-summaries/bcellBNPval1.dat"), header=FALSE)

tcellCIT[tcellCIT==0]<-NA
bcellCIT[bcellCIT==0]<-NA
tcellBN[tcellBN==0]<-NA
bcellBN[bcellBN==0]<-NA


simNet<-read.table(paste0(path0, "bestFitNet.dat"), header=FALSE, skip=100)


testedBcells<-paste0("b_",bInfo[,2]," ","b_",bInfo[,3])
testedTcells<-paste0("t_",tInfo[,2]," ","t_",tInfo[,3])

simedBcells0<-(substr(simNet[,1],1,4)=="b_cg" & substr(simNet[,2],1,4)=="b_IL")
simedTcells0<-(substr(simNet[,1],1,4)=="t_cg" & substr(simNet[,2],1,4)=="t_IL")

simedBcells<-paste0(simNet[simedBcells0,1]," ",simNet[simedBcells0,2])
simedTcells<-paste0(simNet[simedTcells0,1]," ",simNet[simedTcells0,2])

#reverse
rsimedBcells0<-(substr(simNet[,1],1,4)=="b_IL" & substr(simNet[,2],1,4)=="b_cg")
rsimedTcells0<-(substr(simNet[,1],1,4)=="t_IL" & substr(simNet[,2],1,4)=="t_cg")

rsimedBcells<-paste0(simNet[rsimedBcells0,2]," ",simNet[rsimedBcells0,1])
rsimedTcells<-paste0(simNet[rsimedTcells0,2]," ",simNet[rsimedTcells0,1])

##which ones tested were also sim'd?
wasSimmedB<-rep(FALSE, length(testedBcells))
for(i in 1:length(testedBcells))
{
 if(testedBcells[i] %in% simedBcells) wasSimmedB[i]<-TRUE 
}
sum(wasSimmedB)

wasSimmedT<-rep(FALSE, length(testedTcells))
for(i in 1:length(testedTcells))
{
 if(testedTcells[i] %in% simedTcells) wasSimmedT[i]<-TRUE 
}
sum(wasSimmedT)

rwasSimmedB<-rep(FALSE, length(testedBcells))
for(i in 1:length(testedBcells))
{
 if(testedBcells[i] %in% rsimedBcells) rwasSimmedB[i]<-TRUE 
}
sum(rwasSimmedB)

rwasSimmedT<-rep(FALSE, length(testedTcells))
for(i in 1:length(testedTcells))
{
 if(testedTcells[i] %in% rsimedTcells) rwasSimmedT[i]<-TRUE 
}
sum(rwasSimmedT)

notSimdEitherDirB<-(!wasSimmedB & !rwasSimmedB)
notSimdEitherDirT<-(!wasSimmedT & !rwasSimmedT)

##tested ones not simed in eith dir
sum(notSimdEitherDirB)
sum(notSimdEitherDirT)

#########has IVs?
testedBcellsIV<-paste0(bInfo[,1]," ","b_",bInfo[,2])
testedTcellsIV<-paste0(tInfo[,1]," ","t_",tInfo[,2])

simedBcells0IV<-(substr(simNet[,1],1,2)=="rs" & substr(simNet[,2],1,4)=="b_cg")
simedTcells0IV<-(substr(simNet[,1],1,2)=="rs" & substr(simNet[,2],1,4)=="t_cg")

simedBcellsIV<-paste0(simNet[simedBcells0IV,1]," ",simNet[simedBcells0IV,2])
simedTcellsIV<-paste0(simNet[simedTcells0IV,1]," ",simNet[simedTcells0IV,2])

wasSimmedBIV<-rep(FALSE, length(testedBcellsIV))
for(i in 1:length(testedBcellsIV))
{
 if(testedBcellsIV[i] %in% simedBcellsIV) wasSimmedBIV[i]<-TRUE 
}
sum(wasSimmedBIV)

wasSimmedTIV<-rep(FALSE, length(testedTcellsIV))
for(i in 1:length(testedTcellsIV))
{
 if(testedTcellsIV[i] %in% simedTcellsIV) wasSimmedTIV[i]<-TRUE 
}


sum(wasSimmedTIV)

sum(wasSimmedB)
sum(wasSimmedB & wasSimmedBIV)

sum(wasSimmedT)
sum(wasSimmedT & wasSimmedTIV)

sum(notSimdEitherDirB & wasSimmedBIV)
sum(notSimdEitherDirT & wasSimmedTIV)

############################################
getPowerCIT<-function(bt, pval)
{
   if(bt=="t")
   {
     res<-tcellCIT[posTestsToUseT,]
   } else {
     res<-bcellCIT[posTestsToUseB,]
   }
   
   mean(res<pval, na.rm=TRUE)
}

getTypeIErrorCIT<-function(bt, pval)
{
   if(bt=="t")
   {
     res<-tcellCIT[negTestsToUseT,]
   } else {
     res<-bcellCIT[negTestsToUseB,]
   }
   
   mean(res<pval, na.rm=TRUE)
}

getPowerBN<-function(bt, prob)
{
   if(bt=="t")
   {
     res<-tcellBN[posTestsToUseT,]
   } else {
     res<-bcellBN[posTestsToUseB,]
   }
   
   mean(res>prob, na.rm=TRUE)
}

getTypeIErrorBN<-function(bt, prob)
{
   if(bt=="t")
   {
     res<-tcellBN[negTestsToUseT,]
   } else {
     res<-bcellBN[negTestsToUseB,]
   }
   
   mean(res>prob, na.rm=TRUE)
}

############################################
posTestsToUseB<-wasSimmedB & wasSimmedBIV
posTestsToUseT<-wasSimmedT & wasSimmedTIV
negTestsToUseB<-notSimdEitherDirB & wasSimmedBIV
negTestsToUseT<-notSimdEitherDirT & wasSimmedTIV

sum(posTestsToUseB)
sum(negTestsToUseB)
sum(posTestsToUseT)
sum(negTestsToUseT)

pvalues<-seq(0, 1, 0.01)

##get average power for sim'd bcells over 1000 sims
bpowersCIT<-rep(0, length(pvalues))
btypeIerrorsCIT<-rep(0, length(pvalues))
tpowersCIT<-rep(0, length(pvalues))
ttypeIerrorsCIT<-rep(0, length(pvalues))

i<-1
for(p in pvalues)
{
  bpowersCIT[i]<-getPowerCIT("b", p) 
  btypeIerrorsCIT[i]<-getTypeIErrorCIT("b", p)
  tpowersCIT[i]<-getPowerCIT("t", p) 
  ttypeIerrorsCIT[i]<-getTypeIErrorCIT("t", p)
  i<-i+1
}

##get average type I error for sim'd bcells over 1000 sims

probs<-seq(0, 1, 0.01)

bpowersBN<-rep(0, length(pvalues))
btypeIerrorsBN<-rep(0, length(pvalues))
tpowersBN<-rep(0, length(pvalues))
ttypeIerrorsBN<-rep(0, length(pvalues))

i<-1
for(p in probs)
{
  bpowersBN[i]<-getPowerBN("b", p) 
  btypeIerrorsBN[i]<-getTypeIErrorBN("b", p)
  tpowersBN[i]<-getPowerBN("t", p) 
  ttypeIerrorsBN[i]<-getTypeIErrorBN("t", p)
  i<-i+1
}

xlabName<-"empirical false positive rate" 
ylabName<-"empirical true positive rate"
cex2<-2
lwd2=2
cex.axis2=1.5
cex.lab2=2
cleg2=2
cexmain2=2
#bottom, left, top, and right
mar2=c(5.1, 4.1, 4.1, 2.1) + c(0, 1, 0, -0.5) 
#labels, tick labels, tick marks
mgp2=c(3,1,0) #+c(0,0,0)


if(png==2) postscript(paste("fig-CIT-BN-ROC.eps",sep=""), width=6*3, height=3*3,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE ) else dev.new(width=10, height=5.25)

par(mar=mar2, mgp=mgp2, mfrow=c(1,2))

cols<-c("blue", "red")
pchs<-c(1,2)#1:6

par(mfrow=c(1,2))

plot(ttypeIerrorsCIT, tpowersCIT,  type="l", col=cols[1], pch=pchs[1], xlim=c(0,1), ylim=c(0,1), xlab=xlabName, ylab=ylabName, cex=cex2, cex.axis=cex.axis2, cex.lab= cex.lab2, cex.main=cexmain2, main="(a) T cell ROC curve")
points(ttypeIerrorsCIT, tpowersCIT,  type="p", col=cols[1], pch=pchs[1])
points(ttypeIerrorsBN, tpowersBN, type="l", col=cols[2], pch=pchs[2])
points(ttypeIerrorsBN, tpowersBN, type="p", col=cols[2], pch=pchs[2])
legend("bottomright", pch=pchs, lty=1, col=cols, legend=c("CIT", "BN"), title="method", cex=cleg2, lwd=lwd2)

plot(btypeIerrorsCIT, bpowersCIT, type="l", col=cols[1], pch=pchs[1], xlim=c(0,1), ylim=c(0,1), xlab=xlabName, ylab=ylabName, cex=cex2, cex.axis=cex.axis2, cex.lab= cex.lab2, cex.main=cexmain2, main="(b) B cell ROC curve")
points(btypeIerrorsCIT, bpowersCIT, type="p", col=cols[1], pch=pchs[1])
points(btypeIerrorsBN, bpowersBN, type="l", col=cols[2], pch=pchs[2])
points(btypeIerrorsBN, bpowersBN, type="p", col=cols[2], pch=pchs[2])
legend("bottomright", pch=pchs, lty=1, col=cols, legend=c("CIT", "BN"), title="method", cex=cleg2, lwd=lwd2)

if(png>0) dev.off()

 