##

home<-1

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path<-"/home/nrajh/code/bayesnetty/edgeCosts/paper-sims/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path<-"K:/code/bayesnetty/edgeCosts/paper-sims/"
} else {
 path<-"C:/Users/richa/work/code/bayesnetty/edgeCosts/paper-sims/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}



setwd(path)

noSims<-1000

png<-2

cex=1.5#3
lwd=1.5#3
cex.axis=1.5#5
cex.lab=1.5#5
cex.main=2#5

#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1) + c(0, 1.0, 0, 0)   #+ c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  #+ c(4,1.5,0)

#bottom, left, top, and right
#mar=c(5.1, 4.1, 4.1, 2.1)  #+ c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
#mgp=c(3,1,0) # + c(4,1.5,0)

cexleg<-1.1#4
labcex<-1.5#3


#n<-2000


xlab1<-expression(prior~probability~X%->%Y)
ylab1<-expression(proportion~best~fit~X%->%Y)

res1<-read.table("results1.dat", header=FALSE)
res3<-read.table("results3.dat", header=FALSE)


colour<-rainbow(6)

if(png==1) png(paste(figpath,"fig-edge-probs1-v2.png",sep=""), width = 800, height = 400, units = "px", pointsize = 12, bg = "white")
if(png==2) postscript(paste(figpath,"fig-edge-probs1-v2.eps",sep=""), width=12, height=6,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

if(png==0) dev.new(width=9, height=7)

par(mfrow=c(1,2), mar=mar, mgp=mgp)

plot(seq(0,1,0.1), res1[1, ]/noSims, xlab=xlab1, ylab=ylab1, col=colour[1], type="l", main=expression((a)~A%->%X%->%Y), ylim=c(0,1), lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, cex.main=cex.main)

for(betaA in seq(0.1,0.5,0.1))
{
points(seq(0,1,0.1), res1[10*betaA + 1, ]/noSims, col=colour[10*betaA + 1], type="l", lwd=lwd, cex=cexleg)
}

abline(h=0.5, lty=2)
abline(v=0.5, lty=2)
legend("right", legend=seq(0,0.5,0.1), col=colour, title=expression(beta[A]), lty=1, lwd=lwd, cex=cexleg)



plot(seq(0,1,0.1), res3[1, ]/noSims, xlab=xlab1, ylab=ylab1, col=colour[1], type="l", main=expression((b)~A%->%X%<-%Y), ylim=c(0,1), lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, cex.main=cex.main)

for(betaA in seq(0.1,0.5,0.1))
{
points(seq(0,1,0.1), res3[10*betaA + 1, ]/noSims, col=colour[10*betaA + 1], type="l", lwd=lwd, cex=cexleg)
}

abline(h=0.5, lty=2)
abline(v=0.5, lty=2)
legend("left", legend=seq(0,0.5,0.1), col=colour, title=expression(beta[A]), lty=1, lwd=lwd, cex=cexleg)



if(png>0) dev.off()

##############################################################################################################################

#bjklbjkl

countsBX2D<-read.table(paste("results6-BX2D.dat",sep=""), header=FALSE)
countsXY2D<-read.table(paste("results6-XY2D.dat",sep=""), header=FALSE)
 
if(FALSE)
{
 
noSims<-1000

#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1) + c(-4.1, -2.5, -0, -2.1)   #+ c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(0,0,0)

cex.axis=1.1#5
cex.lab=1.1#5
cex.main=1.1

if(png==1) png(paste(figpath,"fig-edge-multi-v2.png",sep=""), width = 800, height = 400, units = "px", pointsize = 12, bg = "white")
if(png==2) postscript(paste(figpath,"fig-edge-multi-v2.eps",sep=""), width=12, height=5,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

plotNo<-1

#par(mfrow=c(4,2), mar=mar, mgp=mgp)
#par(mfcol=c(2,6), mar=mar, mgp=mgp)
par(mfrow=c(1,2), mar=mar, mgp=mgp)

for(a in c(0.1))# c(0, 0.1, 0.2, 0.3, 0.4, 0.5))
{

x<-rep(0, 21*21)
y<-rep(0, 21*21)
zbx<-rep(0, 21*21)
zxy<-rep(0, 21*21)

i<-1

for(px in seq(0, 1, 0.05))
{

 for(pb in seq(0, 1, 0.05))
 {
  x[i]<-pb
  y[i]<-px
  
  colo<-(pb*20+1) + 21*(px*20)
  
  #resultsBX<-countsBX2D[10*a + 1, colo]
  #resultsXY<-countsXY2D[10*a + 1, colo]
  
  zbx[i]<-countsBX2D[10*a + 1, colo]/noSims
  zxy[i]<-countsXY2D[10*a + 1, colo]/noSims
  
  #zxy[i]<-x[i]*(x[i]-1)*y[i]*(y[i]-1) #countsXY2D[10*a + 1, colo]
  
  i<-i+1
 }

}

#zxy<-zxy/max(zxy)
 
x<-seq(0, 1, 0.05)
y<-x
#nums<-countsBX2D[res[,1]==beta0, coNo]/noSims

xlab1<-"\nprior probability B to X"
ylab1<-"\nprior probability X to Y"


z<-matrix(zxy, nrow=length(x), ncol=length(y), byrow = FALSE)

persp(x, y, z, xlim=c(0,1), ylim=c(0,1), zlim=c(0,1), lwd=3, theta = -30, phi = 30, expand = 0.6, 
 xlab=xlab1, ylab=ylab1, zlab="\nproportion", main=paste0("(",letters[plotNo],") Proportion of networks with X to Y"), col=colour[a*10+1+1], shade = 0.75, ticktype="detailed", cex.axis=cex.axis, cex.lab=cex.lab, cex.main=cex.main)

plotNo<-plotNo+1

z<-matrix(zbx, nrow=length(x), ncol=length(y), byrow = FALSE)

persp(x, y, z, xlim=c(0,1), ylim=c(0,1), zlim=c(0,1), lwd=3, theta = -30, phi = 30, expand = 0.6, 
 xlab=xlab1, ylab=ylab1, zlab="\nproportion", main=paste0("(",letters[plotNo],") Proportion of networks with B to X"), col=colour[a*10+1], shade = 0.75, ticktype="detailed", cex.axis=cex.axis, cex.lab=cex.lab, cex.main=cex.main)

plotNo<-plotNo+1
 
} ##end a loop


if(png>0) dev.off()

} ##end skip plot

###############

#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1) + c(-4.1, -2.4, -0, -2.1)   #+ c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(0,0,0)

cex.axis=1.1#5
cex.lab=1.1#5
cex.main=1.1

if(png==1) png(paste(figpath,"fig-edge-multi3-v2.png",sep=""), width = 800, height = 400, units = "px", pointsize = 12, bg = "white")
if(png==2) postscript(paste(figpath,"fig-edge-multi3-v2.eps",sep=""), width=8, height=12,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

colour<-rainbow(6)
colour[2]<-colour[1]
colour<-c(colour[1], colour[1], colour[2], colour[2], colour[3], colour[3], colour[4], colour[4], colour[5], colour[5], colour[6], colour[6]) 

plotNo<-1

par(mfrow=c(3,2), mar=mar, mgp=mgp)
#par(mfcol=c(2,3), mar=mar, mgp=mgp)
#par(mfrow=c(1,2), mar=mar, mgp=mgp)

for(a in c(0.1, 0.3, 0.5))
{

x<-rep(0, 21*21)
y<-rep(0, 21*21)
zbx<-rep(0, 21*21)
zxy<-rep(0, 21*21)

i<-1

for(px in seq(0, 1, 0.05))
{

 for(pb in seq(0, 1, 0.05))
 {
  x[i]<-pb
  y[i]<-px
  
  colo<-(pb*20+1) + 21*(px*20)
  
  #resultsBX<-countsBX2D[10*a + 1, colo]
  #resultsXY<-countsXY2D[10*a + 1, colo]
  
  zbx[i]<-countsBX2D[10*a + 1, colo]/noSims
  zxy[i]<-countsXY2D[10*a + 1, colo]/noSims
  
  #zxy[i]<-x[i]*(x[i]-1)*y[i]*(y[i]-1) #countsXY2D[10*a + 1, colo]
  
  i<-i+1
 }

}

#zxy<-zxy/max(zxy)
 
x<-seq(0, 1, 0.05)
y<-x
#nums<-countsBX2D[res[,1]==beta0, coNo]/noSims

xlab1<-"\nprior probability B to X"
ylab1<-"\nprior probability X to Y"

#

z<-matrix(zxy, nrow=length(x), ncol=length(y), byrow = FALSE)

persp(x, y, z, xlim=c(0,1), ylim=c(0,1), zlim=c(0,1), lwd=3, theta = -30, phi = 30, expand = 0.6, 
 xlab=xlab1, ylab=ylab1, zlab="\nproportion", main=paste("(",letters[plotNo],") Proportion of networks with X to Y (a = ",a,")",sep=""), col=colour[a*10*2+1+1], shade = 0.75, ticktype="detailed", cex.axis=cex.axis, cex.lab=cex.lab, cex.main=cex.main) -> pmat2

lines(trans3d(x, rep(0.5,length(x)), z[,11], pmat2), col="grey", lwd=2, lty=2)
lines(trans3d(rep(0.5,length(y)), y, z[11,], pmat2), col="grey", lwd=2, lty=2)

plotNo<-plotNo+1

z<-matrix(zbx, nrow=length(x), ncol=length(y), byrow = FALSE)

persp(x, y, z, xlim=c(0,1), ylim=c(0,1), zlim=c(0,1), lwd=3, theta = -30, phi = 30, expand = 0.6, 
 xlab=xlab1, ylab=ylab1, zlab="\nproportion", main=paste("(",letters[plotNo],") Proportion of networks with B to X (a = ",a,")",sep=""), col=colour[a*10*2+1], shade = 0.75, ticktype="detailed", cex.axis=cex.axis, cex.lab=cex.lab, cex.main=cex.main) -> pmat

#points(trans3d( x, y, apply(matrixMuSigma, 1, max), pmat=res), col="red")
 
lines(trans3d(x, rep(0.5,length(x)), z[,11], pmat), col="grey", lwd=2, lty=2)
lines(trans3d(rep(0.5,length(y)), y, z[11,], pmat), col="grey", lwd=2, lty=2)

plotNo<-plotNo+1

} ##end a loop


if(png>0) dev.off()






