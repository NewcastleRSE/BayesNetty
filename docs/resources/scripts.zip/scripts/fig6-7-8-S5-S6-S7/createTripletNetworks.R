##

path<-"K:/code/bayesnetty/AlexClarkData"

setwd(path)

bcell<-read.csv("data/RA_triplets_Bcell.csv", header=TRUE, stringsAsFactors=FALSE)
tcell<-read.csv("data/RA_triplets_Tcell.csv", header=TRUE, stringsAsFactors=FALSE)

head(bcell)
head(tcell)

others<-c("Diagnosis", "Gender", "Age") # Diagnosis
#others<-c("Diagnosis") # only diagnosis for SV , "Gender", "Age")

for(i in 1:length(bcell[,1]))
{
 net<-t(t(c(t(bcell[i,1:3]),others)))
 write.table(net, paste("analyses/tripletNetworks/bcell-network",i ,".dat", sep=""), quote=FALSE, row.names=FALSE, col.names=FALSE)
 #write.table(net, paste("analyses/tripletNetworks/bcellSV-network",i ,".dat", sep=""), quote=FALSE, row.names=FALSE, col.names=FALSE)

}

for(i in 1:length(tcell[,1]))
{
 net<-t(t(c(t(tcell[i,1:3]),others)))
 write.table(net, paste("analyses/tripletNetworks/tcell-network",i ,".dat", sep=""), quote=FALSE, row.names=FALSE, col.names=FALSE)
 #write.table(net, paste("analyses/tripletNetworks/tcellSV-network",i ,".dat", sep=""), quote=FALSE, row.names=FALSE, col.names=FALSE)

}
