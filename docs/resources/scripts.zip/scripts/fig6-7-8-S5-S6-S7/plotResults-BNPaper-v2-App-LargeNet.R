##

dataset<-"AC3" #"AC2" #2" #"SV3"

#path0<-"K:/code/bayesnetty/AlexClarkData/"

#path<-paste("K:/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset,"/", sep="")
#path<-paste("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset,"/", sep="")

home<-1    # 0 = at work, 1 = at home, 2 = linux
png<-2
strongThres<-1#1 #0#1#1#1 #FALSE #TRUE

doimpRT<-TRUE #TRUE #TRUE #TRUE

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path0<-"/home/nrajh/code/bayesnetty/AlexClarkData/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path0<-"K:/code/bayesnetty/AlexClarkData/"
} else {
 path0<-"C:/Users/richa/work/code/bayesnetty/AlexClarkData/"
 
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

path<-paste(path0,"analyses/results/results-",dataset,"/", sep="")

setwd(path)


imp<-1 # 0 = no imp, 1 = imp all variables, 2 = imp all variables using genes imp

removeLoneNodes<-FALSE #TRUE
markov<-0#1 #FALSE #TRUE


#load igraph library, http://igraph.org/r/
library(igraph)

editPts<-TRUE 

if(file.exists(paste0(figpath,"theCoordsAppLargeNet.dat",sep="")))
{
 theCoords<-as.matrix(read.table(paste0(figpath,"theCoordsAppLargeNet.dat",sep=""), header=FALSE))
 #theCoords<-as.matrix(read.table(paste0(figpath,"theCoords1.dat",sep=""), header=FALSE))
 editPts<-FALSE
} else {
 theCoords=matrix(0,nrow=1,ncol=1) 
}

if(editPts) png<-0

if(imp==0)
{
  stub<-paste("allVarsNoImp-",dataset,sep="")
  #setwd(paste("K:/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset,"/all-variables-no-imp",sep=""))
  setwd(paste("all-variables-no-imp",sep=""))
 } else if(imp==1 && !doimpRT) {
  #stub<-paste("allVarsImp-",dataset,"-imp",sep="")
  #setwd(paste("K:/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset,"/all-variables-imp",sep=""))
  #setwd(paste("all-variables-imp",sep=""))
  
  stub<-paste("allVarsImp-",dataset,"-imp",sep="") 
  setwd(paste("../results-AC3-1/all-variables-imp",sep=""))
 } else if(imp==1 && doimpRT) {
  stub<-paste("allVarsImpRT-",dataset,"-impRT",sep="")
  #setwd(paste("K:/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset,"/all-variables-imp",sep=""))
  setwd(paste("all-variables-impRT",sep=""))
 } else if(imp==2) {
  stub<-paste("allVarsImp-",dataset,"-gene-imp",sep="")
  #setwd(paste("K:/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset,"/all-variables-imp-genes",sep=""))
  setwd(paste("all-variables-imp-genes",sep=""))
}


#threshold, an arc must be greater than the threshold to be plotted
threshold<-read.table(paste(stub,"-ave-threshold.dat",sep=""), header=FALSE)[1,1]
#threshold<-0.7
if(strongThres) threshold<-0.6 #6 #threshold + (1-threshold)*0.2 #0.333 #(threshold+1)/2

thresholdGraph<-threshold

plotThresholdEst<-FALSE #TRUE

#load average network graph
aveGraph<-read.table(paste(stub,"-ave.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)



if(markov)
{
   toRemove<-c()
   for(i in 1:length(aveGraph$to))
   {
     if(!(aveGraph$to[i] %in% markov.nodes && aveGraph$from[i] %in% markov.nodes))
     {
      toRemove<-append(toRemove,i)
     }
   }

   aveGraph<-aveGraph[-toRemove,]
}

#plot arc strength versus cumulative number of arcs with strength <= arc strength
if(plotThresholdEst) {
dev.new(width=5, height=5)
#png(filename=paste(stub,"-ave-graph-thresholdEst.png",sep=""), width=600, height=600)
y<-c()
for(stren in aveGraph$strength) y<-append(y, sum(aveGraph$strength <= stren))
plot.stepfun(aveGraph$strength, xlab="arc strength", ylab="cumulative distribution function", verticals=FALSE, xlim=c(0,1), pch=19, main="")
abline(v=threshold, lty=2)
#dev.off()
}

#create node and edge tables for igraph
#map node names to numbers
nodeList<-as.numeric(as.factor(c(aveGraph$from, aveGraph$to)))
noArcs<-length(aveGraph$from)
fromNum<-nodeList[1:noArcs]
toNum<-nodeList[(noArcs+1):(2*noArcs)]
nodes1<-as.data.frame(cbind(fromNum, aveGraph$from, aveGraph$type1))
colnames(nodes1)<-c("id", "name", "type")
nodes2<-as.data.frame(cbind(toNum, aveGraph$to, aveGraph$type2))
colnames(nodes2)<-c("id", "name", "type")
nodes<-unique(rbind(nodes1, nodes2))
edges<-as.data.frame(cbind(fromNum, toNum, aveGraph$strength, aveGraph$direction))
colnames(edges)<-c("from", "to", "strength", "direction")

#as previous figure so that coords can be reused
orderNodes<-c(76,  93,  64,  97,  61,  28,  63,  47,  82,  12,  21,  27,  31,  53,  71,  43,  86,   3,  23,  84,  77,  34,  87,  92,  16,  37,  46,  65,  49,  85,  60,   1,  24,  54,  89,  83,   8,  10,  56,  42,  79,  36,  80,  18,   2,   9,  51,  58,   7, 41,  72,  39,  81,  98,   5,  17,  95,   4,  59,  25,   6,  11,  75,  15,  32,  96,  35,  88,  99,  33,  69,  78,  13,  48, 100,  70,  73,  45,  26,  94,  44,  68,  19,  30,  14,  40,  91,  22,  52,  66,  67,  20,  55,  57,  62,  50,  29,  74,  90,  38)

nodes<-nodes[match(orderNodes, nodes$id),]

#nodes<-nodes[order(nodes$id),]

#apply threshold for plotting arc/edge
edges<-edges[edges$strength > threshold,]

if(removeLoneNodes)
{
 newNodes<-nodes
 aveGraphTh<-aveGraph[aveGraph$strength>threshold,]

 for(nd in nodes$name)
 {
      if(!(nd %in% aveGraphTh$from || nd %in% aveGraphTh$to))
      {
       #print(nd)
       newNodes<-newNodes[-which(newNodes$name==nd),]
      }
 }

 nodes<-newNodes
}

#plot the network and output png file, edit style as required
getPrefixName<-function(nam)
{
 substr(nam, 1, 4)
}

pre<-getPrefixName(nodes$name)

#style for continuous nodes
shape<-rep("circle", length(nodes$type))
vsize<-rep(20, length(nodes$type))
color<-rep("black", length(nodes$type))

vcolor<-rep("#e6ffe6", length(nodes$type))
vcolor[pre=="t_cg"]<-"#ffe6ff"
vcolor[pre=="t_IL"]<-"#ff4dff"
vcolor[pre=="b_cg"]<-"#e6f2ff"
vcolor[pre=="b_IL"]<-"#4da3ff"
vcolor[pre=="Gend"]<-"#ffffe6"
vcolor[pre=="Age"]<-"#ffe5cc"
vcolor[pre=="Diag"]<-"#cc0000"

##update node labels to have gene name
bcell<-read.csv(paste0(path0,"data/RA_triplets_Bcell.csv"), header=TRUE, stringsAsFactors=FALSE)
tcell<-read.csv(paste0(path0,"data/RA_triplets_Tcell.csv"), header=TRUE, stringsAsFactors=FALSE)

#nodes2<-as.data.frame(nodes, stringsAsFactors=FALSE)
vlabels<-as.vector(nodes$name)

for(i in 1:length(nodes[,1]))
{
  if(substr(nodes$name[i],1,7) == "t_ILMN_")
  {
   matches<-which(substring(nodes$name[i],3)==tcell[,3])
   gene<-tcell[matches[1],4]
   if(length(matches)>0) vlabels[i]<-paste(gene, "_", substring(tcell[matches[1],3], 6), sep="")
  }

  if(substr(nodes$name[i],1,7) == "b_ILMN_")
  {
   matches<-which(substring(nodes$name[i],3)==bcell[,3])
   gene<-bcell[matches[1],4]
   if(length(matches)>0) vlabels[i]<-paste(gene, "_", substring(bcell[matches[1],3], 6), sep="")
  }
}

frame.cols<-rep("black", length(nodes$type))

if(markov)
{
  frame.cols[nodes$name==node.markov]<-"red"
}

#create graph
graph<-graph_from_data_frame(edges, directed = TRUE, vertices = nodes)

#plot the network and output png file, edit style as required

#edge widths for significances
minWidth<-0.3
maxWidth<-10
edgeMax<-max(edges$strength)
edgeMin<-min(edges$strength)
widths<-((edges$strength-edgeMin)/(edgeMax-edgeMin))*(maxWidth - minWidth) + minWidth
styles<-rep(1, length(widths))

edge.labels<-ifelse(edges$direction==1, round(edges$strength,2), paste(round(edges$strength,2),"(",round(edges$direction,2),")",sep=""))

thrStr<-""
if(strongThres==1) thrStr<-"StrongThres" #1#1 #FALSE #TRUE

#if(png==1) png(paste(figpath,"fig-app-largeNetImp",thrStr,".png",sep=""), width = 800, height = 800*1.66, units = "px", pointsize = 12, bg = "white")
#if(png==2) postscript(paste(figpath,"fig-app-largeNetImp",thrStr,".eps",sep=""), height=14, width=14*1.66,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

#finish png file
#dev.off()
#if(editPts)
#{
  tkCor<-tkplot(graph, canvas.width = 450*1.66*2, canvas.height = 450*2, vertex.frame.color=frame.cols, vertex.label=vlabels, vertex.shape=shape, vertex.size=vsize, vertex.color=vcolor, vertex.label.color=color, edge.width=widths, edge.lty=styles, edge.color="black", edge.arrow.size=1.5, edge.label = edge.labels, edge.label.cex=1.5, edge.label.color="red", layout=theCoords)
  
  #if(theCoords[1,1]!=0) tk_set_coords(tkCor, theCoords)
  
  ##run by hand if editing pts
  if(FALSE)
  {
   ##get coords and replot
   theCoords<-tk_coords(tkCor)

   #tk_close(tkCor)
  
   write.table(theCoords, paste0(figpath,"theCoordsAppLargeNet.dat",sep=""), quote=FALSE, col.names=FALSE, row.names=FALSE)
  }
  
  
#} else {

  #plot(graph, canvas.width = 450*1.66*2, canvas.height = 450*2, vertex.frame.color=frame.cols, vertex.label=vlabels, vertex.shape=shape, vertex.size=vsize, vertex.color=vcolor, vertex.label.color=color, edge.width=widths, edge.lty=styles, edge.color="black", edge.arrow.size=1.5, edge.label = edge.labels, edge.label.cex=1.5, edge.label.color="red", layout=theCoords)
  
#}

dim(edges)

thresholdGraph

#if(png>0) dev.off()

if(png==2) tkplot.export.postscript(tkCor)

 