dataset<-commandArgs()[4]

#path<-paste("C:/Users/nrajh/work/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,sep="")
#path<-paste("K:/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,sep="")
#setwd(path)

tmet<-read.table(paste("tmet-",dataset,".dat",sep=""), header=TRUE)
texp<-read.table(paste("texp-",dataset,".dat",sep=""), header=TRUE)
bmet<-read.table(paste("bmet-",dataset,".dat",sep=""), header=TRUE)
bexp<-read.table(paste("bexp-",dataset,".dat",sep=""), header=TRUE)
info<-read.table(paste("indivInfo-cts.dat",sep=""), header=TRUE)
snps<-read.table(paste("snpDataFiltered-SNPs-cts.dat",sep=""), header=TRUE)

randomImputeData<-function(dat)
{
  dat.new<-dat
  ##loop thro cols and replace with random values
  for(co in 3:ncol(dat))
  {
    nonMissingVals<-dat[!is.na(dat[,co]),co]

    if(length(nonMissingVals)>0)
    {
     #loop thro rows
     for(ro in 1:nrow(dat))
     {
      if(is.na(dat[ro,co]))
      {      
        dat.new[ro,co]<-sample(nonMissingVals, 1)
      }   
     }
    }
  }
  dat.new
}

tmet.new<-randomImputeData(tmet)
texp.new<-randomImputeData(texp)
bmet.new<-randomImputeData(bmet)
bexp.new<-randomImputeData(bexp)
info.new<-randomImputeData(info)
snps.new<-randomImputeData(snps)


##write random data
write.table(tmet.new, paste("tmet-",dataset,"-RAND.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(texp.new, paste("texp-",dataset,"-RAND.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(bmet.new, paste("bmet-",dataset,"-RAND.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(bexp.new, paste("bexp-",dataset,"-RAND.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(info.new, paste("indivInfo-cts-RAND.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
write.table(snps.new, paste("snpDataFiltered-SNPs-cts-RAND.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)


#simData<-read.table("sim-data-cts.dat", header=TRUE)
#simDataSNPs<-read.table("sim-data-SNPs-cts.dat", header=TRUE)

#simData.new<-randomImputeData(simData)
#simDataSNPs.new<-randomImputeData(simDataSNPs)

#write.table(simData.new, paste("sim-data-cts-RAND.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
#write.table(simDataSNPs.new, paste("sim-data-SNPs-cts-RAND.dat",sep=""), quote=FALSE, col.names=TRUE, row.names=FALSE)
