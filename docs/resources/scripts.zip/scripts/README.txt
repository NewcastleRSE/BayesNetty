Scripts for simulations, analyses, plots etc relating to the
manuscript: "A Bayesian network approach incorporating imputation
of missing data enables exploratory analysis of complex causal
biological relationships" by R Howey, A Clark, N Naamane, L
Reynard, A Pratt, H J Cordell

The following directories contain the scripts designed to run in
Linux with the use of R and BayesNetty. R scripts, BayesNetty
parameter files and associated files. If you wish to run these
scripts the directory location of the BayesNetty executable will
need to be updated as well as the location of some data files.

Directory fig1: The scripts beginning with "the" are the ones to
run to simulate and analyses all of the data. The "plot.." R file
plots the figure.

Directory fig2-S1: The scripts beginning with "the" are the ones to
run to simulate and analyses all of the data. The "plot.." R file
plots the figures.

Directory fig3-4: The "runManyAnalysisPaper" should be ran such
that:
 ./runManyAnalysisPaper 20 1 1000
so that the missing percentage to set to 20 and 1000 simulations
are used. The R script
"plotResults-BNPaper-v2-Imputation-LargeNet.R" plots figure 3 and
"plotResults-BNPaper-v2-Imputation-LargeNet-Lines" figure 4.

Directory fig5: The script "runMany" performs the simulations and
analyses. The R file "collateResults.R" collates the results. The
script "plotResults-BNPaper-v2-EdgeProbsLarge.R" plots the figure.

Directory fig6-7-8-S5-S6-S7: The script "runGenAllAnalysesX"
contains a list of all the commands to do the analyses. The
"plot.." R files plot all of the figures.

Directory figS2: The file "theSims.txt" contains a list of how the
script "runManySimsBNReposGen" should be ran. The R script
"plotResults-BNPaper-v2-BNRepos.R" plots the figure.

Directory figS3-S4: The scripts "runManySims3" and "runManySims6"
should be ran, then "collateResults-EdgeProbs.R" and
"collateResults-EdgeProbs10.R" to collate the results. The
"plotResults-BNPaper-v2-EdgeProbs.R" plots the figures.

Directory figS8: The script "runManySims" should be ran such that:
./runManySims 1 1000
 The "createSummaryOfResults.R" script should then be ran to
 collate the results. The "plotResults-CIT-ROC.R" plots the figure.
 A different large network can be used as a basis for the
 simulations by running "runBestFit".

Directory figS9: The script "theSimsBN" contains the commands to
run all the simulations and analyses. The
"plotResults-BNPaper-v2-5-Nodes-SubsetPercentBN.R" plots the
figure.
