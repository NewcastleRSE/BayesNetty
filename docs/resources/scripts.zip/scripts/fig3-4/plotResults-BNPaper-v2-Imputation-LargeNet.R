
## Load package
library(igraph)

edge.arrow.size=2
edge.width=3 ##simulation only
vertex.label.cex=4
vertex.size=20

snpCol<-"lightcyan"
expCol<-"khaki"

bet<-0.3 #0.35 #0.2 #0.05
seed<-22 #1


home<-1    # 0 = at work, 1 = at home, 2 = linux
png<-2

doimpRT<-TRUE
doExtraPlots<-TRUE

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 setwd("/home/nrajh/code/missingData/large-example3/")
} else if(home == 0) {
 setwd("K:/code/bayesnetty/missingData/large-example3/")
 figpath<-"K:/work-other/tex/bayesNet/"
} else {
 setwd("C:/Users/richa/work/code/bayesnetty/missingData/large-example3/")
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}


plotCorGraph<-function(coords=matrix(0,nrow=1,ncol=1) )
{

correctNet<-"correctNet.dat"

##get correct network edges
noNodesCor<-length(t(unique(read.table(correctNet, header=FALSE))))
edgesCor<-read.table(correctNet, header=FALSE, colClasses=c("character", "character"), skip=noNodesCor, stringsAsFactors=FALSE)

nodesCor<-unique(read.table(correctNet, header=FALSE))

noEdges<-length(edgesCor[,1])


#igraphdemo()

verCols<-rep("plum1", length(nodesCor[,1]))
verCols[substr(nodesCor[,1], 1, 1) == "e"]<-expCol
verCols[substr(nodesCor[,1], 1, 1) == "s"]<-snpCol

#create graph
graph<-graph_from_data_frame(edgesCor, directed = TRUE, vertices = nodesCor)

if(coords[1,1]!=0)
{

#if(png==0) dev.new()

#if(png==1) png(paste(figpath,"plotGraph",bet,"-Correct.png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")

plot(graph, vertex.color=verCols, vertex.label.color="black", edge.arrow.size=edge.arrow.size, edge.width=edge.width, vertex.size=vertex.size, vertex.label.cex=vertex.label.cex, edge.color="blue", layout=theCoords) 

#if(png>0) dev.off()

}

#plot(graph)

if(coords[1,1]==0) tkplot(graph, vertex.color=verCols, vertex.label.color="black", edge.arrow.size=edge.arrow.size, edge.width=edge.width, vertex.size=vertex.size, edge.color="blue") 
}



plotGraph<-function(bet, miss, showMissing)
{

correctNet<-"correctNet.dat"

##get correct network edges
noNodesCor<-length(t(unique(read.table(correctNet, header=FALSE))))
edgesCor<-read.table(correctNet, header=FALSE, colClasses=c("character", "character"), skip=noNodesCor, stringsAsFactors=FALSE)
listEdgesCor<-paste(edgesCor[,1], edgesCor[,2])

someEdges<-paste("resultsPaperRedo",bet,"-",20,"-",seed,"/fitted",miss,"-edges.dat", sep="")
someNodes<-paste("resultsPaperRedo",bet,"-",20,"-",seed,"/fitted",miss,"-nodes.dat", sep="")
#someEdges<-paste("resultsPaper",bet,"-",0,"-",seed,"/fitted",miss,"-edges.dat", sep="")
#someNodes<-paste("resultsPaper",bet,"-",0,"-",seed,"/fitted",miss,"-nodes.dat", sep="")

impEdges<-read.table(someEdges, header=TRUE, stringsAsFactors=FALSE)
impNodes<-read.table(someNodes, header=TRUE, stringsAsFactors=FALSE)

noEdges<-length(impEdges[,1])
impEdgeList<-paste(impNodes$name[impEdges[,1]], impNodes$name[impEdges[,2]])

isCorEdge<-impEdgeList %in% listEdgesCor

impEdgeList2<-paste(impNodes$name[impEdges[,2]], impNodes$name[impEdges[,1]])
isEdgeBackwards<-impEdgeList2 %in% listEdgesCor

noMiss<-0

if(showMissing)
{
   cor1<-rep(0, length(edgesCor[, 1]))
   cor2<-rep(0, length(edgesCor[, 1]))
     
   for(i in 1:length(edgesCor[, 1]))
   {
       cor1[i]<-which(edgesCor[i, 1] == impNodes$name)
       cor2[i]<-which(edgesCor[i, 2] == impNodes$name)
   }

  
   isMissing<-!(listEdgesCor %in% impEdgeList) & !(listEdgesCor %in% impEdgeList2)
   
   noMiss<-length(cor1[isMissing])
   
   missEdges<-cbind(cor1[isMissing], cor2[isMissing], rep(min(impEdges$chisq),noMiss))
   colnames(missEdges)<-c("from", "to", "chisq")
   
   impEdges<-rbind(impEdges, missEdges)
}

#sigOrder<-order(-impEdges$chisq)
#impEdges$chisq[sigOrder]
#impRes0<-cbind(impNodes$name[impEdges[,1]], impNodes$name[impEdges[,2]], impEdges$chisq, isCorEdge)
#impRes<-impRes0[sigOrder,]

#create graph
graph<-graph_from_data_frame(impEdges, directed = TRUE, vertices = impNodes)

#plot(graph)

minWidth<-0.3
maxWidth<-10
edgeMax<-max(impEdges[,3])
edgeMin<-min(impEdges[,3])
widths<-((impEdges[,3]-edgeMin)/(edgeMax-edgeMin))*(maxWidth - minWidth) + minWidth
#styles<-rep(1, length(widths))

edgeCols<-rep("green", length(impEdges[,1]))
edgeCols[!isCorEdge]<-"red"
edgeCols[isEdgeBackwards]<-"darkviolet"
edgeStyles<-rep(1, length(impEdges[,1]))
if(noMiss>0)
{
 edgeCols[(length(impEdges[,1])-noMiss+1):length(impEdges[,1])]<-"gray" #"gray95"
 edgeStyles[(length(impEdges[,1])-noMiss+1):length(impEdges[,1])]<-1
 }

verCols<-rep("plum1", length(impNodes$name))
verCols[substr(impNodes$name, 1, 1) == "e"]<-expCol
verCols[substr(impNodes$name, 1, 1) == "s"]<-snpCol

#if the data is imputed draw some edges dashed to suggest possible false positive edges (most likely when the intermediate variable is heavily imputed)
isImputedData<-TRUE

existsStrongerIndirectRoute<-function(edgeNo, edges)
{
isOtherRoute<-FALSE
allFroms<-edges[edges$from==edges$from[edgeNo],]

for(i in 1:length(allFroms$to))
{
nextEdges<-edges[allFroms$to[i]==edges$from,]
num<-which(edges$to[edgeNo] == nextEdges$to)
if(length(num)==1 && edges[edgeNo,3]<allFroms[i, 3] && edges[edgeNo,3]<nextEdges[num, 3]) isOtherRoute<-TRUE
}

isOtherRoute
}

getAllDashed<-function(edges)
{
results<-rep(FALSE, length(edges$from))
for(i in 1:length(edges$from)) results[i]<-existsStrongerIndirectRoute(i, edges)
results
}

#set some edges to be dashed using the two above functions
if(isImputedData)
{
#isDashed<-getAllDashed(impEdges)
#edgeStyles[isDashed]<-2
#edgeCols[isDashed]<-"pink"
}


#if(png==0) dev.new()

#if(png==1) png(paste(figpath,"plotGraph",bet,"-",seed,"-",miss,".png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")

plot(graph, vertex.color=verCols, vertex.label.color="black", edge.arrow.size=edge.arrow.size, vertex.size=vertex.size, vertex.label.cex=vertex.label.cex, edge.width=widths, edge.color=edgeCols, layout=theCoords, edge.lty = edgeStyles) 

#if(png>0) dev.off()

#http://igraph.org/r/doc/plot.common.html

}


#tkplot(graph, vertex.color="white", vertex.label.color="black", edge.width=3, edge.color="blue") 


####################################################################
#plot then adjust coords
tkCor<-plotCorGraph()


##get coords and replot
theCoords<-tk_coords(tkCor)

#tk_close(tkCor)

####################################################################


boxText<-function(tit, letter)
{
box(col = 'black')
title(tit, cex.main=3.8*1.4)
text(-1.09, 1.05, letter, cex=3.5*1.4)
}

if(doExtraPlots) hgt<-1.5 else hgt<-1
if(doExtraPlots) extraName<-"6plots-" else extraName<-"" 

if(png==1) png(paste(figpath,"fig-largeNetImputation-",extraName,seed,"-v3.png",sep=""), width = 1800, height = 1800*hgt, units = "px", pointsize = 12, bg = "white")
if(png==2) postscript(paste(figpath,"fig-largeNetImputation-",extraName,seed,"-v3.eps",sep=""), height=34*hgt, width=34,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

#par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))

if(doExtraPlots) par(mfrow=c(3,2)) else par(mfrow=c(2,2))
plotCorGraph(theCoords)
boxText("Simulation Model", "(a)")


showMissing<-TRUE

plotGraph(bet, "Full", showMissing)
boxText("Full Data", "(b)")

plotGraph(bet, "Miss", showMissing)
boxText("Reduced Data", "(c)")

if(doExtraPlots)
{
 
 plotGraph(bet, "Random", showMissing)
 boxText("Random Data", "(d)")

 plotGraph(bet, "Imp", showMissing)
 boxText("Imputed Data CT", "(e)")
 
 plotGraph(bet, "ImpRT", showMissing)
 boxText("Imputed Data", "(f)")
 
} else {


 if(doimpRT) plotGraph(bet, "ImpRT", showMissing) else plotGraph(bet, "Imp", showMissing) 
 boxText("Imputed Data", "(d)")

}

if(png>0) dev.off()

#theCoords0<-theCoords

