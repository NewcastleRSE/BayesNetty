
#setwd("C:/Users/richa/work/code/bayesnetty/edgeCosts/model10/")

name<-commandArgs()[4]

noSims<-10000

#collate results for model10
resultsRecall<-matrix(0, nrow=6, ncol=11)
resultsPre<-matrix(0, nrow=6, ncol=11)

rowNo<-1
for(a in c(0, 0.1, 0.2, 0.3, 0.4, 0.5))
{

 colNo<-1
 for(p in c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1))
 {
  recall<-0
  pre<-0
  preTot<-0
  for(i in 1:noSims)
  {
   res<-read.table(paste("results/recall-pre-",a,"-",p,"-",i,".dat",sep=""), header=FALSE)
   recall<-recall+res[1,1]
   if(!is.nan(res[1,2]))
   {
    pre<-pre+res[1,2] 
    preTot<-preTot+1
   }
  }
  recall<-recall/noSims
  pre<-pre/preTot
  resultsRecall[rowNo, colNo]<-recall
  resultsPre[rowNo, colNo]<-pre
  
  colNo<-colNo+1
 }

 rowNo<-rowNo+1
}

#rows, betas; cols, probs
write.table(resultsRecall, paste("resultsSummary/resultsRecall-",name,".dat",sep=""), quote=FALSE, row.names = FALSE, col.names = FALSE)
write.table(resultsPre, paste("resultsSummary/resultsPrecision-",name,".dat",sep=""), quote=FALSE, row.names = FALSE, col.names = FALSE)

#get individual edge directions and recall

correctEdges<-read.table("model10.dat", skip=18, header=FALSE, stringsAsFactors=FALSE)


for(a in c(0, 0.1, 0.2, 0.3, 0.4, 0.5))
{
 
 edgeResDir2<-matrix(0, nrow=length(correctEdges[,1]), ncol=11) 
 edgeResRecall<-matrix(0, nrow=length(correctEdges[,1]), ncol=11) 
 colNo<-1
  
  for(p in c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1))
  {
     for(i in 1:noSims)
     {  
       someEdges<-tryCatch(read.table(paste("results/fit-",a,"-",p,"-",i,".dat",sep=""), skip=18, header=FALSE, stringsAsFactors=FALSE), error=function(e) NULL)
       
       if(!is.null(someEdges))
       {
        for(ed in 1:length(correctEdges[,1]))
        {
         #find if edge exists...
         if(sum(correctEdges[ed,1] == someEdges[,1] & correctEdges[ed,2] == someEdges[,2])==1)
         {
          edgeResRecall[ed, colNo]<-edgeResRecall[ed, colNo] + 1          
         }
         else if(sum(correctEdges[ed,1] == someEdges[,2] & correctEdges[ed,2] == someEdges[,1])==1)
         {
          edgeResDir2[ed, colNo]<-edgeResDir2[ed, colNo] + 1
         }
          
        }#end ed loop (edges)
       }
     }#end i loop

   colNo<-colNo+1
  }#end p loop   (probs)


 edgeResDir<-as.data.frame(cbind(correctEdges[,1], correctEdges[,2], edgeResRecall/(edgeResRecall+edgeResDir2) ))
 edgeResRecall<-as.data.frame(cbind(correctEdges[,1], correctEdges[,2], edgeResRecall/noSims ))
 
 write.table(edgeResDir, paste("resultsSummary/resDirection-",a,"-",name,".dat",sep=""), quote=FALSE, row.names = FALSE, col.names = FALSE)
 write.table(edgeResRecall, paste("resultsSummary/resRecall-",a,"-",name,".dat",sep=""), quote=FALSE, row.names = FALSE, col.names = FALSE)
 
}#end a loop (betas)

resultsRecall

resultsPre
