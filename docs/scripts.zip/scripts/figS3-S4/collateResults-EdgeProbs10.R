
#path<-"K:/code/bayesnetty/edgeCosts/paper-sims/"

path<-"/home/nrajh/code/bayesnetty/edgeCosts/paper-sims/"

setwd(path)

noSims<-1000

resultsSet<-6

countsBX2D<-matrix(0, nrow=6, ncol=21*21)
countsXY2D<-matrix(0, nrow=6, ncol=21*21)

#countsBX <- array(rep(0, 6*11*11), dim=c(6, 11, 11))
#countsXY <- array(rep(0, 6*11*11), dim=c(6, 11, 11))

for(a in seq(0, 0.5, 0.1))
{

for(px in seq(0, 1, 0.05))
{

for(pb in seq(0, 1, 0.05))
{

countBX<-0
countXY<-0 

for(s in 1:noSims)
{
 

 score1<-read.table(paste("results6/","score1-",a,"-",pb,"-",px,"-",s,".dat" ,sep=""), header=FALSE)[1,1] #B->X->Y
 score2<-read.table(paste("results6/","score2-",a,"-",pb,"-",px,"-",s,".dat" ,sep=""), header=FALSE)[1,1] #B<-X->Y
 score3<-read.table(paste("results6/","score3-",a,"-",pb,"-",px,"-",s,".dat" ,sep=""), header=FALSE)[1,1] #B->X<-Y
 score4<-read.table(paste("results6/","score4-",a,"-",pb,"-",px,"-",s,".dat" ,sep=""), header=FALSE)[1,1] #B<-X<-Y
 
 if(max(score1,score3) > max(score2,score4))
 {
  countBX<-countBX+1
  }
  
 if(max(score1,score2) > max(score3,score4)) countXY<-countXY+1
  
}
 
  
  colo<-(pb*20+1) + 21*(px*20)
  
  countsBX2D[10*a + 1, colo]<-countBX
 
  countsXY2D[10*a + 1, colo]<-countXY
  
}

}

}




#counts

write.table(countsBX2D, paste("results6-BX2D.dat",sep=""), col.names=FALSE, row.names=FALSE)

write.table(countsXY2D, paste("results6-XY2D.dat",sep=""), col.names=FALSE, row.names=FALSE)

