
#path<-"K:/code/bayesnetty/edgeCosts/paper-sims/"

path<-"/home/nrajh/code/bayesnetty/edgeCosts/paper-sims/"

setwd(path)

noSims<-1000

resultsSet<-3

counts<-matrix(0, nrow=6, ncol=11)
 

for(a in seq(0, 0.5, 0.1))
{

for(p in seq(0, 1, 0.1))
{

count<-0

for(s in 1:noSims)
{
 

 filename<-paste("results",resultsSet,"/all-BICprob-scores-",a,"-",p,"-",s,".dat" ,sep="")

 someData<-read.table(filename, header=FALSE)

 if(max(someData[4,2], someData[5,2]) > someData[6,2]) count<-count + 1

}
 
  counts[10*a + 1, 10*p + 1]<-count
  
}

}




#counts

write.table(counts, paste("results",resultsSet,".dat",sep=""), col.names=FALSE, row.names=FALSE)

