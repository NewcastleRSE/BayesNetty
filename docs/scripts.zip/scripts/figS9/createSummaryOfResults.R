##

sims<-1:1000

doImp<-TRUE
if(doImp) imp<-"-imp" else imp<-""

if(!doImp)
{

##do CIT summaries
tcellCITPval1<-matrix(0, nrow=42, ncol=1000)
tcellCITPval2<-matrix(0, nrow=42, ncol=1000)
bcellCITPval1<-matrix(0, nrow=65, ncol=1000)
bcellCITPval2<-matrix(0, nrow=65, ncol=1000)

for(i in sims)
{

 tRes<-read.table(paste0("results-CIT/tMetCITRes",i,".dat"), header=TRUE)
 bRes<-read.table(paste0("results-CIT/bMetCITRes",i,".dat"), header=TRUE)

 tcellCITPval1[,i]<-tRes[,6]
 tcellCITPval2[,i]<-tRes[,7]
 
 bcellCITPval1[,i]<-bRes[,6]
 bcellCITPval2[,i]<-bRes[,7]
 
}

}#end doImp

##do BN summaries
tInfo<-read.table(paste0("results-CIT/tMetCITRes",1,".dat"), header=TRUE)[,2:3]
bInfo<-read.table(paste0("results-CIT/bMetCITRes",1,".dat"), header=TRUE)[,2:3]

getStrengthAndDir<-function(aveRes, cpg0, expr0, pre="")
{
  cpg<-paste(pre,cpg0,sep="")
  expr<-paste(pre,expr0,sep="")
  
  ans<-c(0,0)
 
  rowNum<-which(aveRes[,1]==cpg & aveRes[,3]==expr)

  if(length(rowNum)>0)
  {
    ans<-c(aveRes$strength[rowNum], aveRes$direction[rowNum])
  } else {
    rowNum<-which(aveRes[,3]==cpg & aveRes[,1]==expr)
    
    if(length(rowNum)>0)
    {
     ans<-c(aveRes$strength[rowNum], 1-aveRes$direction[rowNum])
     }
  }

  ans
}

#get prob met->exp and exp->met
getProbs<-function(bt, tripno, it)
{
   res<-read.table(paste0("results-BN/",bt,"cell-",tripno,"-",it,imp,".dat"), header=TRUE)
   if(bt=="t")
   {
    meth<-tInfo[tripno,1]
    express<-tInfo[tripno,2]
   } else {
    meth<-bInfo[tripno,1]
    express<-bInfo[tripno,2]   
   }
   
   ans0<-getStrengthAndDir(res, meth, express) 

   c(ans0[1]*ans0[2], ans0[1]*(1-ans0[2]))
}


###################################
tcellBNPval1<-matrix(0, nrow=42, ncol=1000)
tcellBNPval2<-matrix(0, nrow=42, ncol=1000)
bcellBNPval1<-matrix(0, nrow=65, ncol=1000)
bcellBNPval2<-matrix(0, nrow=65, ncol=1000)

for(b in 1:65)
{
 for(i in sims)
 {
  #res<-read.table(paste0("results-BN/bcell-",b,"-",i,".dat"), header=TRUE)
  probs<-getProbs("b",b,i)
  bcellBNPval1[b,i]<-probs[1]
  bcellBNPval2[b,i]<-probs[2]
 }
 
}

for(t0 in 1:42)
{
 for(i in sims)
 {
  
  probs<-getProbs("t",t0,i)
  tcellBNPval1[t0,i]<-probs[1]
  tcellBNPval2[t0,i]<-probs[2]
 }
 
}

write.table(tcellCITPval1, paste0("results-summaries/tcellCITPval1.dat"), quote=FALSE, row.names=FALSE, col.names=FALSE)
write.table(tcellCITPval2, paste0("results-summaries/tcellCITPval2.dat"), quote=FALSE, row.names=FALSE, col.names=FALSE)
write.table(bcellCITPval1, paste0("results-summaries/bcellCITPval1.dat"), quote=FALSE, row.names=FALSE, col.names=FALSE)
write.table(bcellCITPval2, paste0("results-summaries/bcellCITPval2.dat"), quote=FALSE, row.names=FALSE, col.names=FALSE)

write.table(tcellBNPval1, paste0("results-summaries/tcellBNPval1",imp,".dat"), quote=FALSE, row.names=FALSE, col.names=FALSE)
write.table(tcellBNPval2, paste0("results-summaries/tcellBNPval2",imp,".dat"), quote=FALSE, row.names=FALSE, col.names=FALSE)
write.table(bcellBNPval1, paste0("results-summaries/bcellBNPval1",imp,".dat"), quote=FALSE, row.names=FALSE, col.names=FALSE)
write.table(bcellBNPval2, paste0("results-summaries/bcellBNPval2",imp,".dat"), quote=FALSE, row.names=FALSE, col.names=FALSE)


