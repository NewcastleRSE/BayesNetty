

home<-1

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path<-"/home/nrajh/code/bayesnetty/missingData/sims/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path<-"K:/code/bayesnetty/missingData/sims/"
} else {
 path<-"C:/Users/richa/work/code/bayesnetty/missingData/sims/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

writeSummaries<-FALSE #TRUE #only if not reading summaries
readSummaries<-TRUE

#modType<-"Cts" #"Dis" = discrete; "" = cts
#model<-3
#perMiss<-2 #1 #0

doBreak<-FALSE

# plot random training imp version
plotImpRT<-TRUE

##plots 1 and 2 in paper

doPlot1<-1 #mod1 cts dir
doPlot2<-1 #mod3 cts undir
doPlot3<-0 #mod1 dis dir
doPlot4<-0 #mod3 dis undir

doPlot5<-0 #mod1 cts undir
doPlot6<-0 #mod1 dis undir

doPlot7<-0 #mod1 cts dir 20%
doPlot8<-0 #mod3 cts undir 20%

setwd(path)

#seed1<-1
#seed2<-2
seeds<-1:1000 ##reps


png<-2 #0#1


xlab=expression(beta)
ylab="number of edges"

cex=1.5 #3
lwd=1.5 #3
cex.axis=1.5 #5
cex.lab=1.5 #5
cex.main=2 #5

cexleg<-1.5#1.1#4
labcex<-3#1.5#3


#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1)  + c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(4,1.5,0)

usingPlots<-c(TRUE, plotImpRT, TRUE, TRUE, TRUE, TRUE)
cols<-c("green", "red", "magenta", "red", "orange", "cyan")
pchs<-c(19, 10, 7, 1, 3, 4)
ltys<-c(1, 1, 1, 2, 1, 1)
leg=c("Full", "Imputed", "Imputed CT", "Reduced", "Random", "EM")[usingPlots]

cexleg<-1.5#1.1#4
labcex<-3#1.5#3

if(png==1)
{
cex=1.5#3
lwd=1.5#3
cex.axis=2 #1.5#5
cex.lab=2 #1.5#5
cex.main=2#5

cexleg<-1.5#1.1#4
labcex<-3#1.5#3
}

#correctNet<-"correctNet.dat"
#dir<-"results0pt4/"
#dir<-"results0.5-8/"



getEdges<-function(networkStr)
{
 fromNodes<-c()
 toNodes<-c()
 fromNode<-"X"
 toNode<-"X"
 
 for(i in 1:nchar(networkStr))
 {
  aChar<-substr(networkStr, i, i)
  if(aChar == "[" || aChar == "]")
  {     
     toNode<-"X" 
  } else if(aChar != ":" && aChar != "r" && aChar != "|") {
    if(toNode == "X") toNode<-aChar
    else {         
      fromNodes<-append(fromNodes, aChar)
      toNodes<-append(toNodes, toNode)     
    }
  }
 }

 cbind(fromNodes, toNodes)
}


calcNoEdges<-function(correctNet, otherNet0, arcs0="")
{

#correctNet<-paste("results",notMiss,"-",bet,"/",correctNet0,sep="")



##get correct network edges
#noNodesCor<-length(t(unique(read.table(correctNet, header=FALSE))))
edgesCor<-getEdges(correctNet)
noNodesCor<-length(edgesCor[,1])
#edgesCor<-read.table(correctNet, header=FALSE, colClasses=c("character", "character"), skip=noNodesCor, stringsAsFactors=FALSE)

##get other network edges
#noNodesOth<-length(t(unique(read.table(otherNet, header=FALSE))))
#edgesOth<-read.table(otherNet, header=FALSE, colClasses=c("character", "character"), skip=noNodesOth, stringsAsFactors=FALSE)
if(otherNet0=="EM")
{
 edgesOth<-arcs0
} else {
 edgesOth<-getEdges(otherNet0)
}

noNodesOth<-length(edgesOth[,1])

correctEdges<-0
wrongDirectionEdges<-0
incorrectEdges<-0
missingEdges<-0

listEdgesCor<-paste(edgesCor[,1],edgesCor[,2])
listEdgesOther<-paste(edgesOth[,1],edgesOth[,2])
listEdgesOther2<-paste(edgesOth[,2],edgesOth[,1])

if(noNodesOth>0)
{
for(i in 1:length(listEdgesOther))
{
    if(listEdgesOther[i] %in% listEdgesCor) correctEdges<-correctEdges+1 
    else if(listEdgesOther2[i] %in% listEdgesCor) wrongDirectionEdges<-wrongDirectionEdges+1 
    else
    {
     incorrectEdges<-incorrectEdges+1
      #print(listEdgesOther[i])
    }
}
}


for(i in 1:length(listEdgesCor))
{
    if(!(listEdgesCor[i] %in% listEdgesOther)) missingEdges<-missingEdges+1 
}


c(correctEdges, wrongDirectionEdges, incorrectEdges, missingEdges)

}



plotSomeGraphs<-function(modType, model, perMiss, doRecall, doPrec, doDir, doUndir, plotNo0=1)
{
 plotNo<-plotNo0
 
if(model==1)
{
 correctNet<-"[A][C][E][B|A:C][D|C:E]"
 correctMissNet<-"[A][C][E][B|A:C][D|C:E]"
 correctFullNet<-"[a][c][e][b|a:c][d|c:e]"
 correctRanNet<-"[ar][cr][er][br|ar:cr][dr|cr:er]"
} else if(model==3) {
 correctNet<-"[A][B|A][C|B][D|C][E|D]"
 correctMissNet<-"[A][B|A][C|B][D|C][E|D]"
 correctFullNet<-"[a][b|a][c|b][d|c][e|d]"
 correctRanNet<-"[ar][br|ar][cr|br][dr|cr][er|dr]"
}

trueNet<-calcNoEdges(correctNet, correctNet)
totalTrueEdges<-trueNet[1]

#betas<-c(0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5)
betas<-c(0.1, 0.2, 0.3, 0.4, 0.5)


if(!readSummaries)
{

num<-length(betas)
num2<-length(seeds)

correctFullM<-matrix(0, nrow=num2, ncol=num)
wrongDirFullM<-matrix(0, nrow=num2, ncol=num)
inCorFullM<-matrix(0, nrow=num2, ncol=num)
missFullM<-matrix(0, nrow=num2, ncol=num)
totFull<-rep(0, length(betas))

correctMissM<-matrix(0, nrow=num2, ncol=num)
wrongDirMissM<-matrix(0, nrow=num2, ncol=num)
inCorMissM<-matrix(0, nrow=num2, ncol=num)
missMissM<-matrix(0, nrow=num2, ncol=num)
totMiss<-rep(0, length(betas))

correctImpM<-matrix(0, nrow=num2, ncol=num)
wrongDirImpM<-matrix(0, nrow=num2, ncol=num)
inCorImpM<-matrix(0, nrow=num2, ncol=num)
missImpM<-matrix(0, nrow=num2, ncol=num)
totImp<-rep(0, length(betas))

correctImpRTM<-matrix(0, nrow=num2, ncol=num)
wrongDirImpRTM<-matrix(0, nrow=num2, ncol=num)
inCorImpRTM<-matrix(0, nrow=num2, ncol=num)
missImpRTM<-matrix(0, nrow=num2, ncol=num)
totImpRT<-rep(0, length(betas))

correctRanM<-matrix(0, nrow=num2, ncol=num)
wrongDirRanM<-matrix(0, nrow=num2, ncol=num)
inCorRanM<-matrix(0, nrow=num2, ncol=num)
missRanM<-matrix(0, nrow=num2, ncol=num)
totRan<-rep(0, length(betas))

correctEMM<-matrix(0, nrow=num2, ncol=num)
wrongDirEMM<-matrix(0, nrow=num2, ncol=num)
inCorEMM<-matrix(0, nrow=num2, ncol=num)
missEMM<-matrix(0, nrow=num2, ncol=num)
totEM<-rep(0, length(betas))


for(i in 1:num)
{
  bet<-betas[i]
  
  for(s in 1:num2)
  {
    #seed<-seeds[s]

  dirStr<-paste("results5Vars",modType,"2-",model,"-",perMiss,sep="")
 
  filename<-paste(dirStr,"/res",modType,"Imp-",bet,"-",perMiss,"-2000-",s,".dat", sep="")
  #if(doBreak && !file.exists(filename)) break
  if(file.exists(filename))
  {
   aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
   calcs<-calcNoEdges(correctNet, aNet)
   correctImpM[s,i]<-calcs[1]
   wrongDirImpM[s,i]<-calcs[2]
   inCorImpM[s,i]<-calcs[3]
   missImpM[s,i]<-calcs[4]
   totImp[i]<-totImp[i]+1
  }
  
  if(plotImpRT)
  {
    filename<-paste(dirStr,"/res",modType,"ImpRT-",bet,"-",perMiss,"-2000-",s,".dat", sep="")
    #if(doBreak && !file.exists(filename)) break
    if(file.exists(filename))
    {
    aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
    calcs<-calcNoEdges(correctNet, aNet)
    correctImpRTM[s,i]<-calcs[1]
    wrongDirImpRTM[s,i]<-calcs[2]
    inCorImpRTM[s,i]<-calcs[3]
    missImpRTM[s,i]<-calcs[4]
    totImpRT[i]<-totImpRT[i]+1  
    }
  }
  
  filename<-paste(dirStr,"/res",modType,"Full-",bet,"-",perMiss,"-2000-",s,".dat", sep="")
  #if(doBreak && !file.exists(filename)) break
  if(file.exists(filename))
  {
  aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
  calcs<-calcNoEdges(correctFullNet, aNet) 
  correctFullM[s,i]<-calcs[1]
  wrongDirFullM[s,i]<-calcs[2]
  inCorFullM[s,i]<-calcs[3]
  missFullM[s,i]<-calcs[4]
  totFull[i]<-totFull[i]+1
  }
  
  filename<-paste(dirStr,"/res",modType,"Miss-",bet,"-",perMiss,"-2000-",s,".dat", sep="")
  #if(doBreak && !file.exists(filename)) break
  if(file.exists(filename))
  {
  aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
  calcs<-calcNoEdges(correctMissNet, aNet)
  correctMissM[s,i]<-calcs[1]
  wrongDirMissM[s,i]<-calcs[2]
  inCorMissM[s,i]<-calcs[3]
  missMissM[s,i]<-calcs[4]
  totMiss[i]<-totMiss[i]+1
  }
  
  filename<-paste(dirStr,"/res",modType,"RanImp-",bet,"-",perMiss,"-2000-",s,".dat", sep="")
  #if(doBreak && !file.exists(filename)) break
  if(file.exists(filename))
  {
  aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
  calcs<-calcNoEdges(correctRanNet, aNet)
  correctRanM[s,i]<-calcs[1]
  wrongDirRanM[s,i]<-calcs[2]
  inCorRanM[s,i]<-calcs[3]
  missRanM[s,i]<-calcs[4]
  totRan[i]<-totRan[i]+1
  }
   
  filename<-paste(dirStr,"/res",modType,"EM-",bet,"-",perMiss,"-2000-",s,".dat", sep="")
  #if(doBreak && !file.exists(filename)) break
  if(file.exists(filename))
  {
  
  if(file.size(filename)>1) #check there are some edges
  {
   aNet<-read.table(filename, stringsAsFactors=FALSE)
  } else {
   aNet<-c()
  }
  
  if(length(aNet) > 0 && dim(aNet)[1]==2 && dim(aNet)[2]==1)
  {
   arcs<-as.data.frame(cbind(c(aNet[1,1]), c(aNet[2,1]))) ##switch if error in one arc being in first column 
  } else {
   arcs<-aNet
  } 
  calcs<-calcNoEdges(correctMissNet, "EM", arcs)
  correctEMM[s,i]<-calcs[1]
  wrongDirEMM[s,i]<-calcs[2]
  inCorEMM[s,i]<-calcs[3]
  missEMM[s,i]<-calcs[4]
  totEM[i]<-totEM[i]+1
  }
  
  }##end seed


} ##end beta

totals<-rbind(totFull, totMiss, totImp, totImpRT, totRan, totEM)
colnames(totals)<-betas
rownames(totals)<-c("Full", "Miss", "Imp", "ImpRT", "Ran", "EM")
write.table(totals, paste(figpath,"totals-",model,"-",perMiss,".dat", sep=""), row.names=TRUE, col.names=TRUE, quote=FALSE)

correctFull<-colMeans(correctFullM)*(num2/totFull)
wrongDirFull<-colMeans(wrongDirFullM)*(num2/totFull)
inCorFull<-colMeans(inCorFullM)*(num2/totFull)
missFull<-colMeans(missFullM)*(num2/totFull)

correctMiss<-colMeans(correctMissM)*(num2/totMiss)
wrongDirMiss<-colMeans(wrongDirMissM)*(num2/totMiss)
inCorMiss<-colMeans(inCorMissM)*(num2/totMiss)
missMiss<-colMeans(missMissM)*(num2/totMiss)

correctImp<-colMeans(correctImpM)*(num2/totImp)
wrongDirImp<-colMeans(wrongDirImpM)*(num2/totImp)
inCorImp<-colMeans(inCorImpM)*(num2/totImp)
missImp<-colMeans(missImpM)*(num2/totImp)

correctImpRT<-colMeans(correctImpRTM)*(num2/totImpRT)
wrongDirImpRT<-colMeans(wrongDirImpRTM)*(num2/totImpRT)
inCorImpRT<-colMeans(inCorImpRTM)*(num2/totImpRT)
missImpRT<-colMeans(missImpRTM)*(num2/totImpRT)

correctRan<-colMeans(correctRanM)*(num2/totRan)
wrongDirRan<-colMeans(wrongDirRanM)*(num2/totRan)
inCorRan<-colMeans(inCorRanM)*(num2/totRan)
missRan<-colMeans(missRanM)*(num2/totRan)

correctEM<-colMeans(correctEMM)*(num2/totEM)
wrongDirEM<-colMeans(wrongDirEMM)*(num2/totEM)
inCorEM<-colMeans(inCorEMM)*(num2/totEM)
missEM<-colMeans(missEMM)*(num2/totEM)

if(writeSummaries)
{
 summaries<-cbind(correctFull, wrongDirFull, inCorFull, missFull,
  correctMiss, wrongDirMiss, inCorMiss, missMiss,
  correctImp, wrongDirImp, inCorImp, missImp,
  correctImpRT, wrongDirImpRT, inCorImpRT, missImpRT,
  correctRan, wrongDirRan, inCorRan, missRan,
  correctEM, wrongDirEM, inCorEM, missEM )

  sumFile<-paste(figpath,"summary-",modType, model, perMiss, doRecall, doPrec, doDir, doUndir,".dat",sep="")
  
  write.table(summaries, sumFile, row.names=FALSE, col.names=TRUE, quote=FALSE)

}

} else {

  sumFile<-paste(figpath,"summary-",modType, model, perMiss, doRecall, doPrec, doDir, doUndir,".dat",sep="")
  
  summaries<-read.table(sumFile, header=TRUE)
  
  correctFull<-summaries[,1]
  wrongDirFull<-summaries[,2]
  inCorFull<-summaries[,3]
  missFull<-summaries[,4]
  correctMiss<-summaries[,5]
  wrongDirMiss<-summaries[,6]
  inCorMiss<-summaries[,7]
  missMiss<-summaries[,8]
  correctImp<-summaries[,9]
  wrongDirImp<-summaries[,10]
  inCorImp<-summaries[,11]
  missImp<-summaries[,12]
  correctImpRT<-summaries[,13]
  wrongDirImpRT<-summaries[,14]
  inCorImpRT<-summaries[,15]
  missImpRT<-summaries[,16]
  correctRan<-summaries[,17]
  wrongDirRan<-summaries[,18]
  inCorRan<-summaries[,19]
  missRan<-summaries[,20]  
  correctEM<-summaries[,21]
  wrongDirEM<-summaries[,22]
  inCorEM<-summaries[,23]
  missEM<-summaries[,24]

} #end read summaries or not above



#maxCor<-4

#if(png==1) png(paste(figpath,"plotLarge3-correct.png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")


###############################################

seedName<-paste(seeds[1],"-",seeds[length(seeds)],sep="")


if(model==1 && perMiss==0) modelExp<-bquote(A %->% B^"*" %<-% C %->% D^"*" %<-% E) 
else if(model==1 && perMiss==1) modelExp<-bquote(A^"*" %->% B %<-% C %->% D %<-% E^"*") 
else if(model==3 && perMiss==0) modelExp<-bquote(A %->% B^"*" %->% C %->% D^"*" %->% E) 
else if(model==3 && perMiss==1) modelExp<-bquote(A^"*" %->% B %->% C %->% D %->% E^"*") 
else if(model==1) modelExp<-bquote(paste(A^"*" %->% B^"*" %<-% C^"*" %->% D^"*" %<-% E^"*", "(",.(perMiss),"%)"))
else if(model==3) modelExp<-bquote(paste(A^"*" %->% B^"*" %->% C^"*" %->% D^"*" %->% E^"*", "(",.(perMiss),"%)"))
else modelExp<-""
 
if(doRecall && doDir)
{
 plotLetter<-paste0("(",letters[plotNo],")")
 
 Lines <- list(bquote(paste(.(plotLetter) , " Recall")), modelExp) #- Directed

 #do recall
 plot(betas, correctFull/totalTrueEdges, ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="recall", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab)
 if(plotImpRT) points(betas, correctImpRT/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
 points(betas, correctImp/totalTrueEdges, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex) 
 points(betas, correctMiss/totalTrueEdges, type="b", col=cols[4], lty=ltys[4], pch=pchs[4],  lwd=lwd, cex=cex)
 points(betas, correctRan/totalTrueEdges, type="b", col=cols[5], lty=ltys[5], pch=pchs[5], lwd=lwd, cex=cex)
 points(betas, correctEM/totalTrueEdges, type="b", col=cols[6], lty=ltys[6], pch=pchs[6], lwd=lwd, cex=cex)
 
 mtext(do.call(expression, Lines),side=3,line=c(2,0), cex=cex.main)
 
 legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

 plotNo<-plotNo+1
}

if(doPrec && doDir)
{
plotLetter<-paste0("(",letters[plotNo],")")
 
 Lines <- list(bquote(paste(.(plotLetter) , " Precision")), modelExp) #- Directed
             
              
##do precision - directed
plot(betas, correctFull/(correctFull + wrongDirFull + inCorFull), ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="precision", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab)
if(plotImpRT) points(betas, correctImpRT/(correctImpRT + wrongDirImpRT + inCorImpRT), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex) 
points(betas, correctImp/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
points(betas, correctMiss/(correctMiss + wrongDirMiss + inCorMiss), type="b", col=cols[4], lty=ltys[4], pch=pchs[4],  lwd=lwd, cex=cex)
points(betas, correctRan/(correctRan + wrongDirRan + inCorRan), type="b", col=cols[5], lty=ltys[5], pch=pchs[5], lwd=lwd, cex=cex)
points(betas, correctEM/(correctEM + wrongDirEM + inCorEM), type="b", col=cols[6], lty=ltys[6], pch=pchs[6], lwd=lwd, cex=cex)
legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

 mtext(do.call(expression, Lines),side=3,line=c(2,0), cex=cex.main)

 plotNo<-plotNo+1
}

if(doRecall && doUndir)
{
plotLetter<-paste0("(",letters[plotNo],")")
 
 Lines <- list(bquote(paste(.(plotLetter) , " Recall")), modelExp)
            
              
#do recall - undirected
plot(betas, (correctFull+wrongDirFull)/totalTrueEdges, ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="recall", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab)
if(plotImpRT) points(betas, (correctImpRT+wrongDirImpRT)/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
points(betas, (correctImp+wrongDirImp)/totalTrueEdges, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)                   
points(betas, (correctMiss+wrongDirMiss)/totalTrueEdges, type="b", col=cols[4], lty=ltys[4], pch=pchs[4],  lwd=lwd, cex=cex)
points(betas, (correctRan+wrongDirRan)/totalTrueEdges, type="b", col=cols[5], lty=ltys[5], pch=pchs[5], lwd=lwd, cex=cex)
points(betas, (correctEM+wrongDirEM)/totalTrueEdges, type="b", col=cols[6], lty=ltys[6], pch=pchs[6], lwd=lwd, cex=cex)
legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

 mtext(do.call(expression, Lines),side=3,line=c(2,0), cex=cex.main)

 plotNo<-plotNo+1
}

if(doPrec && doUndir)
{
plotLetter<-paste0("(",letters[plotNo],")")
 
 Lines <- list(bquote(paste(.(plotLetter) , " Precision")), modelExp)
            
              
##do precision - undirected
plot(betas, (correctFull+wrongDirFull)/(correctFull + wrongDirFull + inCorFull), ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="precision", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab)
if(plotImpRT) points(betas, (correctImpRT+wrongDirImpRT)/(correctImpRT + wrongDirImpRT + inCorImpRT), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
points(betas, (correctImp+wrongDirImp)/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
points(betas, (correctMiss+wrongDirMiss)/(correctMiss + wrongDirMiss + inCorMiss), type="b", col=cols[4], lty=ltys[4], pch=pchs[4],  lwd=lwd, cex=cex)
points(betas, (correctRan+wrongDirRan)/(correctRan + wrongDirRan + inCorRan), type="b", col=cols[5], lty=ltys[5], pch=pchs[5], lwd=lwd, cex=cex)
points(betas, (correctEM+wrongDirEM)/(correctEM + wrongDirEM + inCorEM), type="b", col=cols[6], lty=ltys[6], pch=pchs[6], lwd=lwd, cex=cex)
legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)
 mtext(do.call(expression, Lines),side=3,line=c(2,0), cex=cex.main)

 plotNo<-plotNo+1
}

 plotNo
} ##end doSomePlots

startPlots<-function(plotFilename, layout0=c(2,2))
{
 if(png==2) postscript(paste(figpath,plotFilename,".eps",sep=""), width=12, height=12, bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

 #par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))
 if(png==1) png(paste(figpath,plotFilename,".png",sep=""), width = 800, height = 800, units = "px", pointsize = 12, bg = "white")

 #par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))
 if(png==1) par(mfrow=layout0, mar=c(5.1, 5.1, 4.1, 2.1)) else par(mfrow=layout0) #, mar=c(2.0, 2.0, 5.0, 2.0))

}

#plotSomeGraphs(modType, model, perMiss, doRecall, doPrec, doDir, doUndir)

if(doPlot1)
{
 startPlots("fig-nodes5-cts1-dir-v2")   ##yes, in paper
 plotNo<-plotSomeGraphs("Cts", 1, 0, 1, 1, 1, 0)
 plotSomeGraphs("Cts", 1, 1, 1, 1, 1, 0, plotNo)
 dev.off()
}

if(doPlot2)
{
 startPlots("fig-nodes5-cts3-undir-v2") ##yes, in paper
 plotNo<-plotSomeGraphs("Cts", 3, 0, 1, 1, 0, 1)
 plotSomeGraphs("Cts", 3, 1, 1, 1, 0, 1, plotNo)
 dev.off()
}

if(doPlot3)
{
 startPlots("fig-nodes5-dis1-dir2")
 plotNo<-plotSomeGraphs("Dis", 1, 0, 1, 1, 1, 0)
 plotSomeGraphs("Dis", 1, 1, 1, 1, 1, 0, plotNo)
 dev.off()
}
 #plotSomeGraphs(modType, model, perMiss, doRecall, doPrec, doDir, doUndir)

if(doPlot4)
{
 startPlots("fig-nodes5-dis3-undir2")
 plotNo<-plotSomeGraphs("Dis", 3, 0, 1, 1, 0, 1)
 plotSomeGraphs("Dis", 3, 1, 1, 1, 0, 1, plotNo)
 dev.off()
}

if(doPlot5)
{
 startPlots("fig-nodes5-cts1-undir2")
 plotNo<-plotSomeGraphs("Cts", 1, 0, 1, 1, 0, 1)
 plotSomeGraphs("Cts", 1, 1, 1, 1, 0, 1, plotNo)
 dev.off()
}

if(doPlot6)
{
 startPlots("fig-nodes5-dis1-undir2")
 plotNo<-plotSomeGraphs("Dis", 1, 0, 1, 1, 0, 1)
 plotSomeGraphs("Dis", 1, 1, 1, 1, 0, 1, plotNo)
 dev.off()
}
#plotSomeGraphs(modType, model, perMiss, doRecall, doPrec, doDir, doUndir)

if(doPlot7)
{
 startPlots("fig-nodes5-cts13-20per2")
 plotNo<-plotSomeGraphs("Cts", 1, 20, 1, 1, 1, 0)
 plotSomeGraphs("Cts", 3, 20, 1, 1, 0, 1, plotNo)
 dev.off()
}

if(doPlot8)
{
 #startPlots("fig-nodes5-cts3-undir-20per")
 #plotNo<-plotSomeGraphs("Cts", 3, 20, 1, 1, 0, 1)
 #plotSomeGraphs("Cts", 1, 1, 1, 1, 1, 0, plotNo)
 #dev.off()
}
