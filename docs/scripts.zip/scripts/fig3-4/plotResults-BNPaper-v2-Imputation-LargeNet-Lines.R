


#

home<-1    # 0 = at work, 1 = at home, 2 = linux
png<-2



if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 setwd("/home/nrajh/code/bayesnetty/missingData/large-example3/")
} else if(home == 0) {
 setwd("K:/code/bayesnetty/missingData/large-example3/")
 figpath<-"K:/work-other/tex/bayesNet/"
} else {
 setwd("C:/Users/richa/work/code/bayesnetty/missingData/large-example3/")
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

doimpRT<-TRUE #pthwise imp complete training
doimpCTandRT<-TRUE

#seed1<-1
#seed2<-2
perMiss<-20
seeds<-21:30 #1:10 #1:8
png<-2 #2 #0#1

xlab=expression(beta)
ylab="number of edges"
#cex=3
#lwd=3
#cex.axis=5
#cex.lab=5
#cex.main=5

cex=1.5#3
lwd=1.5#3
cex.axis=1.5#5
cex.lab=1.5#5
cex.main=2#5
#bottom, left, top, and right
#mar=c(5.1, 4.1, 4.1, 2.1)  #+ c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
#mgp=c(3,1,0) # + c(4,1.5,0)

cexleg<-1.5#1.1#4
labcex<-3#1.5#3


#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1)  + c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(4,1.5,0)

cols<-c("green", "red", "red", "orange")
pchs<-c(19, 10, 1, 3)
ltys<-c(1, 1, 2, 1)
leg=c("Full", "Imputed", "Reduced", "Random")
nudge<-0

if(doimpCTandRT)
{

 cols<-c("green", "red", "magenta", "red", "orange")
 pchs<-c(19, 10, 7, 1, 3)
 ltys<-c(1, 1, 1, 2, 1)
 leg=c("Full", "Imputed", "Imputed CT", "Reduced", "Random")
 nudge<-1

}

#cexleg<-4
#labcex<-3

correctNet<-"correctNet.dat"
#dir<-"results0pt4/"
#dir<-"results0.5-8/"


calcNoEdges<-function(dir, correctNet, otherNet0)
{

#correctNet<-paste("results",notMiss,"-",bet,"/",correctNet0,sep="")

otherNet<-paste(dir,otherNet0,sep="")

##get correct network edges
noNodesCor<-length(t(unique(read.table(correctNet, header=FALSE))))
edgesCor<-read.table(correctNet, header=FALSE, colClasses=c("character", "character"), skip=noNodesCor, stringsAsFactors=FALSE)

##get other network edges
noNodesOth<-length(t(unique(read.table(otherNet, header=FALSE))))
edgesOth<-read.table(otherNet, header=FALSE, colClasses=c("character", "character"), skip=noNodesOth, stringsAsFactors=FALSE)

correctEdges<-0
wrongDirectionEdges<-0
incorrectEdges<-0
missingEdges<-0

listEdgesCor<-paste(edgesCor[,1],edgesCor[,2])
listEdgesOther<-paste(edgesOth[,1],edgesOth[,2])
listEdgesOther2<-paste(edgesOth[,2],edgesOth[,1])


for(i in 1:length(listEdgesOther))
{
    if(listEdgesOther[i] %in% listEdgesCor) correctEdges<-correctEdges+1 
    else if(listEdgesOther2[i] %in% listEdgesCor) wrongDirectionEdges<-wrongDirectionEdges+1 
    else
    {
     incorrectEdges<-incorrectEdges+1
      #print(listEdgesOther[i])
    }
}

for(i in 1:length(listEdgesCor))
{
    if(!(listEdgesCor[i] %in% listEdgesOther)) missingEdges<-missingEdges+1 
}


c(correctEdges, wrongDirectionEdges, incorrectEdges, missingEdges)

}




#print("c(correctEdges, wrongDirectionEdges, incorrectEdges, missingEdges)")

#calcNoEdges("", correctNet, correctNet)

#calcNoEdges(dir, correctNet, "fittedNetFull.dat")

#calcNoEdges(dir, correctNet, "fittedNetMiss.dat")

#calcNoEdges(dir, correctNet, "fittedNetImp.dat")

trueNet<-calcNoEdges("", correctNet, correctNet)
totalTrueEdges<-trueNet[1]

betas<-c(0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5)

num<-length(betas)
num2<-length(seeds)

correctFullM<-matrix(0, nrow=num2, ncol=num)
wrongDirFullM<-matrix(0, nrow=num2, ncol=num)
inCorFullM<-matrix(0, nrow=num2, ncol=num)
missFullM<-matrix(0, nrow=num2, ncol=num)

correctMissM<-matrix(0, nrow=num2, ncol=num)
wrongDirMissM<-matrix(0, nrow=num2, ncol=num)
inCorMissM<-matrix(0, nrow=num2, ncol=num)
missMissM<-matrix(0, nrow=num2, ncol=num)

correctImpM<-matrix(0, nrow=num2, ncol=num)
wrongDirImpM<-matrix(0, nrow=num2, ncol=num)
inCorImpM<-matrix(0, nrow=num2, ncol=num)
missImpM<-matrix(0, nrow=num2, ncol=num)

correctImpRTM<-matrix(0, nrow=num2, ncol=num)
wrongDirImpRTM<-matrix(0, nrow=num2, ncol=num)
inCorImpRTM<-matrix(0, nrow=num2, ncol=num)
missImpRTM<-matrix(0, nrow=num2, ncol=num)

correctRanM<-matrix(0, nrow=num2, ncol=num)
wrongDirRanM<-matrix(0, nrow=num2, ncol=num)
inCorRanM<-matrix(0, nrow=num2, ncol=num)
missRanM<-matrix(0, nrow=num2, ncol=num)

for(s in 1:num2)
{

seed<-seeds[s]


for(i in 1:num)
{
  dirStr<-paste("resultsPaperRedo",betas[i],"-",perMiss,"-",seed,"/",sep="")
  
  calcs<-calcNoEdges(dirStr, correctNet, "fittedNetImp.dat")
  correctImpM[s,i]<-calcs[1]
  wrongDirImpM[s,i]<-calcs[2]
  inCorImpM[s,i]<-calcs[3]
  missImpM[s,i]<-calcs[4]
  
  calcs<-calcNoEdges(dirStr, correctNet, "fittedNetImpRT.dat")
  correctImpRTM[s,i]<-calcs[1]
  wrongDirImpRTM[s,i]<-calcs[2]
  inCorImpRTM[s,i]<-calcs[3]
  missImpRTM[s,i]<-calcs[4]
  
  calcs<-calcNoEdges(dirStr, correctNet, "fittedNetFull.dat")
  correctFullM[s,i]<-calcs[1]
  wrongDirFullM[s,i]<-calcs[2]
  inCorFullM[s,i]<-calcs[3]
  missFullM[s,i]<-calcs[4]

  calcs<-calcNoEdges(dirStr, correctNet, "fittedNetMiss.dat")
  correctMissM[s,i]<-calcs[1]
  wrongDirMissM[s,i]<-calcs[2]
  inCorMissM[s,i]<-calcs[3]
  missMissM[s,i]<-calcs[4]
  
  calcs<-calcNoEdges(dirStr, correctNet, "fittedNetRandom.dat")
  correctRanM[s,i]<-calcs[1]
  wrongDirRanM[s,i]<-calcs[2]
  inCorRanM[s,i]<-calcs[3]
  missRanM[s,i]<-calcs[4]
}

} ##end seed


correctFull<-colMeans(correctFullM)
wrongDirFull<-colMeans(wrongDirFullM)
inCorFull<-colMeans(inCorFullM)
missFull<-colMeans(missFullM)

correctMiss<-colMeans(correctMissM)
wrongDirMiss<-colMeans(wrongDirMissM)
inCorMiss<-colMeans(inCorMissM)
missMiss<-colMeans(missMissM)

correctImp<-colMeans(correctImpM)
wrongDirImp<-colMeans(wrongDirImpM)
inCorImp<-colMeans(inCorImpM)
missImp<-colMeans(missImpM)

correctImpRT<-colMeans(correctImpRTM)
wrongDirImpRT<-colMeans(wrongDirImpRTM)
inCorImpRT<-colMeans(inCorImpRTM)
missImpRT<-colMeans(missImpRTM)

correctRan<-colMeans(correctRanM)
wrongDirRan<-colMeans(wrongDirRanM)
inCorRan<-colMeans(inCorRanM)
missRan<-colMeans(missRanM)

maxCor<-29

#if(png==1) png(paste(figpath,"plotLarge3-correct.png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")


if(FALSE)
{
 
if(png==1) png(paste(figpath,"fig-largeNetImputation-Lines",perMiss,".png",sep=""), width = 1200*2, height = 1200*2, units = "px", pointsize = 12, bg = "white")
if(png==2) postscript(paste(figpath,"fig-largeNetImputation-Lines",perMiss,".eps",sep=""), height=12, width=12,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

#par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))

par(mfrow=c(2,2), par(mar=mar, mgp=mgp)) #, mar=c(2.0, 2.0, 5.0, 2.0))

plot(betas, correctFull, ylim=c(0,29), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab=ylab, lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="Correct Edges")

points(betas, correctImp, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)

points(betas, correctMiss, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)

points(betas, correctRan, type="b", col=cols[4], lty=ltys[4], pch=pchs[4], lwd=lwd, cex=cex)

legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

#if(png>0) dev.off()

#if(png==1) png(paste(figpath,"plotLarge3-missing.png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")
#par(mar=mar, mgp=mgp)

plot(betas, missFull, ylim=c(0,29), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab=ylab, lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="Missing Edges")

points(betas, missImp, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)

points(betas, missMiss, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)

points(betas, missRan, type="b", col=cols[4], lty=ltys[4], pch=pchs[4], lwd=lwd, cex=cex)

legend("topright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)
#if(png>0) dev.off()

#if(png==1) png(paste(figpath,"plotLarge3-incorrect.png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")
#par(mar=mar, mgp=mgp)

plot(betas, inCorFull, ylim=c(0,29), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab=ylab, lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="Incorrect Edges")

points(betas, inCorImp, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)

points(betas, inCorMiss, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)

points(betas, inCorRan, type="b", col=cols[4], lty=ltys[4], pch=pchs[4], lwd=lwd, cex=cex)

legend("topright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)
#if(png>0) dev.off()

#if(png==1) png(paste(figpath,"plotLarge3-wrongDir.png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")
#par(mar=mar, mgp=mgp)

plot(betas, wrongDirFull, ylim=c(0,29), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab=ylab, lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="Backwards Edges")

points(betas, wrongDirImp, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)

points(betas, wrongDirMiss, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)

points(betas, wrongDirRan, type="b", col=cols[4], lty=ltys[4], pch=pchs[4], lwd=lwd, cex=cex)

legend("topright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

if(png>0) dev.off()

} ##end skipping these plots

###############################################

seedName<-paste(seeds[1],"-",seeds[length(seeds)],"-",perMiss,sep="")

if(png==1) png(paste(figpath,"fig-largeNetImp-Recall-etc-",seedName,"-v3.png",sep=""), width = 1200*2, height = 1200*2, units = "px", pointsize = 12, bg = "white")
if(png==2) postscript(paste(figpath,"fig-largeNetImp-Recall-etc-",seedName,"-v3.eps",sep=""), width=12, height=6, bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

#par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))

par(mfrow=c(1,2))#, par(mar=mar, mgp=mgp)) #, mar=c(2.0, 2.0, 5.0, 2.0))

#do recall
plot(betas, correctFull/totalTrueEdges, ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="recall", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="(a) Recall", cex.main=cex.main)
if(doimpCTandRT) {
 points(betas, correctImpRT/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
 points(betas, correctImp/totalTrueEdges, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
} else {
 if(doimpRT) points(betas, correctImpRT/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex) else points(betas, correctImp/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
}
points(betas, correctMiss/totalTrueEdges, type="b", col=cols[3+nudge], lty=ltys[3+nudge], pch=pchs[3+nudge], lwd=lwd, cex=cex)
points(betas, correctRan/totalTrueEdges, type="b", col=cols[4+nudge], lty=ltys[4+nudge], pch=pchs[4+nudge], lwd=lwd, cex=cex)
legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

#do recall - undirected
#plot(betas, (correctFull+wrongDirFull)/totalTrueEdges, ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="recall", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="(b) Recall - Undirected", cex.main=cex.main)
#if(doimpRT) points(betas, (correctImpRT+wrongDirImpRT)/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex) else points(betas, (correctImp+wrongDirImp)/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
#points(betas, (correctMiss+wrongDirMiss)/totalTrueEdges, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
#points(betas, (correctRan+wrongDirRan)/totalTrueEdges, type="b", col=cols[4], lty=ltys[4], pch=pchs[4], lwd=lwd, cex=cex)
#legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)


##do precision
plot(betas, correctFull/(correctFull + wrongDirFull + inCorFull), ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="precision", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="(b) Precision", cex.main=cex.main)
if(doimpCTandRT) {
  points(betas, correctImpRT/(correctImpRT + wrongDirImpRT + inCorImpRT), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
  points(betas, correctImp/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
} else {
if(doimpRT) points(betas, correctImpRT/(correctImpRT + wrongDirImpRT + inCorImpRT), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex) else points(betas, correctImp/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
}
points(betas, correctMiss/(correctMiss + wrongDirMiss + inCorMiss), type="b", col=cols[3+nudge], lty=ltys[3+nudge], pch=pchs[3+nudge], lwd=lwd, cex=cex)
points(betas, correctRan/(correctRan + wrongDirRan + inCorRan), type="b", col=cols[4+nudge], lty=ltys[4+nudge], pch=pchs[4+nudge], lwd=lwd, cex=cex)
legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

##do precision - undirected
#plot(betas, (correctFull+wrongDirFull)/(correctFull + wrongDirFull + inCorFull), ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="precision", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="(d) Precision - Undirected", cex.main=cex.main)
#if(doimpRT) points(betas, (correctImpRT+wrongDirImpRT)/(correctImpRT + wrongDirImpRT + inCorImpRT), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex) else points(betas, (correctImp+wrongDirImp)/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
#points(betas, (correctMiss+wrongDirMiss)/(correctMiss + wrongDirMiss + inCorMiss), type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
#points(betas, (correctRan+wrongDirRan)/(correctRan + wrongDirRan + inCorRan), type="b", col=cols[4], lty=ltys[4], pch=pchs[4], lwd=lwd, cex=cex)
#legend("bottomright", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

if(FALSE)
{
plotNums<-FALSE
##do precision-recall
plot(correctFull/totalTrueEdges, correctFull/(correctFull + wrongDirFull + inCorFull), ylim=c(0,1), xlim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab="recall", ylab="precision", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="Precision-Recall - Directed", cex.main=cex.main)
if(plotNums) text(correctFull/totalTrueEdges, correctFull/(correctFull + wrongDirFull + inCorFull), labels=betas, cex=labcex, pos=c(2,4))
points(correctImp/totalTrueEdges, correctImp/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
if(plotNums) text(correctImp/totalTrueEdges, correctImp/(correctImp + wrongDirImp + inCorImp), labels=betas, cex= labcex, pos=c(2,4))
points(correctMiss/totalTrueEdges, correctMiss/(correctMiss + wrongDirMiss + inCorMiss), type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
if(plotNums) text(correctMiss/totalTrueEdges, correctMiss/(correctMiss + wrongDirMiss + inCorMiss), labels=betas, cex= labcex, pos=c(2,4))
points(correctRan/totalTrueEdges, correctRan/(correctRan + wrongDirRan + inCorRan), type="b", col=cols[4], lty=ltys[4], pch=pchs[4], lwd=lwd, cex=cex)
if(plotNums) text(correctRan/totalTrueEdges, correctRan/(correctRan + wrongDirRan + inCorRan), labels=betas, cex= labcex, pos=c(2,4))
legend("topleft", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)

##do precision-recall - undirected
plot((correctFull+wrongDirFull)/totalTrueEdges, (correctFull+wrongDirFull)/(correctFull + wrongDirFull + inCorFull), ylim=c(0,1), xlim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab="recall", ylab="precision", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, main="Precision-Recall - Undirected", cex.main=cex.main)
if(plotNums) text((correctFull+wrongDirFull)/totalTrueEdges, (correctFull+wrongDirFull)/(correctFull + wrongDirFull + inCorFull), labels=betas, cex=labcex, pos=c(2,4))
points((correctImp+wrongDirImp)/totalTrueEdges, (correctImp+wrongDirImp)/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
if(plotNums) text((correctImp+wrongDirImp)/totalTrueEdges, (correctImp+wrongDirImp)/(correctImp + wrongDirImp + inCorImp), labels=betas, cex= labcex, pos=c(2,4))
points((correctMiss+wrongDirMiss)/totalTrueEdges, (correctMiss+wrongDirMiss)/(correctMiss + wrongDirMiss + inCorMiss), type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
if(plotNums) text((correctMiss+wrongDirMiss)/totalTrueEdges, (correctMiss+wrongDirMiss)/(correctMiss + wrongDirMiss + inCorMiss), labels=betas, cex= labcex, pos=c(2,4))
points((correctRan+wrongDirRan)/totalTrueEdges, (correctRan+wrongDirRan)/(correctRan + wrongDirRan + inCorRan), type="b", col=cols[4], lty=ltys[4], pch=pchs[4], lwd=lwd, cex=cex)
if(plotNums) text((correctRan+wrongDirRan)/totalTrueEdges, (correctRan+wrongDirRan)/(correctRan + wrongDirRan + inCorRan), labels=betas, cex= labcex, pos=c(2,4))
legend("topleft", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)
} ##end skip precision-recall

if(png>0) dev.off()




