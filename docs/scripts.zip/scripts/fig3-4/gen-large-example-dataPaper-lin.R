
#R --vanilla --args beta < gen-large-example-dataPaper-lin.R

#set.seed(1)

args = commandArgs()

##sim SNPs

#runif(20,0,1)/2

##number of individuals

n<-2000
noSNPs<-20

##MAFs
mafs<-c(0.16691254, 0.07011743, 0.28222913, 0.41838539, 0.15133425, 0.37865592, 0.20021126, 0.19363299, 0.44987123, 0.17830383, 0.02, 0.13073993, 0.03, 0.03882063, 0.25120755, 0.5, 0.14244884, 0.48245434, 0.21392564, 0.09950864)


lastOK<-n*0.1

#lastOK<-999

bet<-as.numeric(args[4])
perMiss<-as.numeric(args[5])
seed<-as.numeric(args[6])


set.seed(seed)

##bet<-0.1


snpBetas<-rep(bet, noSNPs)

betaVal<-bet

betaAB<-betaVal

betaAX<-betaVal
betaBX<-betaVal
betaCX<-betaVal
betaDX<-betaVal

betaef<-betaVal
betaXe<-betaVal
betaXf<-betaVal
betaXg<-betaVal
betaXh<-betaVal

##sim SNPs
dataSNPs<-matrix(0, ncol=noSNPs, nrow=n)

for(i in 1:noSNPs)
{
 dataSNPs[,i]<-rbinom(n, 2, mafs[i])
}


exA<-rnorm(n, 10 + snpBetas[1]*dataSNPs[,1] + snpBetas[2]*dataSNPs[,2], 1)

exB<-rnorm(n, 10 + snpBetas[3]*dataSNPs[,3] + snpBetas[4]*dataSNPs[,4], 1)

exC<-rnorm(n, 10 + snpBetas[5]*dataSNPs[,5] + snpBetas[6]*dataSNPs[,6], 1)

exD<-rnorm(n, 10 + snpBetas[6]*dataSNPs[,6] + snpBetas[7]*dataSNPs[,7], 1)


traitX<-rnorm(n, 10 + betaAX * exA + betaBX * exB + betaCX * exC + betaDX * exD + snpBetas[19]*dataSNPs[,19] + snpBetas[20]*dataSNPs[,20], 1)

exe<-rnorm(n, 10 + betaXe * traitX + snpBetas[8]*dataSNPs[,8] + snpBetas[9]*dataSNPs[,9], 1)

exf<-rnorm(n, 10 + betaef * exe + snpBetas[10]*dataSNPs[,10] + snpBetas[11]*dataSNPs[,11], 1)

exg<-rnorm(n, 10 + betaXg * traitX + snpBetas[12]*dataSNPs[,12] + snpBetas[13]*dataSNPs[,13], 1)

exh<-rnorm(n, 10 + betaXh * traitX + snpBetas[14]*dataSNPs[,14] + snpBetas[15]*dataSNPs[,15] + snpBetas[16]*dataSNPs[,16], 1)

exN<-rnorm(n, 10 + snpBetas[17]*dataSNPs[,17] + snpBetas[18]*dataSNPs[,18], 1)

exM<-rnorm(n, 10, 1)



allDataSNPs<-cbind(dataSNPs)
varNames<-c("sA1", "sA2", "sB1", "sB2", "sC1", "sCD", "sD2", "se1", "se2", "sf1", "sf2", "sg1", "sg2", "sh1", "sh2", "sh3", "sN1", "sN2", "s1", "s2") 
colnames(allDataSNPs)<-varNames


write.table(allDataSNPs, "exampleLargeDataFull-SNPs.dat", row.names=FALSE, col.names=TRUE, quote=FALSE)


##add 1% missing for SNPs
#for(i in 1:(n*noSNPs)) if(runif(1, 0 , 1) < 0.01) allDataSNPs[i]<-NA

write.table(allDataSNPs, "exampleLargeData-SNPs.dat", row.names=FALSE, col.names=TRUE, quote=FALSE)



allDataOther<-cbind(exA, exB, exC, exD, exe, exf, exg, exh, exN, exM, traitX)
varNamesOther<-c("exA", "exB", "exC", "exD", "exe", "exf", "exg", "exh", "exN", "exM", "trait") 
colnames(allDataOther)<-varNamesOther

write.table(allDataOther, "exampleLargeDataFull-Other.dat", row.names=FALSE, col.names=TRUE, quote=FALSE)


#for(i in (lastOK+1):n)
#{
#  allDataOther[i,1:10]<-NA
#}


if(perMiss==0)
{

 lastblock1<-round((n+lastOK)/2)
 for(i in (lastOK+1):lastblock1)
 {
   allDataOther[i,1:5]<-NA
 }
 
 for(i in (lastblock1+1):n)
 {
   allDataOther[i,6:10]<-NA
 }
 
} else {
 missM<-matrix(0, ncol=10, nrow=n)

 for(nd in 1:10)
 {
  missM[,nd]<-(sample(1:100, n, replace=TRUE) <= perMiss)
  
  #for(k in 1:n) if(missM[k,nd]) allDataOther[k, nd]<-NA 
  allDataOther[(1:n)[missM[,nd]==1], nd]<-NA
}

}


write.table(allDataOther, "exampleLargeData-Other.dat", row.names=FALSE, col.names=TRUE, quote=FALSE)

if(perMiss==0)
{

 for(colu in 1:5)
 {
    allDataOther[(lastOK+1):lastblock1,colu]<-sample(allDataOther[-((lastOK+1):lastblock1),colu], length((lastOK+1):lastblock1), replace=TRUE)
 }
 
 for(colu in 6:10)
 {
    allDataOther[(lastblock1+1):n,colu]<-sample(allDataOther[-((lastblock1+1):n),colu], length((lastblock1+1):n), replace=TRUE)
 }

} else {

 for(nd in 1:10)
 {
  ##for(k in 1:n) if(missM[k,nd]) allDataOther[k, nd]<-sample(allDataOther[-((1:n)[missM[,nd]==1]), nd], 1, replace=TRUE)
  allDataOther[(1:n)[missM[,nd]==1], nd]<-sample(allDataOther[-((1:n)[missM[,nd]==1]), nd], sum(missM[,nd]), replace=TRUE)
}
 

}

 
write.table(allDataOther, "exampleLargeDataRandom-Other.dat", row.names=FALSE, col.names=TRUE, quote=FALSE)

