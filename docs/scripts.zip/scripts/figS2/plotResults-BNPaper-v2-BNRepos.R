

home<-1

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path<-"/home/nrajh/code/bayesnetty/missingData/sims/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path<-"K:/code/bayesnetty/missingData/sims/"
} else {
 path<-"C:/Users/richa/work/code/bayesnetty/missingData/sims/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

seeds<-1:100 #1:100 ##reps
n<-500 #data size

plotEM2<-FALSE #TRUE #FALSE #TRUE extra iters etc
plotImp<-TRUE #FALSE
plotImpRan<-TRUE  #this is random replace for later sims
plotReduced<-TRUE #FALSE

resultsSuffix<-""

writeSummaries<-FALSE #TRUE #TRUE #TRUE #only if not reading summaries
readSummaries<-TRUE

#modType<-"Cts" #"Dis" = discrete; "" = cts
#model<-3
#perMiss<-2 #1 #0

doAllSims<-0 #TRUE #FALSE #FALSE

doPlot1<-1 #ecoli70, insurance, alarm
doPlot2<-1 
doPlot3<-0 
doPlot4<-0 

#doPlot5<-0 
#doPlot6<-0 

#doPlot7<-0 
#doPlot8<-0 

setwd(path)

#seed1<-1
#seed2<-2


png<-2 #0#1


xlab="percentage missing" #expression(beta)
ylab="number of edges"



cex=1.5#3
lwd=1.5#3
cex.axis=1.5*1.2#5
cex.lab=1.5*1.2#5

cex.main=2#5

#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1)  + c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(4,1.5,0)


cexleg<-1.5#1.1#4
labcex<-3#1.5#3


usingPlots<-c(TRUE, plotImpRan, plotImp, plotReduced, TRUE, TRUE, plotEM2)
cols<-c("green", "red", "magenta", "red", "orange", "cyan", "blue")
pchs<-c(19, 10, 7, 1, 3, 4, 2)
ltys<-c(1, 1, 1, 2, 1, 1, 1)
leg=c("Full", "Imputed", "Imputed CT", "Reduced", "Random", "EM", "EM2")[usingPlots]

if(png==1)
{
cex=1.5#3
lwd=1.5#3
cex.axis=2 #1.5#5
cex.lab=2 #1.5#5
cex.main=2#5

cexleg<-1.5#1.1#4
labcex<-3#1.5#3
}

#correctNet<-"correctNet.dat"
#dir<-"results0pt4/"
#dir<-"results0.5-8/"


getEdges<-function(networkStr)
{
 fromNodes<-c()
 toNodes<-c()
 fromNode<-"XXXX"
 toNode<-"XXXX"
 startCharNo<-0
 doingToVar<-FALSE
 
 for(i in 1:nchar(networkStr))
 {
  aChar<-substr(networkStr, i, i)
  if(aChar == "[")
  {
     doingToVar<-TRUE     
     startCharNo<-i+1
  } else if(aChar == ":" || aChar == "|" || aChar == "]") {
     varStr<-substr(networkStr, startCharNo, i-1)
     if(doingToVar)
     {     
      toNode<-varStr     
      doingToVar<-FALSE
     }
     else {
      fromNode<-varStr
      fromNodes<-append(fromNodes, fromNode)
      toNodes<-append(toNodes, toNode) 
     }
     startCharNo<-i+1
  } 
   
  } #end letter loop
      
 cbind(fromNodes, toNodes)
}

getEdgesDirUndir<-function(networkEquivFile)
{
 ##Partially_directed_graph_(PDAG)
 networkStr<-read.table(networkEquivFile, header=TRUE, nrow=1, stringsAsFactors=FALSE)[1,1]
 fromNodesDir<-c()
 toNodesDir<-c()
 fromNodesUndir<-c()
 toNodesUndir<-c()
 fromNode<-"XXXX"
 toNode<-"XXXX"
 startCharNo<-0
 doingToVar<-FALSE
 doingDir<-FALSE
 
 for(i in 1:nchar(networkStr))
 {
  aChar<-substr(networkStr, i, i)
  if(aChar == "(")
  {
     doingToVar<-TRUE     
     startCharNo<-i+1
  } else if(aChar == ":" || aChar == "|" || aChar == "<" || aChar == ")") {
     if(aChar == "<") doingDir<-TRUE
     if(aChar == "|") doingDir<-FALSE
     varStr<-substr(networkStr, startCharNo, i-1)
     if(doingToVar)
     {     
      toNode<-varStr     
      doingToVar<-FALSE
     }
     else {
      fromNode<-varStr
      if(doingDir)
      {
        fromNodesDir<-append(fromNodesDir, fromNode)
        toNodesDir<-append(toNodesDir, toNode) 
      } else {
        fromNodesUndir<-append(fromNodesUndir, fromNode)
        toNodesUndir<-append(toNodesUndir, toNode) 
      }
     }
     startCharNo<-i+1
  } 
   
  } #end letter loop
 
 dirEdges<-cbind(fromNodesDir, toNodesDir)
 undirEdges<-cbind(fromNodesUndir, toNodesUndir)
  
 dirEdges<-dirEdges[!duplicated(paste(dirEdges[,1], dirEdges[,2])),]
 undirEdges<-undirEdges[!duplicated(paste(undirEdges[,1], undirEdges[,2])),]
 
 list(dirEdges = dirEdges, undirEdges = undirEdges)
}


calcNoEdges<-function(correctEdges0, otherNet0, arcs0="")
{

#correctNet<-paste("results",notMiss,"-",bet,"/",correctNet0,sep="")



##get correct network edges
#noNodesCor<-length(t(unique(read.table(correctNet, header=FALSE))))
edgesCor<-correctEdges0 #getEdges(correctNet)
noNodesCor<-length(edgesCor[,1])
#edgesCor<-read.table(correctNet, header=FALSE, colClasses=c("character", "character"), skip=noNodesCor, stringsAsFactors=FALSE)

##get other network edges
#noNodesOth<-length(t(unique(read.table(otherNet, header=FALSE))))
#edgesOth<-read.table(otherNet, header=FALSE, colClasses=c("character", "character"), skip=noNodesOth, stringsAsFactors=FALSE)
if(otherNet0=="EM")
{
 edgesOth<-arcs0
} else {
 edgesOth<-getEdges(otherNet0)
}

noNodesOth<-length(edgesOth[,1])

correctEdges<-0
wrongDirectionEdges<-0
incorrectEdges<-0
missingEdges<-0

listEdgesCor<-paste(edgesCor[,1],edgesCor[,2])
listEdgesOther<-paste(edgesOth[,1],edgesOth[,2])
listEdgesOther2<-paste(edgesOth[,2],edgesOth[,1])

if(noNodesOth>0)
{
for(i in 1:length(listEdgesOther))
{
    if(listEdgesOther[i] %in% listEdgesCor) correctEdges<-correctEdges+1 
    else if(listEdgesOther2[i] %in% listEdgesCor) wrongDirectionEdges<-wrongDirectionEdges+1 
    else
    {
     incorrectEdges<-incorrectEdges+1
      #print(listEdgesOther[i])
    }
}
}


for(i in 1:length(listEdgesCor))
{
    if(!(listEdgesCor[i] %in% listEdgesOther)) missingEdges<-missingEdges+1 
}


c(correctEdges, wrongDirectionEdges, incorrectEdges, missingEdges)

}


calcNoEdgesPDAG<-function(correctEdgesDir0, correctEdgesUndir0, otherNet0, arcs0="")
{

edgesCorDir<-correctEdgesDir0 #getEdges(correctNet)
noNodesCorDir<-length(edgesCorDir[,1])

edgesCorUndir<-correctEdgesUndir0 #getEdges(correctNet)
noNodesCorUndir<-length(edgesCorUndir[,1])

if(otherNet0=="EM")
{
 edgesOth<-arcs0
} else {
 edgesOth<-getEdges(otherNet0)
}

noNodesOth<-length(edgesOth[,1])

correctEdges<-0
wrongDirectionEdges<-0
incorrectEdges<-0
missingEdges<-0

listEdgesCorDir<-paste(edgesCorDir[,1],edgesCorDir[,2])
listEdgesCorUndir<-paste(edgesCorUndir[,1],edgesCorUndir[,2])
listEdgesOther<-paste(edgesOth[,1],edgesOth[,2])
listEdgesOther2<-paste(edgesOth[,2],edgesOth[,1])

if(noNodesOth>0)
{
for(i in 1:length(listEdgesOther))
{
    if(listEdgesOther[i] %in% listEdgesCorDir || listEdgesOther[i] %in% listEdgesCorUndir || listEdgesOther2[i] %in% listEdgesCorUndir) correctEdges<-correctEdges+1 
    else if(listEdgesOther2[i] %in% listEdgesCorDir) wrongDirectionEdges<-wrongDirectionEdges+1 
    else
    {
     incorrectEdges<-incorrectEdges+1
      #print(listEdgesOther[i])
    }
}
}


for(i in 1:length(listEdgesCorDir))
{
    if(!(listEdgesCorDir[i] %in% listEdgesOther)) missingEdges<-missingEdges+1 
}

for(i in 1:length(listEdgesCorUndir))
{
    if(!(listEdgesCorUndir[i] %in% listEdgesOther || listEdgesCorUndir[i] %in% listEdgesOther2)) missingEdges<-missingEdges+1 
}


c(correctEdges, wrongDirectionEdges, incorrectEdges, missingEdges)
}



plotSomeGraphs<-function(model, perMissVec, doRecall, doPrec, doDir, doUndir, plotNo0=1)
{
 plotNo<-plotNo0
 
 if(doDir)
 {
  corEdges<-getEdgesDirUndir(paste("equiv-nets-",model,".dat", sep="")) 
  totalTrueEdges<-dim(corEdges$dirEdges)[1] + dim(corEdges$undirEdges)[1]
 } else {
  correctEdges<-read.table(paste("networkCorArcs-",model,".dat", sep=""), header=FALSE)
  totalTrueEdges<-dim(correctEdges)[1]
  }

 
 
if(!readSummaries)
{

num<-length(perMissVec)
num2<-length(seeds)

correctFullM<-matrix(0, nrow=num2, ncol=num)
wrongDirFullM<-matrix(0, nrow=num2, ncol=num)
inCorFullM<-matrix(0, nrow=num2, ncol=num)
missFullM<-matrix(0, nrow=num2, ncol=num)
totFull<-rep(0, length(perMissVec))

correctMissM<-matrix(0, nrow=num2, ncol=num)
wrongDirMissM<-matrix(0, nrow=num2, ncol=num)
inCorMissM<-matrix(0, nrow=num2, ncol=num)
missMissM<-matrix(0, nrow=num2, ncol=num)
totMiss<-rep(0, length(perMissVec))

correctImpM<-matrix(0, nrow=num2, ncol=num)
wrongDirImpM<-matrix(0, nrow=num2, ncol=num)
inCorImpM<-matrix(0, nrow=num2, ncol=num)
missImpM<-matrix(0, nrow=num2, ncol=num)
totImp<-rep(0, length(perMissVec))

correctImp50M<-matrix(0, nrow=num2, ncol=num)
wrongDirImp50M<-matrix(0, nrow=num2, ncol=num)
inCorImp50M<-matrix(0, nrow=num2, ncol=num)
missImp50M<-matrix(0, nrow=num2, ncol=num)
totImp50<-rep(0, length(perMissVec))

correctRanM<-matrix(0, nrow=num2, ncol=num)
wrongDirRanM<-matrix(0, nrow=num2, ncol=num)
inCorRanM<-matrix(0, nrow=num2, ncol=num)
missRanM<-matrix(0, nrow=num2, ncol=num)
totRan<-rep(0, length(perMissVec))

correctEMM<-matrix(0, nrow=num2, ncol=num)
wrongDirEMM<-matrix(0, nrow=num2, ncol=num)
inCorEMM<-matrix(0, nrow=num2, ncol=num)
missEMM<-matrix(0, nrow=num2, ncol=num)
totEM<-rep(0, length(perMissVec))

correctEM2M<-matrix(0, nrow=num2, ncol=num)
wrongDirEM2M<-matrix(0, nrow=num2, ncol=num)
inCorEM2M<-matrix(0, nrow=num2, ncol=num)
missEM2M<-matrix(0, nrow=num2, ncol=num)
totEM2<-rep(0, length(perMissVec))

dirStr<-paste("results-",model,resultsSuffix,"-",n,sep="")
 
for(i in 1:num)  # missing percents
{
  missingPer<-perMissVec[i]
  
  if(plotImp)
  {
  for(s in 1:num2) #reps
  {
    
   filename<-paste(dirStr,"/resImp-",missingPer,"-",s,".dat", sep="") 
   if(doAllSims || file.exists(filename))
   {
   aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
   if(doDir) calcs<-calcNoEdgesPDAG(corEdges$dirEdges, corEdges$undirEdges, aNet) else calcs<-calcNoEdges(correctEdges, aNet)
   correctImpM[s,i]<-calcs[1]
   wrongDirImpM[s,i]<-calcs[2]
   inCorImpM[s,i]<-calcs[3]
   missImpM[s,i]<-calcs[4]
   totImp[i]<-totImp[i]+1
   }
  }
  }
   
  if(plotImpRan)
  {
  for(s in 1:num2)
  {
    
   filename<-paste(dirStr,"/resImp50-",missingPer,"-",s,".dat", sep="") 
   if(doAllSims || file.exists(filename))
   {
   aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
   if(doDir) calcs<-calcNoEdgesPDAG(corEdges$dirEdges, corEdges$undirEdges, aNet) else calcs<-calcNoEdges(correctEdges, aNet)
   correctImp50M[s,i]<-calcs[1]
   wrongDirImp50M[s,i]<-calcs[2]
   inCorImp50M[s,i]<-calcs[3]
   missImp50M[s,i]<-calcs[4]
   totImp50[i]<-totImp50[i]+1
   }
  }
  }
   
  for(s in 1:num2)
  {
   filename<-paste(dirStr,"/resFull-",missingPer,"-",s,".dat", sep="")
   if(doAllSims || file.exists(filename))
   {
   aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
   if(doDir) calcs<-calcNoEdgesPDAG(corEdges$dirEdges, corEdges$undirEdges, aNet) else calcs<-calcNoEdges(correctEdges, aNet) 
   correctFullM[s,i]<-calcs[1]
   wrongDirFullM[s,i]<-calcs[2]
   inCorFullM[s,i]<-calcs[3]
   missFullM[s,i]<-calcs[4]
   totFull[i]<-totFull[i]+1
   }
  }
  
  if(plotReduced)
  {
  for(s in 1:num2)
  {
   filename<-paste(dirStr,"/resMiss-",missingPer,"-",s,".dat", sep="")
   if(doAllSims || file.exists(filename))
   {
   aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
   if(doDir) calcs<-calcNoEdgesPDAG(corEdges$dirEdges, corEdges$undirEdges, aNet) else calcs<-calcNoEdges(correctEdges, aNet)
   correctMissM[s,i]<-calcs[1]
   wrongDirMissM[s,i]<-calcs[2]
   inCorMissM[s,i]<-calcs[3]
   missMissM[s,i]<-calcs[4]
   totMiss[i]<-totMiss[i]+1
   }
  }
   }
   
  for(s in 1:num2)
  {
   filename<-paste(dirStr,"/resRanImp-",missingPer,"-",s,".dat", sep="")
   if(doAllSims || file.exists(filename))
   {
    aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
  
    if(doDir) calcs<-calcNoEdgesPDAG(corEdges$dirEdges, corEdges$undirEdges, aNet) else calcs<-calcNoEdges(correctEdges, aNet)
    correctRanM[s,i]<-calcs[1]
    wrongDirRanM[s,i]<-calcs[2]
    inCorRanM[s,i]<-calcs[3]
    missRanM[s,i]<-calcs[4]
    totRan[i]<-totRan[i]+1
   }
  }
   
  for(s in 1:num2)
  {
   filename<-paste(dirStr,"/resEM-",missingPer,"-",s,".dat", sep="")
   if(doAllSims || file.exists(filename))
   {
   if(file.size(filename)>1) #check there are some edges
   {
    aNet<-read.table(filename, stringsAsFactors=FALSE)
    } else {
   aNet<-c()
   }
  
   if(length(aNet) > 0 && dim(aNet)[1]==2 && dim(aNet)[2]==1)
   {
    arcs<-as.data.frame(cbind(c(aNet[1,1]), c(aNet[2,1]))) ##switch if error in one arc being in first column 
   } else {
    arcs<-aNet
   } 
   if(doDir) calcs<-calcNoEdgesPDAG(corEdges$dirEdges, corEdges$undirEdges, "EM", arcs) else calcs<-calcNoEdges(correctEdges, "EM", arcs)
   correctEMM[s,i]<-calcs[1]
   wrongDirEMM[s,i]<-calcs[2]
   inCorEMM[s,i]<-calcs[3]
   missEMM[s,i]<-calcs[4]
   totEM[i]<-totEM[i]+1
   }
  }##end seed

  if(plotEM2)
  {
  for(s in 1:num2)
  {
   filename<-paste(dirStr,"/resEM2-",missingPer,"-",s,".dat", sep="")
   if(doAllSims || file.exists(filename))
   {
   if(file.size(filename)>1) #check there are some edges
   {
    aNet<-read.table(filename, stringsAsFactors=FALSE)
    } else {
   aNet<-c()
   }
  
   if(length(aNet) > 0 && dim(aNet)[1]==2 && dim(aNet)[2]==1)
   {
    arcs<-as.data.frame(cbind(c(aNet[1,1]), c(aNet[2,1]))) ##switch if error in one arc being in first column 
   } else {
    arcs<-aNet
   } 
   if(doDir) calcs<-calcNoEdgesPDAG(corEdges$dirEdges, corEdges$undirEdges, "EM", arcs) else calcs<-calcNoEdges(correctEdges, "EM", arcs)
   correctEM2M[s,i]<-calcs[1]
   wrongDirEM2M[s,i]<-calcs[2]
   inCorEM2M[s,i]<-calcs[3]
   missEM2M[s,i]<-calcs[4]
   totEM2[i]<-totEM2[i]+1
   }
  }##end seed
  }
  
} ##end missingPerVec

totals<-rbind(totFull, totMiss, totImp, totImp50, totRan, totEM, totEM2)
colnames(totals)<-perMissVec
rownames(totals)<-c("Full", "Miss", "Imp", "Imp50", "Ran", "EM", "EM2")
write.table(totals, paste(figpath,"totals-",model,"-BNRespos.dat", sep=""), row.names=TRUE, col.names=TRUE, quote=FALSE)


correctFull<-colMeans(correctFullM)*(num2/totFull)
wrongDirFull<-colMeans(wrongDirFullM)*(num2/totFull)
inCorFull<-colMeans(inCorFullM)*(num2/totFull)
missFull<-colMeans(missFullM)*(num2/totFull)

correctMiss<-colMeans(correctMissM)*(num2/totMiss)
wrongDirMiss<-colMeans(wrongDirMissM)*(num2/totMiss)
inCorMiss<-colMeans(inCorMissM)*(num2/totMiss)
missMiss<-colMeans(missMissM)*(num2/totMiss)

correctImp<-colMeans(correctImpM)*(num2/totImp)
wrongDirImp<-colMeans(wrongDirImpM)*(num2/totImp)
inCorImp<-colMeans(inCorImpM)*(num2/totImp)
missImp<-colMeans(missImpM)*(num2/totImp)

correctImp50<-colMeans(correctImp50M)*(num2/totImp50)
wrongDirImp50<-colMeans(wrongDirImp50M)*(num2/totImp50)
inCorImp50<-colMeans(inCorImp50M)*(num2/totImp50)
missImp50<-colMeans(missImp50M)*(num2/totImp50)

correctRan<-colMeans(correctRanM)*(num2/totRan)
wrongDirRan<-colMeans(wrongDirRanM)*(num2/totRan)
inCorRan<-colMeans(inCorRanM)*(num2/totRan)
missRan<-colMeans(missRanM)*(num2/totRan)

correctEM<-colMeans(correctEMM)*(num2/totEM)
wrongDirEM<-colMeans(wrongDirEMM)*(num2/totEM)
inCorEM<-colMeans(inCorEMM)*(num2/totEM)
missEM<-colMeans(missEMM)*(num2/totEM)

correctEM2<-colMeans(correctEM2M)*(num2/totEM2)
wrongDirEM2<-colMeans(wrongDirEM2M)*(num2/totEM2)
inCorEM2<-colMeans(inCorEM2M)*(num2/totEM2)
missEM2<-colMeans(missEM2M)*(num2/totEM2)

if(writeSummaries)
{
 summaries<-cbind(correctFull, wrongDirFull, inCorFull, missFull,
  correctMiss, wrongDirMiss, inCorMiss, missMiss,
  correctImp, wrongDirImp, inCorImp, missImp,
  correctImp50, wrongDirImp50, inCorImp50, missImp50,
  correctRan, wrongDirRan, inCorRan, missRan,
  correctEM, wrongDirEM, inCorEM, missEM,
  correctEM2, wrongDirEM2, inCorEM2, missEM2 )

  
  sumFile<-paste(figpath,"summaryBNRepos-", model, doRecall, doPrec, doDir, doUndir,".dat",sep="")
  
  write.table(summaries, sumFile, row.names=FALSE, col.names=TRUE, quote=FALSE)

}

} else {

  sumFile<-paste(figpath,"summaryBNRepos-", model, doRecall, doPrec, doDir, doUndir,".dat",sep="")
  
  summaries<-read.table(sumFile, header=TRUE)
  
  correctFull<-summaries[,1]
  wrongDirFull<-summaries[,2]
  inCorFull<-summaries[,3]
  missFull<-summaries[,4]
  correctMiss<-summaries[,5]
  wrongDirMiss<-summaries[,6]
  inCorMiss<-summaries[,7]
  missMiss<-summaries[,8]
  correctImp<-summaries[,9]
  wrongDirImp<-summaries[,10]
  inCorImp<-summaries[,11]
  missImp<-summaries[,12]
  correctImp50<-summaries[,13]
  wrongDirImp50<-summaries[,14]
  inCorImp50<-summaries[,15]
  missImp50<-summaries[,16]
  correctRan<-summaries[,17]
  wrongDirRan<-summaries[,18]
  inCorRan<-summaries[,19]
  missRan<-summaries[,20]  
  correctEM<-summaries[,21]
  wrongDirEM<-summaries[,22]
  inCorEM<-summaries[,23]
  missEM<-summaries[,24]
  correctEM2<-summaries[,25]
  wrongDirEM2<-summaries[,26]
  inCorEM2<-summaries[,27]
  missEM2<-summaries[,28]

} #end read summaries or not above

#maxCor<-4

#if(png==1) png(paste(figpath,"plotLarge3-correct.png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")


###############################################

seedName<-paste(seeds[1],"-",seeds[length(seeds)],sep="")

 
if(doRecall && doDir)
{
 plotLetter<-paste0("(",letters[plotNo],")")
 
 #Lines <- list(bquote(paste(.(plotLetter) , " Recall - Directed")), model)
 Lines <- list(bquote(paste(.(plotLetter), " Network \"", .(model) ,"\" Recall")))

 #do recall
 plot(perMissVec, correctFull/totalTrueEdges, ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="recall", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab)
 if(plotImpRan) points(perMissVec, correctImp50/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
 if(plotImp) points(perMissVec, correctImp/totalTrueEdges, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex) 
 if(plotReduced) points(perMissVec, correctMiss/totalTrueEdges, type="b", col=cols[4], lty=ltys[4], pch=pchs[4],  lwd=lwd, cex=cex)
 points(perMissVec, correctRan/totalTrueEdges, type="b", col=cols[5], lty=ltys[5], pch=pchs[5], lwd=lwd, cex=cex)
 points(perMissVec, correctEM/totalTrueEdges, type="b", col=cols[6], lty=ltys[6], pch=pchs[6], lwd=lwd, cex=cex)
 if(plotEM2) points(perMissVec, correctEM2/totalTrueEdges, type="b", col=cols[7], lty=ltys[7], pch=pchs[7], lwd=lwd, cex=cex)
 
 mtext(do.call(expression, Lines),side=3,line=1, cex=cex.main)
 
 legPos<-"bottomleft"
 if(plotNo==3 || plotNo==5) legPos<-"topleft" 
 legend(legPos, legend=leg, pch=pchs[usingPlots], lwd=lwd, cex=cexleg, col=cols[usingPlots], lty=ltys[usingPlots])

 plotNo<-plotNo+1
}

if(doRecall && doUndir)
{
plotLetter<-paste0("(",letters[plotNo],")")
 
 Lines <- list(bquote(paste(.(plotLetter) , " Recall - Undirected")), model)
            
              
#do recall - undirected
plot(perMissVec, (correctFull+wrongDirFull)/totalTrueEdges, ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="recall", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab)
if(plotImpRan) points(perMissVec, (correctImp50+wrongDirImp50)/totalTrueEdges, type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
if(plotImp) points(perMissVec, (correctImp+wrongDirImp)/totalTrueEdges, type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
if(plotReduced) points(perMissVec, (correctMiss+wrongDirMiss)/totalTrueEdges, type="b", col=cols[4], lty=ltys[4], pch=pchs[4],  lwd=lwd, cex=cex)
points(perMissVec, (correctRan+wrongDirRan)/totalTrueEdges, type="b", col=cols[5], lty=ltys[5], pch=pchs[5], lwd=lwd, cex=cex)
points(perMissVec, (correctEM+wrongDirEM)/totalTrueEdges, type="b", col=cols[6], lty=ltys[6], pch=pchs[6], lwd=lwd, cex=cex)
if(plotEM2) points(perMissVec, (correctEM2+wrongDirEM2)/totalTrueEdges, type="b", col=cols[7], lty=ltys[7], pch=pchs[7], lwd=lwd, cex=cex)
legend("bottomright", legend=leg, pch=pchs[usingPlots], lwd=lwd, cex=cexleg, col=cols[usingPlots], lty=ltys[usingPlots])

 mtext(do.call(expression, Lines),side=3,line=1:0, cex=cex.main)

 plotNo<-plotNo+1
}

if(doPrec && doDir)
{
plotLetter<-paste0("(",letters[plotNo],")")
 
 #Lines <- list(bquote(paste(.(plotLetter) , " Precision - Directed")), model)
   Lines <- list(bquote(paste(.(plotLetter), " Network \"", .(model) ,"\" Precision")))
           
              
##do precision - directed
plot(perMissVec, correctFull/(correctFull + wrongDirFull + inCorFull), ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="precision", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab)
if(plotImpRan) points(perMissVec, correctImp50/(correctImp50 + wrongDirImp50 + inCorImp50), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
if(plotImp) points(perMissVec, correctImp/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
if(plotReduced) points(perMissVec, correctMiss/(correctMiss + wrongDirMiss + inCorMiss), type="b", col=cols[4], lty=ltys[4], pch=pchs[4],  lwd=lwd, cex=cex)
points(perMissVec, correctRan/(correctRan + wrongDirRan + inCorRan), type="b", col=cols[5], lty=ltys[5], pch=pchs[5], lwd=lwd, cex=cex)
points(perMissVec, correctEM/(correctEM + wrongDirEM + inCorEM), type="b", col=cols[6], lty=ltys[6], pch=pchs[6], lwd=lwd, cex=cex)
if(plotEM2) points(perMissVec, correctEM2/(correctEM2 + wrongDirEM2 + inCorEM2), type="b", col=cols[7], lty=ltys[7], pch=pchs[7], lwd=lwd, cex=cex)

legPos<-"bottomleft"
 #if(plotNo==3 || plotNo==5) legPos<-"topright" 
legend(legPos, legend=leg, pch=pchs[usingPlots], lwd=lwd, cex=cexleg, col=cols[usingPlots], lty=ltys[usingPlots])

 mtext(do.call(expression, Lines),side=3,line=1, cex=cex.main)

 plotNo<-plotNo+1
}

if(doPrec && doUndir)
{
plotLetter<-paste0("(",letters[plotNo],")")
 
 Lines <- list(bquote(paste(.(plotLetter) , " Precision - Undirected")), model)
            
              
##do precision - undirected
plot(perMissVec, (correctFull+wrongDirFull)/(correctFull + wrongDirFull + inCorFull), ylim=c(0,1), type="b", col=cols[1], lty=ltys[1], pch=pchs[1], xlab=xlab, ylab="precision", lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab)
if(plotImpRan) points(perMissVec, (correctImp50+wrongDirImp50)/(correctImp50 + wrongDirImp50 + inCorImp50), type="b", col=cols[2], lty=ltys[2], pch=pchs[2], lwd=lwd, cex=cex)
if(plotImp) points(perMissVec, (correctImp+wrongDirImp)/(correctImp + wrongDirImp + inCorImp), type="b", col=cols[3], lty=ltys[3], pch=pchs[3], lwd=lwd, cex=cex)
if(plotReduced) points(perMissVec, (correctMiss+wrongDirMiss)/(correctMiss + wrongDirMiss + inCorMiss), type="b", col=cols[4], lty=ltys[4], pch=pchs[4],  lwd=lwd, cex=cex)
points(perMissVec, (correctRan+wrongDirRan)/(correctRan + wrongDirRan + inCorRan), type="b", col=cols[5], lty=ltys[5], pch=pchs[5], lwd=lwd, cex=cex)
points(perMissVec, (correctEM+wrongDirEM)/(correctEM + wrongDirEM + inCorEM), type="b", col=cols[6], lty=ltys[6], pch=pchs[6], lwd=lwd, cex=cex)
if(plotEM2) points(perMissVec, (correctEM2+wrongDirEM2)/(correctEM2 + wrongDirEM2 + inCorEM2), type="b", col=cols[7], lty=ltys[7], pch=pchs[7], lwd=lwd, cex=cex)
legend("bottomright", legend=leg, pch=pchs[usingPlots], lwd=lwd, cex=cexleg, col=cols[usingPlots], lty=ltys[usingPlots])
 mtext(do.call(expression, Lines),side=3,line=1:0, cex=cex.main)

 plotNo<-plotNo+1
}

 plotNo
} ##end doSomePlots

startPlots<-function(plotFilename, layout0=c(3,2))
{
 if(png==2) postscript(paste(figpath,plotFilename,".eps",sep=""), width=12, height=15, bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

 #par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))
 if(png==1) png(paste(figpath,plotFilename,".png",sep=""), width = 800, height = 800, units = "px", pointsize = 12, bg = "white")

 #par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))
 if(png==1) par(mfrow=layout0, mar=c(5.1, 5.1, 4.1, 2.1)) else par(mfrow=layout0) #, mar=c(2.0, 2.0, 5.0, 2.0))

}

#plotSomeGraphs<-function(model, perMissVec, doRecall, doPrec, doDir, doUndir, plotNo0=1)
perMissVec<-c(10,20,30,40)
if(doPlot1)
{
 startPlots("fig-BNRepos1-dir-25Reps-v2")
 plotNo<-plotSomeGraphs("ecoli70", perMissVec, 1, 1, 1, 0)
 plotNo<-plotSomeGraphs("insurance", perMissVec, 1, 1, 1, 0, plotNo)
 plotSomeGraphs("alarm", perMissVec, 1, 1, 1, 0, plotNo)
 dev.off()
}

if(doPlot2)
{
 startPlots("fig-BNRepos1-undir-25Reps-v2")
 plotNo<-0
 plotNo<-plotSomeGraphs("ecoli70", perMissVec, 1, 1, 0, 1)
 plotNo<-plotSomeGraphs("insurance", perMissVec, 1, 1, 0, 1, plotNo)
 plotSomeGraphs("alarm", perMissVec, 1, 1, 0, 1, plotNo)
 dev.off()
}

if(doPlot3)
{
 startPlots("fig-BNRepos22-dir-25RepsY")
 plotNo<-plotSomeGraphs("ecoli70X", perMissVec, 1, 1, 1, 0)
 plotNo<-plotSomeGraphs("insuranceX", perMissVec, 1, 1, 1, 0, plotNo)
 plotSomeGraphs("alarmX", perMissVec, 1, 1, 1, 0, plotNo)
 dev.off()
}

if(doPlot4)
{
 startPlots("fig-BNRepos2-undir-25Reps")
 plotNo<-plotSomeGraphs("ecoli70X", perMissVec, 1, 1, 0, 1)
 plotNo<-plotSomeGraphs("insuranceX", perMissVec, 1, 1, 0, 1, plotNo)
 plotSomeGraphs("alarmX", perMissVec, 1, 1, 0, 1, plotNo)
 dev.off()
}