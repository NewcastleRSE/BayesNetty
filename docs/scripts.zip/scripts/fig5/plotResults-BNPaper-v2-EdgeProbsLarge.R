#
library("igraph")

setwd("C:/Users/richa/work/code/bayesnetty/edgeCosts/model10/")

home<-1

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path<-"/home/nrajh/code/bayesnetty/edgeCosts/paper-sims/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path<-"K:/code/bayesnetty/edgeCosts/paper-sims/"
} else {
 path<-"C:/Users/richa/work/code/bayesnetty/edgeCosts/model10/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

#name<-"w0pt2"
#name<-"v2w0pt1"
name<-"v2w0pt05"

png<-2

cex=1.5#3
lwd=1.5#3
cex.axis=1.5#5
cex.lab=1.5#5
cex.main=2#5

#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1) + c(0, 1.0, 0, 0)   #+ c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  #+ c(4,1.5,0)


cols<-rep("black", 18) #rainbow(18)
cols[c(2,8,14)]<-"red"
cols[c(1,7,13)]<-"blue"
cols[c(3,9)]<-"cyan"
cols[c(5,6,11,12,15,16)]<-"green"

ltys<-rep(3, 18) 
ltys[c(2,8,14)]<-2
ltys[c(1,7,13)]<-3
ltys[c(3,9)]<-3
ltys[c(5,6,11,12,15,16)]<-1
ltys<-rep(1, 18)

pchs<-rep("o", 18) #rainbow(18)
pchs[c(2,8,14)]<-"p"
pchs[c(1,7,13)]<-"+"
pchs[c(3,9)]<-"x"
pchs[c(5,6,11,12,15,16)]<-"~"


probs<-c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1)

gcols<-rep("black", 18) 
gcols[c(3,9,15)]<-"red"
gcols[c(1,7,13)]<-"blue"
gcols[c(5,11)]<-"cyan"
gcols[c(2,4,8,10,14,16)]<-"green"

gltys<-rep(3, 18) 
gltys[c(3,9,15)]<-2
gltys[c(1,7,13)]<-3
gltys[c(5,11)]<-3
gltys[c(2,4,8,10,14,16)]<-1
gltys<-rep(1, 18)

edge.labs<-rep("   o", 18)
edge.labs[c(3,9,15)]<-"   p"
edge.labs[c(2,4,8,10,14,16)]<-"   ~"
edge.labs[c(1,7,13)]<-"   +"
edge.labs[c(5,11)]<-"   x"

edge.fonts<-rep(1, 18)
edge.fonts[c(3,9,15)]<-3

edge.cexs<-rep(1.8, 18)
edge.cexs[c(3,9,15)]<-2.7

####plot graphs
#load network graph
nodes<-read.table("graph-nodes.dat", header=TRUE)
edges<-read.table("graph-edges.dat", header=TRUE)

#create graph
graph<-graph_from_data_frame(edges, directed = TRUE, vertices = nodes)

#plot the network and output png file, edit style as required

#style for continuous nodes
shape<-rep("circle", length(nodes$type))
vcolor<-rep("#eeeeee", length(nodes$type))
vsize<-rep(20, length(nodes$type))
color<-rep("black", length(nodes$type))

theCoords<-as.matrix(read.table("theCoords.dat", header=FALSE))

#edge widths for significances
minWidth<-1
maxWidth<-7
mean(edges$chisq)
edgeThick<-rep(0.05, length(edges$chisq))
edgeThick[edges$chisq > mean(edges$chisq)]<-0.3 
edgeMin<-min(edgeThick)
edgeMax<-max(edgeThick)
widths<-((edgeThick-edgeMin)/(edgeMax-edgeMin))*(maxWidth - minWidth) + minWidth
styles<-rep(1, length(widths))

#plot to a png file
#png(filename="graph.png", width=800, height=800)
if(png==1) png(paste(figpath,"fig-largeNetImputation",seed,"-v2.png",sep=""), width = 1800, height = 1800, units = "px", pointsize = 12, bg = "white")
if(png==2) postscript(paste(figpath,"fig-largeNetEdgeProb-v2.eps",sep=""), height=12, width=12,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

if(png==0) dev.new(width=8, height=8)

par(mfrow=c(2,2), mar=mar, mgp=mgp)
#par(xpd=FALSE)

plot(graph, layout=theCoords, vertex.shape=shape, vertex.size=vsize, vertex.color=vcolor, vertex.label.color=color, edge.width=widths, edge.lty=gltys, edge.color=gcols, edge.arrow.size=1.5, vertex.label=NA, edge.label=edge.labs, edge.label.font=edge.fonts, edge.label.cex=edge.cexs)
box(col = "black")
title("(a) Simulation Model", cex.main=cex.main)
#text(-1.09, 1.05, "a", cex=3.5)


####################################################################
#plot then adjust coords
#tkCor<-tkplot(graph, vertex.shape=shape, vertex.size=vsize, vertex.color=vcolor, vertex.label.color=color, edge.width=widths, edge.lty=styles, edge.color="black", edge.arrow.size=1.5)

##get coords and replot
#theCoords<-tk_coords(tkCor)
#write.table(theCoords, "theCoords.dat", quote=FALSE, row.names=FALSE, col.names=FALSE)
#tk_close(tkCor)

####################################################################




###############################################################################
edgeResRecall<-read.table(paste("resultsSummary/resRecall-",0.3,"-",name,".dat",sep=""), header = FALSE)

#"(b) Individual Edges Average Recall"   
plot(probs, edgeResRecall[1,3:13], lty=ltys[1], col=cols[1], pch=pchs[1], type="b", ylim=c(0,1), main=paste("(b) Proportion of networks with edges", sep=""), xlab="prior probility", ylab="proportion", cex=cex, lwd=lwd, cex.axis=1.5, cex.lab=1.5, cex.main=cex.main)
#abline(h=0.5, lty=2)
#lines(x = c(0,1), y = c(0.5, 0.5), lty = 2)
lines(x = c(0.5,0.5), y = c(0, 1), lty = 2)
for(ed in 2:length(edgeResRecall[,1])) points(probs, edgeResRecall[ed,3:13], type="b", col=cols[ed], lty=ltys[ed], pch=pchs[ed], cex=cex) 


#plot recall
resRecall<-read.table(paste("resultsSummary/resultsRecall-",name,".dat",sep=""), header = FALSE)

plot(probs, resRecall[3,]/100, type="b", ylim=c(0,1), main=paste("(c) Network Average Recall", sep=""), xlab="prior probility", ylab="average recall", cex=cex, lwd=lwd, cex.axis=1.5, cex.lab=1.5, cex.main=cex.main)
#lines(x = c(0,1), y = c(0.5, 0.5), lty = 2)
lines(x = c(0.5,0.5), y = c(0, 1), lty = 2)

#plotPrecision
resPrecision<-read.table(paste("resultsSummary/resultsPrecision-",name,".dat",sep=""), header = FALSE)

plot(probs, resPrecision[3,]/100, type="b", ylim=c(0,1), main=paste("(d) Network Average Precision", sep=""), xlab="prior probility", ylab="average precision", cex=cex, lwd=lwd, cex.axis=1.5, cex.lab=1.5, cex.main=cex.main)
#lines(x = c(0,1), y = c(0.5, 0.5), lty = 2)
lines(x = c(0.5,0.5), y = c(0, 1), lty = 2)


#finish png file
if(png>0) dev.off()

