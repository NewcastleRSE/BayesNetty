

home<-3

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path<-"/home/nrajh/code/bayesnetty/missingData/sims/subsetPercent"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path<-"K:/code/bayesnetty/missingData/sims/subsetPercent"
} else if(home == 3) {
     figpath<-"/mnt/nfs/home/nrajh/bayesnetty/subsetPercent/"
     path<-"/nobackup/nrajh"
} else if(home == 1) {
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
 path<-"C:/Users/richa/work/code/bayesnetty/missingData/sims/subsetPercent" 
}

#C:\Users\richa\work\work-other\tex\bayesNet

writeSummaries<-TRUE #TRUE #TRUE #only if not reading summaries
readSummaries<-FALSE #TRUE

##plots 1 

doPlot1<-1 #mod1 cts dir

setwd(path)


png<-2 #0#1


xlab="subset percentage"
#ylab="number of edges"

cex=1.5 #3
lwd=1.5 #3
cex.axis=1.5 #5
cex.lab=1.5 #5
cex.main=2 #5

cexleg<-1.5#1.1#4
labcex<-3#1.5#3


#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1)  + c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(4,1.5,0)


cexleg<-1.5#1.1#4
labcex<-3#1.5#3

if(png==1)
{
cex=1.5#3
lwd=1.5#3
cex.axis=2 #1.5#5
cex.lab=2 #1.5#5
cex.main=2#5

cexleg<-1.5#1.1#4
labcex<-3#1.5#3
}

#correctNet<-"correctNet.dat"
#dir<-"results0pt4/"
#dir<-"results0.5-8/"




plotSomeGraphs<-function(modType, model, perMiss, doRecall, doPrec, method, plotNo0=1)
{
 plotNo<-plotNo0


if(!readSummaries)
{

num<-length(percents)
num2<-length(seeds)


recallsM<-matrix(0, nrow=num2, ncol=num)
precisionsM<-matrix(0, nrow=num2, ncol=num)


for(i in 1:num)
{
  percent<-percents[i]
  
  for(s in 1:num2)
  {
    #seed<-seeds[s]

  dirStr<-paste0("results-",model,"-",bet,"-",missingPer,"-",n)
 
  
  #filename<-paste(dirStr,"/res",modType,"Imp-",bet,"-",perMiss,"-2000-",s,".dat", sep="")
  filename<-paste0(dirStr,"/resCts",method,"-",percent,"-",s,".dat")
  #if(doBreak && !file.exists(filename)) break
  if(file.exists(filename))
  {
   #aNet<-read.table(filename, stringsAsFactors=FALSE)[1,1]
   rp<-read.table(filename, header=FALSE)
   
   recallsM[s,i]<-rp[1,1]
   precisionsM[s,i]<-rp[1,2]
   
  } else {
    recallsM[s,i]<-NA
    precisionsM[s,i]<-NA
  
  }
  
  
 
  
  }##end seed


} ##end percent

#totals<-rbind(tot)
#colnames(totals)<-percents
#rownames(totals)<-c(method)
#write.table(totals, paste(figpath,"totals-",method,"-",perMiss,".dat", sep=""), row.names=TRUE, col.names=TRUE, quote=FALSE)


if(writeSummaries)
{
  colnames(recallsM)<-percents
  sumFile<-paste(figpath,"summary-recallM-",method,"-",model,"-",bet,"-",missingPer,"-",n,".dat",sep="") 
  write.table(recallsM, sumFile, row.names=FALSE, col.names=TRUE, quote=FALSE)

  colnames(precisionsM)<-percents
  sumFile<-paste(figpath,"summary-precisionM-",method,"-",model,"-",bet,"-",missingPer,"-",n,".dat",sep="") 
  write.table(precisionsM, sumFile, row.names=FALSE, col.names=TRUE, quote=FALSE)

}

} else {

  sumFile<-paste(figpath,"summary-recallM-",method,"-",model,"-",bet,"-",missingPer,"-",n,".dat",sep="") 
  
  recallsM<-read.table(sumFile, header=TRUE)
  
  sumFile<-paste(figpath,"summary-precisionM-",method,"-",model,"-",bet,"-",missingPer,"-",n,".dat",sep="") 
  
  precisionsM<-read.table(sumFile, header=TRUE)

} #end read summaries or not above



#maxCor<-4

#if(png==1) png(paste(figpath,"plotLarge3-correct.png",sep=""), width = 1200, height = 1200, units = "px", pointsize = 12, bg = "white")


###############################################

seedName<-paste(seeds[1],"-",seeds[length(seeds)],sep="")


if(doRecall)
{
 plotLetter<-paste0("(",letters[plotNo],")")
 
 Lines <- list(bquote(paste(.(plotLetter) , " Recall")), method) #- Directed

 theMatrix<-recallsM
 
 #do recall
 #boxplot(x = as.list(as.data.frame(theMatrix)), main="Different boxplots for each subset percentage", xlab="percentage", ylab="recall", col="orange", border="brown", names=percents)
 
 aves<-colMeans(theMatrix, na.rm = TRUE)/100
 plot(percents, aves, type="b", ylim=c(0,1))
 
 plotNo<-plotNo+1
}

if(doPrec)
{
plotLetter<-paste0("(",letters[plotNo],")")
 
 Lines <- list(bquote(paste(.(plotLetter) , " Precision")), method) #- Directed
             
 theMatrix<-precisionsM
   
 #boxplot(x = as.list(as.data.frame(theMatrix)), main="Different boxplots for each subset percentage", xlab="percentage", ylab="precision", col="orange", border="brown", names=percents)
 
 aves<-colMeans(theMatrix, na.rm = TRUE)/100
 plot(percents, aves, type="b", ylim=c(0,1))
 
 plotNo<-plotNo+1
}



 plotNo
} ##end doSomePlots

startPlots<-function(plotFilename, layout0=c(2,2))
{
 if(png==2) postscript(paste(figpath,plotFilename,".eps",sep=""), width=12, height=12, bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )

 #par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))
 if(png==1) png(paste(figpath,plotFilename,".png",sep=""), width = 800, height = 800, units = "px", pointsize = 12, bg = "white")

 #par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))
 if(png==1) par(mfrow=layout0, mar=c(5.1, 5.1, 4.1, 2.1)) else par(mfrow=layout0) #, mar=c(2.0, 2.0, 5.0, 2.0))

}

#plotSomeGraphs(modType, model, perMiss, doRecall, doPrec, method)

if(doPlot1)
{
 model<-"ecoli70" #1
 bet<-0.3 #2
 missingPer<-20
 n<-500
 percents<-c(10, 20, 30, 40, 50, 60, 70, 80, 90, 100)
 seeds<-1:100 ##reps

 startPlots("fig-ecoli70-subsetPercent1-v3")   ##yes, in paper
 plotNo<-plotSomeGraphs("Cts", model, missingPer, 1, 0, "ImpRT")
 plotSomeGraphs("Cts", model, missingPer, 0, 1, "ImpRT", plotNo)
 plotSomeGraphs("Cts", model, missingPer, 1, 0, "ImpCT", plotNo)
 plotSomeGraphs("Cts", model, missingPer, 0, 1, "ImpCT", plotNo)
 dev.off()
}
