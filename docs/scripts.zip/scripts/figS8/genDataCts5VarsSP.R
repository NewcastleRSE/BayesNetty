cmd_args<-commandArgs()

#cmd_args<-c(0,0,0,   1, 0.3, 10, 2000, 90, 1)

model<-cmd_args[4] #1
bet<-as.numeric(cmd_args[5]) #2
missingPer<-as.numeric(cmd_args[6]) #3
n<-as.numeric(cmd_args[7]) #4
subsetPercent<-as.numeric(cmd_args[8]) #5
it<-cmd_args[9] ##iteration #6

total<-n

if(model==1)
{

 A<-rnorm(total, 10 ,1)
 C<-rnorm(total, 10 ,1)
 E<-rnorm(total, 10 ,1)
 B<-rnorm(total, 10 + A*bet + C*bet, 1)
 D<-rnorm(total, 10 + C*bet + E*bet, 1)

} else if(model==3) {

 A<-rnorm(total, 10 ,1)
 B<-rnorm(total, 10 + A*bet, 1)
 C<-rnorm(total, 10 + B*bet, 1)
 D<-rnorm(total, 10 + C*bet, 1)
 E<-rnorm(total, 10 + D*bet, 1)

} else if(model=="ecoli70") {


library("bnlearn")

######################
##write correct network
load(paste(model,".rda", sep=""))

net<-bn.net(bn)

arcs<-net$arcs

nodes<-unique(c(arcs[,1], arcs[,2]))

nodeList<-cbind(nodes, rep(" ", length(nodes)))

netFile<-rbind(nodeList, arcs)

write.table(netFile, paste("networkCor",model,".dat", sep=""), row.names=FALSE, col.names=FALSE, quote=FALSE)

write.table(arcs, paste("networkCorArcs-",model,".dat", sep=""), row.names=FALSE, col.names=FALSE, quote=FALSE)

allData<-rbn(bn, n) 

##write.table(allData, paste("dataFull-",model,"-",missingPer,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)
#write.table(allData, paste("dataFullCts",model,"-",bet,"-",missingPer,"-",n,"-",subsetPercent,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)

setToMissing<-matrix(sample(c(TRUE, FALSE), dim(allData)[1]*dim(allData)[2], replace=TRUE, prob=c(missingPer/100,(1-missingPer/100))), nrow=dim(allData)[1], ncol=dim(allData)[2])

#ensure first 50 rows have some data 
setToMissing[1:50,1:dim(allData)[2]]<-FALSE

allData[setToMissing]<-NA

#write.table(allData, paste("dataMiss-",model,"-",missingPer,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)
write.table(allData, paste("dataCts",model,"-",bet,"-",missingPer,"-",n,"-",subsetPercent,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)

#allDataRan<-allData

##loop though columns
#for(co in 1:dim(allDataRan)[2])
#{
#  isMissing<-is.na(allDataRan[,co])
#  allDataRan[isMissing, co]<-sample(allDataRan[!isMissing, co], sum(isMissing), replace=TRUE)
#}


#write.table(allDataRan, paste("dataRanImp-",model,"-",missingPer,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)
##write.table(allDataRan, paste("dataRanImpCts",model,"-",bet,"-",missingPer,"-",n,"-",subsetPercent,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)

} #end ecoli70 

if(model!="ecoli70")
{
 allData<-cbind(A,B,C,D,E)
 colnames(allData)<-c("a", "b", "c", "d", "e")

 write.table(allData, paste("dataFullCts",model,"-",bet,"-",missingPer,"-",n,"-",subsetPercent,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)

if(missingPer == 0)
{
 B[1:975]<-NA
 D[976:1950]<-NA

 #B[1:900]<-NA
 #D[901:1800]<-NA
} else if (missingPer == 1) {
 A[1:975]<-NA
 E[976:1950]<-NA

 #A[1:900]<-NA
 #E[901:1800]<-NA

} else if (missingPer == 2) {
 
 missB<-1:1200
 missD<-601:1800
 B[missB]<-NA
 D[missD]<-NA

} else if (missingPer == 3) {
 
 missA<-1:1200
 missE<-601:1800
 A[missA]<-NA
 E[missE]<-NA

} else {
 miss<-missingPer
 missA<-(1:n)[(sample(1:100, n, replace=TRUE) <= miss)]
 missB<-(1:n)[(sample(1:100, n, replace=TRUE) <= miss)]
 missC<-(1:n)[(sample(1:100, n, replace=TRUE) <= miss)]
 missD<-(1:n)[(sample(1:100, n, replace=TRUE) <= miss)]
 missE<-(1:n)[(sample(1:100, n, replace=TRUE) <= miss)]

 A[missA]<-NA
 B[missB]<-NA
 C[missC]<-NA
 D[missD]<-NA
 E[missE]<-NA
}


allData<-cbind(A,B,C,D,E)

write.table(allData, paste("dataCts",model,"-",bet,"-",missingPer,"-",n,"-",subsetPercent,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)

}


######################

##do structural EM

#library("bnlearn")
#bn<-structural.em(as.data.frame(allData))
#arcs<-bn$arcs[order(bn$arcs[,1],bn$arcs[,2]),]
#write.table(arcs, paste("results5VarsCts2-",model,"-",missingPer,"/resCtsEM-",bet,"-",noMissing,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=FALSE, quote=FALSE)




######################


##do random imp now

if(model!="ecoli70")
{

if(missingPer == 0)
{
 B[1:975]<-sample(B[-(1:975)], 975, replace=TRUE)
 D[976:1950]<-sample(D[-(976:1950)], 975, replace=TRUE)

 #B[1:900]<-sample(B[-(1:900)], 900, replace=TRUE)
 #D[901:1800]<-sample(D[-(901:1800)], 900, replace=TRUE)
} else if(missingPer == 1) {
 A[1:975]<-sample(A[-(1:975)], 975, replace=TRUE)
 E[976:1950]<-sample(E[-(976:1950)], 975, replace=TRUE)

 #A[1:900]<-sample(A[-(1:900)], 900, replace=TRUE)
 #E[901:1800]<-sample(E[-(901:1800)], 900, replace=TRUE)
}  else if(missingPer == 2) {
 B[missB]<-sample(B[-(missB)], sum(missB), replace=TRUE)
 D[missD]<-sample(D[-(missD)], sum(missD), replace=TRUE)

}  else if(missingPer == 3) {
 A[missA]<-sample(A[-(missA)], sum(missA), replace=TRUE)
 E[missE]<-sample(E[-(missE)], sum(missE), replace=TRUE)

} else {

 A[missA]<-sample(A[-(missA)], length(missA), replace=TRUE)
 B[missB]<-sample(B[-(missB)], length(missB), replace=TRUE)
 C[missC]<-sample(C[-(missC)], length(missC), replace=TRUE)
 D[missD]<-sample(D[-(missD)], length(missD), replace=TRUE)
 E[missE]<-sample(E[-(missE)], length(missE), replace=TRUE)

}

 allData<-cbind(A,B,C,D,E)
 colnames(allData)<-c("ar", "br", "cr", "dr", "er")

 write.table(allData, paste("dataRanImpCts",model,"-",bet,"-",missingPer,"-",n,"-",subsetPercent,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)
}

