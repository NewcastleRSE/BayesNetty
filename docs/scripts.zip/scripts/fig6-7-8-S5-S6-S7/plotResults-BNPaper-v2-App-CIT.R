#do plot comparing CIT 

home<-1    # 0 = at work, 1 = at home, 2 = linux
png<-2

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path0<-"/home/nrajh/code/bayesnetty/AlexClarkData/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path0<-"K:/code/bayesnetty/AlexClarkData/"
} else {
 path0<-"C:/Users/richa/work/code/bayesnetty/AlexClarkData/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

doImpRT<-TRUE
dataset<-"AC3" #"AC2" #2" #"SV3"

path<-paste(path0,"analyses/results/results-",dataset,"/", sep="")
setwd(path)

cex=3
lwd=3
cex.axis=3
cex.lab=3
cex.main=3
#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1)  + c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(4,1.5,0)


cexleg<-4
labcex<-3


bCellAllRes<-read.table("summary/bcellAllRes2.dat", header=TRUE)
tCellAllRes<-read.table("summary/tcellAllRes2.dat", header=TRUE)

#head(bCellAllRes)
#head(tCellAllRes)


plotComparisons2<-function(v1, v2, tit0, plotNo, ...)
{
 cor1<-cor(v1, v2)^2
 xmax<-max(v1,1)
 cols<-c(rep("black", 11), rep("red",11), rep("blue",11), rep("green",11), rep("purple",11), rep("orange",11) )
 #tit<-paste("(",letters[plotNo],") ",tit0,"\ncorrelation = ",signif(cor1,3),sep="")
 #tit<-bquote((.(letters[plotNo]))~.(tit0)~"\n"~r^2==.(signif(cor1,3)))
 tit<-bquote(atop((.(letters[plotNo]))~.(tit0),            r^2==.(signif(cor1,3))))
 plot(v1, v2, xlim=c(0,xmax), ylim=c(0,1), main=tit, pch=1:11, col=cols, cex.main=cex.main, lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab=cex.lab, ... )
 abline(v=-log10(0.05), lty=2)
}

xlabel<-expression(CIT~-log[10]~p-value)

if(png==0)
{
 dev.new(width=12, height=8)
 par(mfrow=c(4,3), par(mar=mar, mgp=mgp))
} else if(png==2) {
 postscript(paste(figpath,"fig-CIT-Tcellr2-v2.eps",sep=""), width=24, height=24, bg="white", horizontal=FALSE, paper="special", onefile=FALSE)#, fonts=c("serif", "Palatino") )
 par(mfrow=c(4,3), par(mar=mar, mgp=mgp))
} else if(png==1)
{
 png(paste(figpath,"fig-CIT-Tcellr2-v2.png",sep=""), width = 800, height = 800, units = "px", pointsize = 12, bg = "white")
 par(mfrow=c(4,3), par(mar=mar, mgp=mgp)) #par(mfrow=c(2,2), mar=c(5.1, 5.1, 4.1, 2.1)) else par(mfrow=c(2,2), par(mar=mar, mgp=mgp)) #, mar=c(2.0, 2.0, 5.0, 2.0))
}

plotNo<-1

plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$dirTripNoImp, "T cell Triplet Data", plotNo, xlab=xlabel, ylab="direction")
plotNo<-plotNo+1
abline(h=0.5, lty=2)
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strTripNoImp, "T cell Triplet Data", plotNo, xlab=xlabel, ylab="strength")
plotNo<-plotNo+1
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strTripNoImp*tCellAllRes$dirTripNoImp, "T cell Triplet Data", plotNo, xlab=xlabel, ylab="directed edge probability")
plotNo<-plotNo+1

if(doImpRT)
{
 plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$dirTripImpRT, "T cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="direction")
 plotNo<-plotNo+1
 abline(h=0.5, lty=2)
 plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strTripImpRT, "T cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="strength")
 plotNo<-plotNo+1
 plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strTripImpRT*tCellAllRes$dirTripImpRT, "T cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="directed edge probability")
 plotNo<-plotNo+1
} else {
 plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$dirTripImp, "T cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="direction")
 plotNo<-plotNo+1
 abline(h=0.5, lty=2)
 plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strTripImp, "T cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="strength")
 plotNo<-plotNo+1
 plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strTripImp*tCellAllRes$dirTripImp, "T cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="directed edge probability")
 plotNo<-plotNo+1
}

plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$dirAllNoImp, "T cell All Data", plotNo, xlab=xlabel, ylab="direction")
abline(h=0.5, lty=2)
plotNo<-plotNo+1
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strAllNoImp, "T cell All Data", plotNo, xlab=xlabel, ylab="strength")
plotNo<-plotNo+1
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strAllNoImp*tCellAllRes$dirAllNoImp, "T cell All Data", plotNo, xlab=xlabel, ylab="directed edge probability")
plotNo<-plotNo+1

if(doImpRT)
{
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$dirAllImpRT, "T cell All Data Imputed", plotNo, xlab=xlabel, ylab="direction")
plotNo<-plotNo+1
abline(h=0.5, lty=2)
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strAllImpRT, "T cell All Data Imputed", plotNo, xlab=xlabel, ylab="strength")
plotNo<-plotNo+1
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strAllImpRT*tCellAllRes$dirAllImpRT, "T cell All Data Imputed", plotNo, xlab=xlabel, ylab="directed edge probability")
plotNo<-plotNo+1
} else {
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$dirAllImp, "T cell All Data Imputed", plotNo, xlab=xlabel, ylab="direction")
plotNo<-plotNo+1
abline(h=0.5, lty=2)
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strAllImp, "T cell All Data Imputed", plotNo, xlab=xlabel, ylab="strength")
plotNo<-plotNo+1
plotComparisons2(-log10(tCellAllRes$p_cit), tCellAllRes$strAllImp*tCellAllRes$dirAllImp, "T cell All Data Imputed", plotNo, xlab=xlabel, ylab="directed edge probability")
plotNo<-plotNo+1

}

if(png>0) dev.off()

###

if(png==0)
{
 dev.new(width=12, height=8)
 par(mfrow=c(4,3), par(mar=mar, mgp=mgp))
} else if(png==2) {
 postscript(paste(figpath,"fig-CIT-Bcellr2-v2.eps",sep=""), width=24, height=24, bg="white", horizontal=FALSE, paper="special", onefile=FALSE)#, fonts=c("serif", "Palatino") )
 par(mfrow=c(4,3), par(mar=mar, mgp=mgp))
} else if(png==1)
{
 png(paste(figpath,"fig-CIT-Bcellr2-v2.png",sep=""), width = 800, height = 800, units = "px", pointsize = 12, bg = "white")
 par(mfrow=c(4,3), par(mar=mar, mgp=mgp)) #par(mfrow=c(2,2), mar=c(5.1, 5.1, 4.1, 2.1)) else par(mfrow=c(2,2), par(mar=mar, mgp=mgp)) #, mar=c(2.0, 2.0, 5.0, 2.0))
}

plotNo<-1

plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$dirTripNoImp, "B cell Triplet Data", plotNo, xlab=xlabel, ylab="direction")
abline(h=0.5, lty=2)
plotNo<-plotNo+1
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strTripNoImp, "B cell Triplet Data", plotNo, xlab=xlabel, ylab="strength")
plotNo<-plotNo+1
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strTripNoImp*bCellAllRes$dirTripNoImp, "B cell Triplet Data", plotNo, xlab=xlabel, ylab="directed edge probability")
plotNo<-plotNo+1

if(doImpRT) 
{
 plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$dirTripImpRT, "B cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="direction")
 plotNo<-plotNo+1
 abline(h=0.5, lty=2)
 plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strTripImpRT, "B cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="strength")
 plotNo<-plotNo+1
 plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strTripImpRT*bCellAllRes$dirTripImpRT, "B cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="directed edge probability")
 plotNo<-plotNo+1
} else {
 plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$dirTripImp, "B cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="direction")
 plotNo<-plotNo+1
 abline(h=0.5, lty=2)
 plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strTripImp, "B cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="strength")
 plotNo<-plotNo+1
 plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strTripImp*bCellAllRes$dirTripImp, "B cell Triplet Data Imputed", plotNo, xlab=xlabel, ylab="directed edge probability")
 plotNo<-plotNo+1
}

plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$dirAllNoImp, "B cell All Data", plotNo, xlab=xlabel, ylab="direction")
plotNo<-plotNo+1
abline(h=0.5, lty=2)
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strAllNoImp, "B cell All Data", plotNo, xlab=xlabel, ylab="strength")
plotNo<-plotNo+1
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strAllNoImp*bCellAllRes$dirAllNoImp, "B cell All Data", plotNo, xlab=xlabel, ylab="directed edge probability")
plotNo<-plotNo+1

if(doImpRT)
{
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$dirAllImpRT, "B cell All Data Imputed", plotNo, xlab=xlabel, ylab="direction")
plotNo<-plotNo+1
abline(h=0.5, lty=2)
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strAllImpRT, "B cell All Data Imputed", plotNo, xlab=xlabel, ylab="strength")
plotNo<-plotNo+1
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strAllImpRT*bCellAllRes$dirAllImpRT, "B cell All Data Imputed", plotNo, xlab=xlabel, ylab="directed edge probability")
plotNo<-plotNo+1
} else {
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$dirAllImp, "B cell All Data Imputed", plotNo, xlab=xlabel, ylab="direction")
plotNo<-plotNo+1
abline(h=0.5, lty=2)
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strAllImp, "B cell All Data Imputed", plotNo, xlab=xlabel, ylab="strength")
plotNo<-plotNo+1
plotComparisons2(-log10(bCellAllRes$p_cit), bCellAllRes$strAllImp*bCellAllRes$dirAllImp, "B cell All Data Imputed", plotNo, xlab=xlabel, ylab="directed edge probability")
plotNo<-plotNo+1
}

if(png>0) dev.off()

####################################################################################################


