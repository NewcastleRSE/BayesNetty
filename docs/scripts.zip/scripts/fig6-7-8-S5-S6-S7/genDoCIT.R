##

cmd_args<-commandArgs()

dataset<-cmd_args[4]


#path<-"K:/code/bayesnetty/AlexClarkData/analyses/"

#setwd(path)

source("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/CIT-function.R")


#try residuals with SVs
tmet<-read.table(paste("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,"/tmet-",dataset,".dat", sep=""), header=TRUE)
bmet<-read.table(paste("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,"/bmet-",dataset,".dat", sep=""), header=TRUE)

texp<-read.table(paste("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,"/texp-",dataset,".dat", sep=""), header=TRUE)
bexp<-read.table(paste("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,"/bexp-",dataset,".dat", sep=""), header=TRUE)

dim(tmet)[2]-2
dim(texp)[2]-2
dim(bmet)[2]-2
dim(bexp)[2]-2




bcell<-read.csv("/home/nrajh/code/bayesnetty/AlexClarkData/data/RA_triplets_Bcell.csv", header=TRUE, stringsAsFactors=FALSE)
tcell<-read.csv("/home/nrajh/code/bayesnetty/AlexClarkData/data/RA_triplets_Tcell.csv", header=TRUE, stringsAsFactors=FALSE)

#info<-read.table("/home/nrajh/code/bayesnetty/AlexClarkData/data-ids2/indivInfo-cts.dat", header=TRUE)
#snps<-read.table("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/snpDataFiltered-SNPs-cts.dat", header=TRUE)

info<-read.table(paste("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,"/indivInfo-cts.dat",sep=""), header=TRUE)
snps<-read.table(paste("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/processed-data/",dataset,"/snpDataFiltered-SNPs-cts.dat",sep=""), header=TRUE)


                   
doCIT<-function(num, bt)
{
   if(bt =="b")
   {
    colSNP<-which(colnames(snps) == bcell$SNP[num])
    g<-snps[,colSNP]
  
    colMet<-which(colnames(bmet) == bcell$CpG[num])
    met<-bmet[,colMet]
    
    colExp<-which(colnames(bexp) == bcell$IlluminaID[num])
    expr<-bexp[,colExp]
   
   } else {
    colSNP<-which(colnames(snps) == tcell$SNP[num])
    g<-snps[,colSNP]
     
    colMet<-which(colnames(tmet) == tcell$CpG[num])
    met<-tmet[,colMet]
    
    colExp<-which(colnames(texp) == tcell$IlluminaID[num])
    expr<-texp[,colExp]
     
   }

   #y<-info$Diagnosis

   iv<-CausalityTestJM(g,met,expr)
   
   iv
}

##get MR results for snp->met->expr for bcells
bMetRes<-c()

for(b in 1:length(bcell[,1]))
{
 iv<-doCIT(b, "b")
 bMetRes<-rbind(bMetRes, as.data.frame(t(c(bcell$SNP[b], bcell$CpG[b], bcell$IlluminaID[b], bcell$Gene[b], iv ))))
}

##get CIT results for snp->met->expr for tcells
tMetRes<-c()

for(tt in 1:length(tcell[,1]))
{
 iv<-doCIT(tt, "t")
 tMetRes<-rbind(tMetRes, as.data.frame(t(c(tcell$SNP[tt], tcell$CpG[tt], tcell$IlluminaID[tt], tcell$Gene[tt], iv))))
}


#Output:
#pvalc = p-value for causal model L -> G -> T
#pvalr = p-value for reactive call L -> T -> G
#ccall = causal call 0:no call, 1:causal, 2:reactive, 3:independent(or other)

#tMetRes[tMetRes[,7]==1,]

#bMetRes[bMetRes[,7]==1,]


#tMetRes[tMetRes[,7]==2,]


#tMetRes[tMetRes[,7] %in% c(1,2) ,]

#bMetRes[bMetRes[,7] %in% c(1,2) ,]

#plot(-log10(as.numeric(as.character(tMetRes[,4]))), -log10(as.numeric(as.character(tMetResResid[,4]))))


#tMetRes[order(tMetRes[,4],tMetRes[,1], tMetRes[,2]),]

#bMetRes[order(bMetRes[,4],bMetRes[,1], bMetRes[,2]),]

write.table(tMetRes, "tMetCITRes.dat", quote=FALSE, row.names=FALSE, col.names=TRUE)
write.table(bMetRes, "bMetCITRes.dat", quote=FALSE, row.names=FALSE, col.names=TRUE)
