##

cmd_args<-commandArgs()

dataset<-cmd_args[4]

##dataset<-"SV3"

#path<-paste("K:/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset,"/", sep="")
path<-paste("/home/nrajh/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset,"/", sep="")

setwd(path)


bcell<-read.csv(paste("../../../data/RA_triplets_Bcell.csv", sep=""), header=TRUE, stringsAsFactors=FALSE)
tcell<-read.csv(paste("../../../data/RA_triplets_Tcell.csv", sep=""), header=TRUE, stringsAsFactors=FALSE)

##get results...

#CIT
bCIT<-read.table("CIT/bMetCITRes.dat", header=TRUE, stringsAsFactors=FALSE)
tCIT<-read.table("CIT/tMetCITRes.dat", header=TRUE, stringsAsFactors=FALSE)

bCITpack<-read.table("CIT/bMetCITRes-package.dat", header=TRUE, stringsAsFactors=FALSE)
tCITpack<-read.table("CIT/tMetCITRes-package.dat", header=TRUE, stringsAsFactors=FALSE)

getFileNumber<-function(bt, cpg, expr)
{
   num<-0
   
   if(bt=="b") num<-which(bcell[,2]==cpg & bcell[,3]==expr) else num<-which(tcell[,2]==cpg & tcell[,3]==expr)

   num
}

getStrengthAndDir<-function(aveRes, cpg0, expr0, pre="")
{
  cpg<-paste(pre,cpg0,sep="")
  expr<-paste(pre,expr0,sep="")
  
  ans<-c(0,0)
 
  rowNum<-which(aveRes[,1]==cpg & aveRes[,3]==expr)

  if(length(rowNum)>0)
  {
    ans<-c(aveRes$strength[rowNum], aveRes$direction[rowNum])
  } else {
    rowNum<-which(aveRes[,3]==cpg & aveRes[,1]==expr)
    
    if(length(rowNum)>0)
    {
     ans<-c(aveRes$strength[rowNum], 1-aveRes$direction[rowNum])
     }
  }

  ans
}

##do b cells first, triplets no Imp
bStrTripNoImp<-rep(0, length(bCIT[,1]))
bDirTripNoImp<-rep(0, length(bCIT[,1]))

for(i in 1:length(bCIT[,1]))
{
      fileNum<-getFileNumber("b", bCIT[i, 2], bCIT[i, 3])

      tripAve<-read.table(paste("triplets-no-imp/bcell-",dataset,"-",fileNum,"-ave.dat",sep=""), header=TRUE)

      strDir<-getStrengthAndDir(tripAve, bCIT[i, 2], bCIT[i, 3])
      
      bStrTripNoImp[i]<-strDir[1]
      bDirTripNoImp[i]<-strDir[2]
}

##do t cells first, triplets no Imp
tStrTripNoImp<-rep(0, length(tCIT[,1]))
tDirTripNoImp<-rep(0, length(tCIT[,1]))

for(i in 1:length(tCIT[,1]))
{
      fileNum<-getFileNumber("t", tCIT[i, 2], tCIT[i, 3])

      tripAve<-read.table(paste("triplets-no-imp/tcell-",dataset,"-",fileNum,"-ave.dat",sep=""), header=TRUE)

      strDir<-getStrengthAndDir(tripAve, tCIT[i, 2], tCIT[i, 3])

      tStrTripNoImp[i]<-strDir[1]
      tDirTripNoImp[i]<-strDir[2]
}

##now do triplets with imputation

##do b cells first, triplets Imp
bStrTripImp<-rep(0, length(bCIT[,1]))
bDirTripImp<-rep(0, length(bCIT[,1]))

for(i in 1:length(bCIT[,1]))
{
      fileNum<-getFileNumber("b", bCIT[i, 2], bCIT[i, 3])

      tripAve<-read.table(paste("triplets-imp/bcell-",dataset,"-",fileNum,"-ave-imp.dat",sep=""), header=TRUE)

      strDir<-getStrengthAndDir(tripAve, bCIT[i, 2], bCIT[i, 3])

      bStrTripImp[i]<-strDir[1]
      bDirTripImp[i]<-strDir[2]
}

##do t cells, triplets Imp
tStrTripImp<-rep(0, length(tCIT[,1]))
tDirTripImp<-rep(0, length(tCIT[,1]))

for(i in 1:length(tCIT[,1]))
{
      fileNum<-getFileNumber("t", tCIT[i, 2], tCIT[i, 3])

      tripAve<-read.table(paste("triplets-imp/tcell-",dataset,"-",fileNum,"-ave-imp.dat",sep=""), header=TRUE)

      strDir<-getStrengthAndDir(tripAve, tCIT[i, 2], tCIT[i, 3])

      tStrTripImp[i]<-strDir[1]
      tDirTripImp[i]<-strDir[2]
}

###
##do b cells first, triplets Imp
bStrTripImp2<-rep(0, length(bCIT[,1]))
bDirTripImp2<-rep(0, length(bCIT[,1]))

if(FALSE)
{
for(i in 1:length(bCIT[,1]))
{
      fileNum<-getFileNumber("b", bCIT[i, 2], bCIT[i, 3])

      tripAve<-read.table(paste("triplets-imp2/bcell-",dataset,"-",fileNum,"-ave-imp.dat",sep=""), header=TRUE)

      strDir<-getStrengthAndDir(tripAve, bCIT[i, 2], bCIT[i, 3])

      bStrTripImp2[i]<-strDir[1]
      bDirTripImp2[i]<-strDir[2]
}
}

##do t cells, triplets Imp
tStrTripImp2<-rep(0, length(tCIT[,1]))
tDirTripImp2<-rep(0, length(tCIT[,1]))

if(FALSE)
{
for(i in 1:length(tCIT[,1]))
{
      fileNum<-getFileNumber("t", tCIT[i, 2], tCIT[i, 3])

      tripAve<-read.table(paste("triplets-imp2/tcell-",dataset,"-",fileNum,"-ave-imp.dat",sep=""), header=TRUE)

      strDir<-getStrengthAndDir(tripAve, tCIT[i, 2], tCIT[i, 3])

      tStrTripImp2[i]<-strDir[1]
      tDirTripImp2[i]<-strDir[2]
}
}


##do b cells first, triplets Imp RT - random training, now the default
bStrTripImpRT<-rep(0, length(bCIT[,1]))
bDirTripImpRT<-rep(0, length(bCIT[,1]))

for(i in 1:length(bCIT[,1]))
{
      fileNum<-getFileNumber("b", bCIT[i, 2], bCIT[i, 3])

      tripAve<-read.table(paste("triplets-impRT/bcell-",dataset,"-",fileNum,"-ave-impRT.dat",sep=""), header=TRUE)

      strDir<-getStrengthAndDir(tripAve, bCIT[i, 2], bCIT[i, 3])

      bStrTripImpRT[i]<-strDir[1]
      bDirTripImpRT[i]<-strDir[2]
}

##do t cells, triplets Imp
tStrTripImpRT<-rep(0, length(tCIT[,1]))
tDirTripImpRT<-rep(0, length(tCIT[,1]))

for(i in 1:length(tCIT[,1]))
{
      fileNum<-getFileNumber("t", tCIT[i, 2], tCIT[i, 3])

      tripAve<-read.table(paste("triplets-impRT/tcell-",dataset,"-",fileNum,"-ave-impRT.dat",sep=""), header=TRUE)

      strDir<-getStrengthAndDir(tripAve, tCIT[i, 2], tCIT[i, 3])

      tStrTripImpRT[i]<-strDir[1]
      tDirTripImpRT[i]<-strDir[2]
}

##do all data imputation


allVarsNoImp<-read.table(paste("all-variables-no-imp/allVarsNoImp-",dataset,"-ave.dat",sep=""), header=TRUE)

##do b cells first, triplets no Imp
bStrAllNoImp<-rep(0, length(bCIT[,1]))
bDirAllNoImp<-rep(0, length(bCIT[,1]))

for(i in 1:length(bCIT[,1]))
{
      fileNum<-getFileNumber("b", bCIT[i, 2], bCIT[i, 3])

      strDir<-getStrengthAndDir(allVarsNoImp, bCIT[i, 2], bCIT[i, 3], "b_")

      bStrAllNoImp[i]<-strDir[1]
      bDirAllNoImp[i]<-strDir[2]
}

##do t cells first, triplets no Imp
tStrAllNoImp<-rep(0, length(tCIT[,1]))
tDirAllNoImp<-rep(0, length(tCIT[,1]))

for(i in 1:length(tCIT[,1]))
{
      fileNum<-getFileNumber("t", tCIT[i, 2], tCIT[i, 3])

      strDir<-getStrengthAndDir(allVarsNoImp, tCIT[i, 2], tCIT[i, 3], "t_")

      tStrAllNoImp[i]<-strDir[1]
      tDirAllNoImp[i]<-strDir[2]
}

allVarsImp<-read.table(paste("all-variables-imp/allVarsImp-",dataset,"-imp-ave.dat",sep=""), header=TRUE)

##do b cells first, all Imp
bStrAllImp<-rep(0, length(bCIT[,1]))
bDirAllImp<-rep(0, length(bCIT[,1]))

for(i in 1:length(bCIT[,1]))
{
      fileNum<-getFileNumber("b", bCIT[i, 2], bCIT[i, 3])

      strDir<-getStrengthAndDir(allVarsImp, bCIT[i, 2], bCIT[i, 3], "b_")

      bStrAllImp[i]<-strDir[1]
      bDirAllImp[i]<-strDir[2]
}

##do t cells first, all Imp
tStrAllImp<-rep(0, length(tCIT[,1]))
tDirAllImp<-rep(0, length(tCIT[,1]))

for(i in 1:length(tCIT[,1]))
{
      fileNum<-getFileNumber("t", tCIT[i, 2], tCIT[i, 3])

      strDir<-getStrengthAndDir(allVarsImp, tCIT[i, 2], tCIT[i, 3], "t_")

      tStrAllImp[i]<-strDir[1]
      tDirAllImp[i]<-strDir[2]
}

allVarsImpRT<-read.table(paste("all-variables-impRT/ave.dat",sep=""), header=TRUE)

##do b cells first, all Imp
bStrAllImpRT<-rep(0, length(bCIT[,1]))
bDirAllImpRT<-rep(0, length(bCIT[,1]))

for(i in 1:length(bCIT[,1]))
{
      fileNum<-getFileNumber("b", bCIT[i, 2], bCIT[i, 3])

      strDir<-getStrengthAndDir(allVarsImpRT, bCIT[i, 2], bCIT[i, 3], "b_")

      bStrAllImpRT[i]<-strDir[1]
      bDirAllImpRT[i]<-strDir[2]
}

##do t cells first, all Imp
tStrAllImpRT<-rep(0, length(tCIT[,1]))
tDirAllImpRT<-rep(0, length(tCIT[,1]))

for(i in 1:length(tCIT[,1]))
{
      fileNum<-getFileNumber("t", tCIT[i, 2], tCIT[i, 3])

      strDir<-getStrengthAndDir(allVarsImpRT, tCIT[i, 2], tCIT[i, 3], "t_")

      tStrAllImpRT[i]<-strDir[1]
      tDirAllImpRT[i]<-strDir[2]
}

## do all genes imp
#allVarsGenesImp<-read.table(paste("all-variables-imp-genes/allVarsImp-",dataset,"-gene-imp-ave.dat",sep=""), header=TRUE)

##do b cells first, all genes Imp
bStrAllGenesImp<-rep(0, length(bCIT[,1]))
bDirAllGenesImp<-rep(0, length(bCIT[,1]))

#for(i in 1:length(bCIT[,1]))
#{
#      fileNum<-getFileNumber("b", bCIT[i, 2], bCIT[i, 3])
#
#      strDir<-getStrengthAndDir(allVarsGenesImp, bCIT[i, 2], bCIT[i, 3], "b_")

#      bStrAllGenesImp[i]<-strDir[1]
#      bDirAllGenesImp[i]<-strDir[2]
#}

##do t cells, all genes Imp
tStrAllGenesImp<-rep(0, length(tCIT[,1]))
tDirAllGenesImp<-rep(0, length(tCIT[,1]))

#for(i in 1:length(tCIT[,1]))
#{
#      fileNum<-getFileNumber("t", tCIT[i, 2], tCIT[i, 3])

#      strDir<-getStrengthAndDir(allVarsGenesImp, tCIT[i, 2], tCIT[i, 3], "t_")

#      tStrAllGenesImp[i]<-strDir[1]
#      tDirAllGenesImp[i]<-strDir[2]
#}

##do final table for b cells

bCellAllRes<-cbind(bCIT, bCITpack[,5:length(bCITpack[1,])], bStrTripNoImp, bDirTripNoImp, bStrTripImp, bDirTripImp, bStrAllNoImp, bDirAllNoImp, bStrAllImp, bDirAllImp, bStrAllGenesImp, bDirAllGenesImp, bStrTripImp2, bDirTripImp2, bStrTripImpRT, bDirTripImpRT, bStrAllImpRT, bDirAllImpRT)

dim(bCellAllRes)
#head(bCellAllRes)
colnames(bCellAllRes)<-c("snp", "cpg", "expr", "gene", "pval1", "pval2", "call", "p_cit", "p_TassocL", "p_TassocGgvnL", "p_GassocLgvnT", "p_LindTgvnG", "strTripNoImp", "dirTripNoImp", "strTripImp", "dirTripImp", "strAllNoImp", "dirAllNoImp", "strAllImp", "dirAllImp", "strAllGenesImp", "dirAllGenesImp", "strTripImp2", "dirTripImp2", "strTripImpRT", "dirTripImpRT", "strAllImpRT", "dirAllImpRT")
head(bCellAllRes)

tCellAllRes<-cbind(tCIT, tCITpack[,5:length(tCITpack[1,])], tStrTripNoImp, tDirTripNoImp, tStrTripImp, tDirTripImp, tStrAllNoImp, tDirAllNoImp, tStrAllImp, tDirAllImp, tStrAllGenesImp, tDirAllGenesImp, tStrTripImp2, tDirTripImp2, tStrTripImpRT, tDirTripImpRT, tStrAllImpRT, tDirAllImpRT)

dim(tCellAllRes)
#head(tCellAllRes)
colnames(tCellAllRes)<-c("snp", "cpg", "expr", "gene", "pval1", "pval2", "call", "p_cit", "p_TassocL", "p_TassocGgvnL", "p_GassocLgvnT", "p_LindTgvnG", "strTripNoImp", "dirTripNoImp", "strTripImp", "dirTripImp", "strAllNoImp", "dirAllNoImp", "strAllImp", "dirAllImp", "strAllGenesImp", "dirAllGenesImp", "strTripImp2", "dirTripImp2", "strTripImpRT", "dirTripImpRT", "strAllImpRT", "dirAllImpRT")

head(tCellAllRes)

write.table(bCellAllRes, "summary/bcellAllRes2.dat", quote=FALSE, row.names=FALSE, col.names=TRUE)

write.table(tCellAllRes, "summary/tcellAllRes2.dat", quote=FALSE, row.names=FALSE, col.names=TRUE)


