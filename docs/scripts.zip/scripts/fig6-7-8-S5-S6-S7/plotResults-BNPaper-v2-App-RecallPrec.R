#do plot comparing CIT 

home<-1    # 0 = at work, 1 = at home, 2 = linux
png<-2



analNum<-"" # "" = 0 percent to impute (-impute-network-data-min-non-missing-edges 0); 2 = 50 percent to impute (-impute-network-data-min-non-missing-edges 50)

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path0<-"/home/nrajh/code/bayesnetty/AlexClarkData/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path0<-"K:/code/bayesnetty/AlexClarkData/"
} else {
 path0<-"C:/Users/richa/work/code/bayesnetty/AlexClarkData/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

doDots<-FALSE #TRUE

plotNo<-0

#dataset<-"AC3" #"AC2" #2" #"SV3"


cex=3
lwd=3
cex.axis=3
cex.lab=3
cex.main=3
#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1)  + c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(4,1.5,0)


cexleg<-3


if(png==0)
{
 dev.new(width=10, height=5)
 par(mfrow=c(3,2), par(mar=mar, mgp=mgp))
} else if(png==2) {
 postscript(paste(figpath,"fig-app-recall-prec",analNum,"-v2.eps",sep=""), width=24, height=24, bg="white", horizontal=FALSE, paper="special", onefile=FALSE)#, fonts=c("serif", "Palatino") )
 par(mfrow=c(3,2), par(mar=mar, mgp=mgp))
} else if(png==1) {
 png(paste(figpath,"fig-app-recall-prec",analNum,"-v2.png",sep=""), width = 800, height = 800, units = "px", pointsize = 12, bg = "white")
 par(mfrow=c(3,2), par(mar=mar, mgp=mgp)) #par(mfrow=c(2,2), mar=c(5.1, 5.1, 4.1, 2.1)) else par(mfrow=c(2,2), par(mar=mar, mgp=mgp)) #, mar=c(2.0, 2.0, 5.0, 2.0))
}


#imps<-c(0,1,3,5,6)
imps<-c(6,2,1,0,5)
simNo<-1

for(dataset0 in c( "SIM50", "SIM51", "SIM52")) #c( "SIM20", "SIM21", "SIM22"))
{

dataset<-dataset0
datasetFULL<-dataset0


path<-paste(path0,"analyses/results/results-",dataset,"/", sep="")
setwd(path)


##edges and nodes for the true simulation network
if(dataset=="SIM1" || dataset=="SIM2")
{
 edges<-read.table(paste0(path0,"analyses/results/results-AC/all-variables-imp-genes/allVariables-AC-genesImp-bestfit2-edges.dat"), header=TRUE, stringsAsFactors=FALSE)
 nodes<-read.table(paste0(path0,"analyses/results/results-AC/all-variables-imp-genes/allVariables-AC-genesImp-bestfit2-nodes.dat"), header=TRUE, stringsAsFactors=FALSE)
} else if(dataset=="SIM3") {
 edges<-read.table(paste0(path0,"analyses/results/results-AC2/all-variables-imp/allVars-AC2-imp-bestFitNet-edges.dat"), header=TRUE, stringsAsFactors=FALSE)
 nodes<-read.table(paste0(path0,"analyses/results/results-AC2/all-variables-imp/allVars-AC2-imp-bestFitNet-nodes.dat"), header=TRUE, stringsAsFactors=FALSE)
} else if(dataset=="SIM20" || dataset=="SIM21" || dataset=="SIM22" || dataset=="SIM23" || dataset=="SIM50" || dataset=="SIM51" || dataset=="SIM52" || dataset=="SIM53") {
 edges<-read.table(paste0(path0,"analyses/results1/results-AC3/all-variables-imp/allVars-AC3-imp-bestFitNet-edges.dat"), header=TRUE, stringsAsFactors=FALSE)
 nodes<-read.table(paste0(path0,"analyses/results1/results-AC3/all-variables-imp/allVars-AC3-imp-bestFitNet-nodes.dat"), header=TRUE, stringsAsFactors=FALSE)
}


#imp<-0 # 0 = no imp, 1 = imp all variables, 2 = random training (impRT), 3 = imp all variables using genes imp, 4 = 50% include threshold imputation; 5 = random imp; 6 = full data, 



allResults<-NULL
allResultsBF<-NULL
allResultsThres<-NULL
allResultsThresGraph<-NULL

for(imp in imps)
{

if(imp==0)
{
  stub<-paste("allVarsNoImp-",dataset,sep="")
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-no-imp",sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset,"-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 } else if(imp==1) {
  stub<-paste("allVarsImp-",dataset,"-imp",sep="")
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-imp",analNum,sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset,"-imp-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-imp-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 } else if(imp==3) {
  stub<-paste("allVarsImp-",dataset,"-gene-imp",sep="")
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-imp-genes",sep=""))

  edges.bestFit<-read.table(paste("allVariables-",dataset,"-genesImp-bestfit-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVariables-",dataset,"-genesImp-bestfit-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 }  else if(imp==6) {
  dataset0<-paste(datasetFULL,"-FULL",sep="")
  #stub<-paste("allVarsImp-",dataset0,"-gene-imp",sep="")

  #setwd(paste("K:/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset0,"/all-variables-imp-genes",sep=""))

  #edges.bestFit<-read.table(paste("allVariables-",dataset0,"-genesImp-bestfit-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  #nodes.bestFit<-read.table(paste("allVariables-",dataset0,"-genesImp-bestfit-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

  stub<-paste("allVarsNoImp-",dataset0,sep="")
  setwd(paste(path0,"analyses/results/results-",dataset0,"/all-variables-no-imp",sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset0,"-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset0,"-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

}  else if(imp==4) {
  stub<-paste("allVarsImp-",dataset,"-imp",sep="")
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-imp2",sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset,"-imp-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-imp-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 } else if(imp==5) {
  #stub<-paste("allVarsRanImp-",dataset,"-rand-imp",sep="")
  stub<-paste("allVars-",dataset,"-rand-imp",sep="") ##from rocket
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-rand-imp",sep=""))
 
  edges.bestFit<-read.table(paste("allVars-",dataset,"-rand-imp-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-rand-imp-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 }  else if(imp==2) {
  stub<-paste("allVarsImp-",dataset,"-impRT",sep="") 
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-impRT",analNum,sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset,"-impRT-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-impRT-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

} 

#threshold, an arc must be greater than the threshold to be plotted
threshold<-read.table(paste(stub,"-ave-threshold.dat",sep=""), header=FALSE)[1,1]


#load average network graph
aveGraph<-read.table(paste(stub,"-ave.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

#print(paste(stub, dim(aveGraph)))

print(paste(stub, dim(aveGraph[aveGraph$strength > threshold,])))

#dim(aveGraph)
#dim(aveGraph[aveGraph$strength > threshold,])
#par(mfrow=c(1,2))
#hist(aveGraph$strength)

getRowNum<-function(num, nodes0)
{
  which(num==nodes0$id)
}

calcNoEdges<-function(thres=0, doBestFit=0)
{

  if(doBestFit==0) aveGraphTh<-aveGraph[aveGraph$strength > thres,]

  if(thres==0 || nrow(aveGraphTh)!=0)
  {
   correctEdges<-0
   wrongDirectionEdges<-0
   incorrectEdges<-0
   missingEdges<-0

   listEdgesCor<-paste(nodes$name[sapply(edges$from, getRowNum, nodes0=nodes)], nodes$name[sapply(edges$to, getRowNum, nodes0=nodes)])

   if(doBestFit==0)
   {
    listEdgesOther<-paste(aveGraphTh$from, aveGraphTh$to)
    listEdgesOther2<-paste(aveGraphTh$to, aveGraphTh$from)
   } else {
    from<-nodes.bestFit$name[sapply(edges.bestFit$from, getRowNum, nodes0=nodes.bestFit)]
    to<-nodes.bestFit$name[sapply(edges.bestFit$to, getRowNum, nodes0=nodes.bestFit)]
    listEdgesOther<-paste(from, to)
    listEdgesOther2<-paste(to, from)
   }

   for(i in 1:length(listEdgesOther))
   {
    if(listEdgesOther[i] %in% listEdgesCor) correctEdges<-correctEdges+1
    else if(listEdgesOther2[i] %in% listEdgesCor) wrongDirectionEdges<-wrongDirectionEdges+1
    else
    {
     incorrectEdges<-incorrectEdges+1
      #print(listEdgesOther[i])
    }
   }

   for(i in 1:length(listEdgesCor))
   {
     if(!(listEdgesCor[i] %in% listEdgesOther)) missingEdges<-missingEdges+1
   }

 } else
 {
   correctEdges<-0
   wrongDirectionEdges<-0
   incorrectEdges<-0
   missingEdges<-length(edges$from)
 }

 c(correctEdges, wrongDirectionEdges, incorrectEdges, missingEdges)
}

thresholds<-seq(0, 1, 0.001)

res<-matrix(0, nrow=length(thresholds), ncol=4)

i<-1
for(th in thresholds)
{
 res[i,]<-calcNoEdges(th)
 i<-i+1
}

colnames(res)<-c("correct", "wrongDir", "inCor", "miss")

bf<-calcNoEdges(0,1)

thr<-c(calcNoEdges(threshold), threshold)
#thrGrp<-c(calcNoEdges(thresholdGraph), thresholdGraph)

allResults[[imp+1]]<-res
allResultsBF[[imp+1]]<-bf
allResultsThres[[imp+1]]<-thr
#allResultsThresGraph[[imp+1]]<-thrGrp

} ##end imp loop


totalTrueEdges<-length(edges$from)

pchbf<-c(3,2,0,4,5,6)

#dev.new(width=10, height=5)
#dev.new(width=5, height=5)
#par(mfrow=c(1,2), c(5,5,4,2)) #mar=c(5,6,4,2))


#imp<-0 # 0 = no imp, 1 = imp all variables, 2 = random training (impRT), 3 = imp all variables using genes imp, 4 = 50% include threshold imputation; 5 = random imp; 6 = full data, 

plotNo<-plotNo+1
cols<-c("black", "magenta", "red", "blue", "magenta", "orange", "green")
plot(2,2, ylim=c(0,1), xlim=c(0,1), ylab="precision", xlab="recall", main=paste0("(",letters[plotNo],") Simulation ",simNo,"\nPrecision-Recall - Directed Edges"), cex.main=cex.main, lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab=cex.lab)
for(imp in imps)
{
 correct<-allResults[[imp+1]][,1]
 wrongDir<-allResults[[imp+1]][,2]
 inCor<-allResults[[imp+1]][,3]
 bf<-allResultsBF[[imp+1]]
 thr<-allResultsThres[[imp+1]]
 #thrGrp<-allResultsThresGraph[[imp+1]]
 
 points(correct/totalTrueEdges, correct/(correct + wrongDir + inCor),  type="l", col=cols[imp+1], lwd=lwd)
 #points(bf[1]/totalTrueEdges, bf[1]/(bf[1] + bf[2] + bf[3]), pch=pchbf[imp+1], col=cols[imp+1])
 if(doDots)
 {
   theDots<-c(0.1,0.3,0.5,0.7,0.9)*1000 + 1 
   points(correct[theDots]/totalTrueEdges, correct[theDots]/(correct[theDots] + wrongDir[theDots] + inCor[theDots]), pch=19, col=cols[imp+1], cex=cex, lwd=lwd)
 } else {
   points(thr[1]/totalTrueEdges, thr[1]/(thr[1] + thr[2] + thr[3]), pch=19, col=cols[imp+1], cex=cex, lwd=lwd)
   
    impStr<-c("No imputation", "Imputation", "Imputation Ran", "Gene Imputation", "50 percent thres", "Random", "Full data")[imp+1]
   print(paste(impStr,"directed, recall-prec:",thr[1]/totalTrueEdges, thr[1]/(thr[1] + thr[2] + thr[3])))
 }
 
 #if(imp==1) points(thrGrp[1]/totalTrueEdges, thrGrp[1]/(thrGrp[1] + thrGrp[2] + thrGrp[3]), pch=19, cex=3, col=cols[imp+1])

 
}

#imp<-0 # 0 = no imp, 1 = imp all variables, 2 = imp all variables using genes imp, 3 = full data, 4 = 50% include threshold imputation; 5 = random imp; 6 = random training (impRT)


legend("bottomleft", legend=c("Reduced", "Imputed CT", "Imputed", "Gene Imputation", "50 percent thres", "Random", "Full")[imps+1], col=cols[imps+1], lty=1, pch=19, cex=cexleg, lwd=lwd)#pchbf)

plotNo<-plotNo+1
#dev.new(width=5, height=5)
plot(2,2, ylim=c(0,1), xlim=c(0,1), ylab="precision", xlab="recall", main=paste0("(",letters[plotNo],") Simulation ",simNo,"\nPrecision-Recall - Undirected Edges"), cex.main=cex.main, lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab=cex.lab)
for(imp in imps)
{
 correct<-allResults[[imp+1]][,1]
 wrongDir<-allResults[[imp+1]][,2]
 inCor<-allResults[[imp+1]][,3]
 bf<-allResultsBF[[imp+1]]
 thr<-allResultsThres[[imp+1]]
 thrGrp<-allResultsThresGraph[[imp+1]]

 points((correct+ wrongDir)/totalTrueEdges, (correct+ wrongDir)/(correct + wrongDir + inCor), col=cols[imp+1], type="l", lwd=lwd)
 #points((bf[1]+ bf[2])/totalTrueEdges, (bf[1]+bf[2])/(bf[1] + bf[2] + bf[3]), pch=pchbf[imp+1], col=cols[imp+1])
 #if(imp==1) points((thrGrp[1]+thrGrp[2])/totalTrueEdges, (thrGrp[1]+thrGrp[2])/(thrGrp[1] + thrGrp[2] + thrGrp[3]), pch=19, cex=3, col=cols[imp+1])
 if(doDots)
 {
   theDots<-c(0.1,0.3,0.5,0.7,0.9)*1000 + 1 
   points((correct[theDots]+ wrongDir[theDots])/totalTrueEdges, (correct[theDots]+ wrongDir[theDots])/(correct[theDots] + wrongDir[theDots] + inCor[theDots]), pch=19, col=cols[imp+1], cex=cex, lwd=lwd)
 } else {
   points((thr[1]+ thr[2])/totalTrueEdges, (thr[1]+ thr[2])/(thr[1] + thr[2] + thr[3]), pch=19, col=cols[imp+1], cex=cex, lwd=lwd)
   
    impStr<-c("No imputation", "Imputation", "Imputation Ran", "Gene Imputation", "50 percent thres", "Random", "Full data")[imp+1]
   print(paste(impStr,"directed, recall-prec:",(thr[1]+ thr[2])/totalTrueEdges, (thr[1]+ thr[2])/(thr[1] + thr[2] + thr[3])))
 }
}


legend("bottomleft", legend=c("Reduced", "Imputed CT", "Imputed", "Gene Imputation", "50 percent thres", "Random", "Full")[imps+1], col=cols[imps+1], lty=1, pch=19, cex=cexleg, lwd=lwd)#pchbf)








simNo<-simNo+1

} ##end of loop thro' datasets


if(png>0) dev.off()

##############################

#listEdgesCor<-paste(nodes$name[sapply(edges$from, getRowNum, nodes0=nodes)], nodes$name[sapply(edges$to, getRowNum, nodes0=nodes)])

edgesTh<-edges

nodesFrom<-nodes$name[sapply(edgesTh$from, getRowNum, nodes0=nodes)]
nodesTo<-nodes$name[sapply(edgesTh$to, getRowNum, nodes0=nodes)]

#b cell, meth to exp 
sum(substr(nodesFrom,1,3)== "b_c" & substr(nodesTo,1,3) == "b_I")

#t cell, meth to exp
sum(substr(nodesFrom,1,3)== "t_c" & substr(nodesTo,1,3) == "t_I")

#b cell, meth to t exp 
sum(substr(nodesFrom,1,3)== "b_c" & substr(nodesTo,1,3) == "t_I")

#t cell, meth to b exp
sum(substr(nodesFrom,1,3)== "t_c" & substr(nodesTo,1,3) == "b_I")

###############

#b cell, meth to exp 
sum(substr(nodesFrom,1,3)== "b_I" & substr(nodesTo,1,3) == "b_c")

#t cell, meth to exp
sum(substr(nodesFrom,1,3)== "t_I" & substr(nodesTo,1,3) == "t_c")

#b cell, meth to t exp 
sum(substr(nodesFrom,1,3)== "b_I" & substr(nodesTo,1,3) == "t_c")

#t cell, meth to b exp
sum(substr(nodesFrom,1,3)== "t_I" & substr(nodesTo,1,3) == "b_c")

#####################
#b cell, meth to exp 
sum(substr(nodesFrom,1,3)== "b_I" & substr(nodesTo,1,3) == "b_I")

#t cell, meth to exp
sum(substr(nodesFrom,1,3)== "t_I" & substr(nodesTo,1,3) == "t_I")

#b cell, meth to t exp 
sum(substr(nodesFrom,1,3)== "b_c" & substr(nodesTo,1,3) == "b_c")

#t cell, meth to b exp
sum(substr(nodesFrom,1,3)== "t_c" & substr(nodesTo,1,3) == "t_c")

