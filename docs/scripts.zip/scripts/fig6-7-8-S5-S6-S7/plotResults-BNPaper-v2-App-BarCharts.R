#do plot comparing CIT 

home<-1    # 0 = at work, 1 = at home, 2 = linux
png<-2



if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path0<-"/home/nrajh/code/bayesnetty/AlexClarkData/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path0<-"K:/code/bayesnetty/AlexClarkData/"
} else {
 path0<-"C:/Users/richa/work/code/bayesnetty/AlexClarkData/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}

doDots<-FALSE #TRUE

plotNo<-0

#dataset<-"AC3" #"AC2" #2" #"SV3"

bfStr<-"" #"BF" ## "" = ave other do best fit "BF"

cex=3
lwd=3
cex.axis=3
cex.lab=3
cex.main=3
#bottom, left, top, and right
mar=c(5.1, 4.1, 4.1, 2.1)  + c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
mgp=c(3,1,0)  + c(4,1.5,0)


cexleg<-3


if(png==0)
{
 dev.new(width=10, height=5)
 par(mfrow=c(3,3), par(mar=mar, mgp=mgp))
} else if(png==2) {
 postscript(paste(figpath,"fig-app-barcharts",bfStr,"-v2.eps",sep=""), width=24, height=24, bg="white", horizontal=FALSE, paper="special", onefile=FALSE)#, fonts=c("serif", "Palatino") )
 par(mfrow=c(3,3), par(mar=mar, mgp=mgp))
} else if(png==1) {
 png(paste(figpath,"fig-app-barcharts",bfStr,"-v2.png",sep=""), width = 800, height = 800, units = "px", pointsize = 12, bg = "white")
 par(mfrow=c(3,3), par(mar=mar, mgp=mgp)) #par(mfrow=c(2,2), mar=c(5.1, 5.1, 4.1, 2.1)) else par(mfrow=c(2,2), par(mar=mar, mgp=mgp)) #, mar=c(2.0, 2.0, 5.0, 2.0))
}



imps<-c(0,2,1,5,6) #c(0,1,3,5)
simNo<-1

for(dataset0 in c( "SIM50", "SIM51", "SIM52")) #c( "SIM20", "SIM21", "SIM22"))
{

dataset<-dataset0
datasetFULL<-dataset0


path<-paste(path0,"analyses/results/results-",dataset,"/", sep="")
setwd(path)


##edges and nodes for the true simulation network
if(dataset=="SIM1" || dataset=="SIM2")
{
 edges<-read.table(paste0(path0,"analyses/results/results-AC/all-variables-imp-genes/allVariables-AC-genesImp-bestfit2-edges.dat"), header=TRUE, stringsAsFactors=FALSE)
 nodes<-read.table(paste0(path0,"analyses/results/results-AC/all-variables-imp-genes/allVariables-AC-genesImp-bestfit2-nodes.dat"), header=TRUE, stringsAsFactors=FALSE)
} else if(dataset=="SIM3") {
 edges<-read.table(paste0(path0,"analyses/results/results-AC2/all-variables-imp/allVars-AC2-imp-bestFitNet-edges.dat"), header=TRUE, stringsAsFactors=FALSE)
 nodes<-read.table(paste0(path0,"analyses/results/results-AC2/all-variables-imp/allVars-AC2-imp-bestFitNet-nodes.dat"), header=TRUE, stringsAsFactors=FALSE)
} else if(dataset=="SIM20" || dataset=="SIM21" || dataset=="SIM22" || dataset=="SIM23" || dataset=="SIM50" || dataset=="SIM51" || dataset=="SIM52" || dataset=="SIM53") {
 #simulation model at "results1" but results in "results"
 edges<-read.table(paste0(path0,"analyses/results1/results-AC3/all-variables-imp/allVars-AC3-imp-bestFitNet-edges.dat"), header=TRUE, stringsAsFactors=FALSE)
 nodes<-read.table(paste0(path0,"analyses/results1/results-AC3/all-variables-imp/allVars-AC3-imp-bestFitNet-nodes.dat"), header=TRUE, stringsAsFactors=FALSE)
}


#imp<-0 # 0 = no imp, 1 = imp all variables, 2 = random training (impRT), 3 = imp all variables using genes imp, 4 = 50% include threshold imputation; 5 = random imp; 6 = full data, 


allResults<-NULL
allResultsBF<-NULL
allResultsThres<-NULL
allResultsThresGraph<-NULL

analNum<-""

for(imp in imps)
{

if(imp==0)
{
  stub<-paste("allVarsNoImp-",dataset,sep="")
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-no-imp",sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset,"-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 } else if(imp==1) {
  stub<-paste("allVarsImp-",dataset,"-imp",sep="")
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-imp",analNum,sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset,"-imp-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-imp-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 } else if(imp==3) {
  stub<-paste("allVarsImp-",dataset,"-gene-imp",sep="")
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-imp-genes",sep=""))

  edges.bestFit<-read.table(paste("allVariables-",dataset,"-genesImp-bestfit-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVariables-",dataset,"-genesImp-bestfit-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 }  else if(imp==6) {
  dataset0<-paste(datasetFULL,"-FULL",sep="")
  #stub<-paste("allVarsImp-",dataset0,"-gene-imp",sep="")

  #setwd(paste("K:/code/bayesnetty/AlexClarkData/analyses/results/results-",dataset0,"/all-variables-imp-genes",sep=""))

  #edges.bestFit<-read.table(paste("allVariables-",dataset0,"-genesImp-bestfit-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  #nodes.bestFit<-read.table(paste("allVariables-",dataset0,"-genesImp-bestfit-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

  stub<-paste("allVarsNoImp-",dataset0,sep="")
  setwd(paste(path0,"analyses/results/results-",dataset0,"/all-variables-no-imp",sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset0,"-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset0,"-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

}  else if(imp==4) {
  stub<-paste("allVarsImp-",dataset,"-imp",sep="")
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-imp2",sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset,"-imp-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-imp-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 } else if(imp==5) {
  #stub<-paste("allVarsRanImp-",dataset,"-rand-imp",sep="")
  stub<-paste("allVars-",dataset,"-rand-imp",sep="") ##from rocket
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-rand-imp",sep=""))
 
  edges.bestFit<-read.table(paste("allVars-",dataset,"-rand-imp-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-rand-imp-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

 }  else if(imp==2) {
  stub<-paste("allVarsImp-",dataset,"-impRT",sep="") 
  setwd(paste(path0,"analyses/results/results-",dataset,"/all-variables-impRT",analNum,sep=""))

  edges.bestFit<-read.table(paste("allVars-",dataset,"-impRT-bestFitNet-edges.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)
  nodes.bestFit<-read.table(paste("allVars-",dataset,"-impRT-bestFitNet-nodes.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

} 

#threshold, an arc must be greater than the threshold to be plotted
threshold<-read.table(paste(stub,"-ave-threshold.dat",sep=""), header=FALSE)[1,1]


#load average network graph
aveGraph<-read.table(paste(stub,"-ave.dat",sep=""), header=TRUE, stringsAsFactors=FALSE)

#dim(aveGraph)
#dim(aveGraph[aveGraph$strength > threshold,])
#par(mfrow=c(1,2))
#hist(aveGraph$strength)

getRowNum<-function(num, nodes0)
{
  which(num==nodes0$id)
}

calcNoEdges<-function(thres=0, doBestFit=0)
{

  if(doBestFit==0) aveGraphTh<-aveGraph[aveGraph$strength > thres,]

  if(thres==0 || nrow(aveGraphTh)!=0)
  {
   correctEdges<-0
   wrongDirectionEdges<-0
   incorrectEdges<-0
   missingEdges<-0

   listEdgesCor<-paste(nodes$name[sapply(edges$from, getRowNum, nodes0=nodes)], nodes$name[sapply(edges$to, getRowNum, nodes0=nodes)])

   if(doBestFit==0)
   {
    listEdgesOther<-paste(aveGraphTh$from, aveGraphTh$to)
    listEdgesOther2<-paste(aveGraphTh$to, aveGraphTh$from)
   } else {
    from<-nodes.bestFit$name[sapply(edges.bestFit$from, getRowNum, nodes0=nodes.bestFit)]
    to<-nodes.bestFit$name[sapply(edges.bestFit$to, getRowNum, nodes0=nodes.bestFit)]
    listEdgesOther<-paste(from, to)
    listEdgesOther2<-paste(to, from)
   }

   for(i in 1:length(listEdgesOther))
   {
    if(listEdgesOther[i] %in% listEdgesCor) correctEdges<-correctEdges+1
    else if(listEdgesOther2[i] %in% listEdgesCor) wrongDirectionEdges<-wrongDirectionEdges+1
    else
    {
     incorrectEdges<-incorrectEdges+1
      #print(listEdgesOther[i])
    }
   }

   for(i in 1:length(listEdgesCor))
   {
     #if(!(listEdgesCor[i] %in% listEdgesOther)) missingEdges<-missingEdges+1
     #unordered  
   }

    #missing in any direction
    missingEdges<-length(edges$from)-correctEdges-wrongDirectionEdges
 } else
 {
   correctEdges<-0
   wrongDirectionEdges<-0
   incorrectEdges<-0
   missingEdges<-length(edges$from)
 }

 c(correctEdges, wrongDirectionEdges, incorrectEdges, missingEdges)
}

thresholds<-seq(0, 1, 0.001)

res<-matrix(0, nrow=length(thresholds), ncol=4)

i<-1
for(th in thresholds)
{
 res[i,]<-calcNoEdges(th)
 i<-i+1
}

colnames(res)<-c("correct", "wrongDir", "inCor", "miss")

bf<-calcNoEdges(0,1)

thr<-c(calcNoEdges(threshold), threshold)
#thrGrp<-c(calcNoEdges(thresholdGraph), thresholdGraph)

allResults[[imp+1]]<-res
allResultsBF[[imp+1]]<-bf
allResultsThres[[imp+1]]<-thr
#allResultsThresGraph[[imp+1]]<-thrGrp

} ##end imp loop



#cols<-c("black", "red", "blue", "green", "magenta", "orange")
cols<-c("black", "magenta", "red", "blue", "magenta", "orange", "green")
#function for plots
doBarChart<-function(bars, ...)
{
 barplot(bars, names=c("No Imp", "Imp", "Imp CT", "Rnd", "Full"), col=cols[imps+1], cex.main=cex.main, lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab=cex.lab, ...)
 abline(h=dim(edges)[1], lty=2)
}

correct<-rep(0,5)
correctundir<-rep(0,5)
incorrectundir<-rep(0,5)
missingundir<-rep(0,5)

barNo<-1
for(imp in imps)
{
 if(bfStr != "")
 {
  correct[barNo]<-allResultsBF[[imp+1]][1]
  correctundir[barNo]<-allResultsBF[[imp+1]][1]+allResultsThres[[imp+1]][2]
  incorrectundir[barNo]<-allResultsBF[[imp+1]][3]
  missingundir[barNo]<-allResultsBF[[imp+1]][4]
 
 } else {
  correct[barNo]<-allResultsThres[[imp+1]][1]
  correctundir[barNo]<-allResultsThres[[imp+1]][1]+allResultsThres[[imp+1]][2]
  incorrectundir[barNo]<-allResultsThres[[imp+1]][3]
  missingundir[barNo]<-allResultsThres[[imp+1]][4]
 }
 
 barNo<-barNo+1
}

ymax<-max(correct, correctundir, incorrectundir, missingundir,300)
#ymax<-500
plotNo<-plotNo+1
doBarChart(correct, ylim=c(0, ymax), main=paste0("(",letters[plotNo],") Simulation ",simNo,"\nCorrect Directed Edges"))
plotNo<-plotNo+1
doBarChart(correctundir, ylim=c(0, ymax), main=paste0("(",letters[plotNo],") Simulation ",simNo,"\nCorrect Undirected Edges"))
plotNo<-plotNo+1
doBarChart(incorrectundir, ylim=c(0, ymax), main=paste0("(",letters[plotNo],") Simulation ",simNo,"\nIncorrect Undirected Edges"))
#plotNo<-plotNo+1
#doBarChart(missingundir, ylim=c(0, ymax), main=paste0("(",letters[plotNo],") Simulation ",simNo,"\nUndirected, Missing Edges"))



simNo<-simNo+1

} ##end of loop thro' datasets

if(png>0) dev.off()






