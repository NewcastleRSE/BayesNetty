##

home<-1

if(home == 2)
{
 figpath<-"/home/nrajh/work-other/tex/bayesNet/"
 path<-"/home/nrajh/code/bayesnetty/missingData/sims/"
} else if(home == 0) {
 figpath<-"K:/work-other/tex/bayesNet/"
 path<-"K:/code/bayesnetty/missingData/sims/"
} else {
 path<-"C:/Users/richa/work/code/bayesnetty/missingData/sims/"
 figpath<-"C:/Users/richa/work/work-other/tex/bayesNet/"
}


modType<-"" #"Dis" = discrete; "" = cts

plotAllMissing<-TRUE
useXorY<-"X"

setwd(path)

plotImpRT<-TRUE


cex=1.5#3
lwd=1.5#3
cex.axis=1.5#5
cex.lab=1.5#5
cex.main=2#5
#bottom, left, top, and right
#mar=c(5.1, 4.1, 4.1, 2.1)  #+ c(5, 6.1, 3, 0) 
#labels, tick labels, tick marks
#mgp=c(3,1,0) # + c(4,1.5,0)

cexleg<-1.5#1.1#4
labcex<-3#1.5#3

noSims<-1000
noMissing<-1800
if(modType=="Dis") noMissing<-1000
n<-2000



usingPlots<-c(TRUE, plotImpRT, TRUE, TRUE, TRUE, TRUE)
cols<-c("green", "red", "magenta", "red", "orange", "cyan")
pchs<-c(19, 10, 7, 1, 3, 4)
ltys<-c(1, 1, 1, 2, 1, 1)
leg=c("Full", "Imputed", "Imputed CT", "Reduced", "Random", "EM")[usingPlots]


png<-2

if(png==1)
{
cex=1.5#3
lwd=1.5#3
cex.axis=2 #1.5#5
cex.lab=2 #1.5#5
cex.main=2#5

cexleg<-1.5#1.1#4
labcex<-3#1.5#3
}


getPropBestMod<-function(imp, mod, varMiss, bet, miss, tot, noSims)
{

countBest<-0
totalCount<-0

modType0<-modType
if(imp=="RanImp") modType0<-""

for(i in 1:noSims)
{

filename<-paste("results",modType,modFile,"-",varMiss,"/res",modType0,imp,"-",bet,"-",miss,"-",tot,"-",i,".dat", sep="")

if(!file.exists(filename)) break

res<-read.table(filename, header=FALSE, stringsAsFactors=FALSE)

if(mod==2 || mod==3)
{
if(res[1,1] == "[A][B|A][C|B]" || res[1,1] == "[C][B|C][A|B]" || res[1,1] == "[B][A|B][C|B]" || res[1,1] == "[B][C|B][A|B]"
   || res[1,1] == "[a][b|a][c|b]" || res[1,1] == "[c][b|c][a|b]" || res[1,1] == "[b][a|b][c|b]" || res[1,1] == "[b][c|b][a|b]"
   || res[1,1] == "[ar][br|ar][cr|br]" || res[1,1] == "[cr][br|cr][ar|br]" || res[1,1] == "[br][ar|br][cr|br]" || res[1,1] == "[br][cr|br][ar|br]"
 ) countBest<-countBest+1
} else if(mod==1) {

 
if(res[1,1] == "[A][C][B|A:C]" || res[1,1] == "[a][c][b|a:c]" || res[1,1] == "[ar][cr][br|ar:cr]" ) countBest<-countBest+1

}

totalCount<-totalCount+1
}


countBest/totalCount
}

getPropBestModEM<-function(imp, mod, varMiss, bet, miss, tot, noSims)
{

countBest<-0
totalCount<-0

for(i in 1:noSims)
{

filename<-paste("results",modType,modFile,"-",varMiss,"/res",modType,imp,"-",bet,"-",miss,"-",tot,"-",i,".dat", sep="")

if(!file.exists(filename)) break


if(file.size(filename)>1) #check there are some edges
{

res<-read.table(filename, header=FALSE, stringsAsFactors=FALSE)

resDim<-dim(res)

##check if correct dim
if(resDim[1] == 2 && resDim[2] == 2)
{
  ##edges are ordered on "from" col then "to" col
  if(mod==2 || mod==3)
  {
     if((res[1,1]=="A" && res[1,2]=="B" && res[2,1]=="B" && res[2,2]=="C") ||
        (res[1,1]=="B" && res[1,2]=="A" && res[2,1]=="B" && res[2,2]=="C") ||
        (res[1,1]=="B" && res[1,2]=="A" && res[2,1]=="C" && res[2,2]=="B")
       ) countBest<-countBest+1
  } else {
   if(res[1,1]=="A" && res[1,2]=="B" && res[2,1]=="C" && res[2,2]=="B") countBest<-countBest+1  
  }

}

} 

totalCount<-totalCount+1
}


countBest/totalCount
}


betas<-c(0, 0.1, 0.2, 0.3, 0.4, 0.5)


if(png==1) png(paste(figpath,"fig-",modType,"Imp-3Nodes-v3.png",sep=""), width = 800, height = 800, units = "px", pointsize = 12, bg = "white")
if(png==2)
{
 if(plotAllMissing)
 {
 postscript(paste(figpath,"fig-",modType,"Imp-3Nodes",useXorY,"-v3.eps",sep=""), height=12, width=12,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") )
 } else {
   postscript(paste(figpath,"fig-",modType,"Imp-3Nodes-v3.eps",sep=""), height=12, width=12,  bg="white", horizontal=FALSE, paper="special", onefile=FALSE, fonts=c("serif", "Palatino") ) 
 }
}

noGraphs<-4

#par(mfrow=c(1,2), mar=c(2.0, 2.0, 5.0, 2.0))
if(png==1)
{
 par(mfrow=c(2,2), mar=c(5.1, 5.1, 4.1, 2.1))
} else {
 if(plotAllMissing)
 {
  par(mfrow=c(3,2))
  noGraphs<-6
 } else {
   par(mfrow=c(2,2)) 
 }
}

for(graphNo in 1:noGraphs)
{

if(graphNo%%2 == 1) model<-1 else model<-3
if(graphNo <= 2) varMiss<-"B"
else if(graphNo <= 4) varMiss<-"C"
else varMiss<-useXorY

modFile<-paste("Sub90Paper2-",model,sep="")

filename2<-paste("results",modType,modFile,"-",varMiss,"/resultsSummary",noSims,".dat",sep="")

if(file.exists(filename2))
{
  
  res<-read.table(filename2, header=FALSE, stringsAsFactors=FALSE)
  impProp<-res[1,]
  impRTProp<-res[2,]
  fullProp<-res[3,]
  missProp<-res[4,]
  rimpProp<-res[5,]
  emProp<-res[6,]

} else {

impProp<-rep(0, 6)
impRTProp<-rep(0, 6)
fullProp<-rep(0, 6)
missProp<-rep(0, 6)
rimpProp<-rep(0, 6)
emProp<-rep(0, 6)

no<-1
for(bet in betas)
{

impProp[no]<-getPropBestMod("Imp", model, varMiss, bet, noMissing, n, noSims)
impRTProp[no]<-getPropBestMod("ImpRT", model, varMiss, bet, noMissing, n, noSims)
fullProp[no]<-getPropBestMod("Full", model, varMiss, bet, noMissing, n, noSims)
missProp[no]<-getPropBestMod("Miss", model, varMiss, bet, noMissing, n, noSims)
rimpProp[no]<-getPropBestMod("RanImp", model, varMiss, bet, noMissing, n, noSims)
emProp[no]<-getPropBestModEM("EM", model, varMiss, bet, noMissing, n, noSims)

no<-no+1
}

  write.table(rbind(impProp, impRTProp, fullProp, missProp, rimpProp, emProp), filename2, quote=FALSE, row.names=FALSE, col.names=FALSE)
}  ##end look up summary of results


#dev.new(width=10, height=6)

#tit<-paste("Power for correct model - Model ",model,", ",varMiss," missing ",noMissing,"/",n, sep="")
#tit<-paste("Model ",model,", ",varMiss," missing ",noMissing,"/",n, sep="")
if(model==1 && varMiss=="B") tit<-expression((a)~A %->% B^"*" %<-% C) 
if(model==1 && varMiss=="C") tit<-expression((c)~A %->% B %<-% C^"*")
if(model==3 && varMiss=="B") tit<-expression((b)~A %->% B^"*" %->% C) 
if(model==3 && varMiss=="C") tit<-expression((d)~A %->% B %->% C^"*")
if(model==1 && varMiss=="X") tit<-expression((e)~A^"*" %->% B^"*" %<-% C^"*")
if(model==3 && varMiss=="X") tit<-expression((f)~A^"*" %->% B^"*" %->% C^"*")
if(model==1 && varMiss=="Y") tit<-expression((e)~A^"*" %->% B %<-% C^"*")
if(model==3 && varMiss=="Y") tit<-expression((f)~A^"*" %->% B %->% C^"*")

plot(betas, missProp, ylim=c(0,1), xlim=c(0,0.5), xlab=expression(beta), ylab="proportion", main=tit, type="b", col="red", pch=pchs[4], lwd=lwd, cex=cex, cex.axis=cex.axis, cex.lab= cex.lab, cex.main=cex.main, lty=2)


points(betas, fullProp, type="b", col="green", pch=pchs[1], lwd=lwd, cex=cex)

points(betas, rimpProp, type="b", col="orange", pch=pchs[5], lwd=lwd, cex=cex)

points(betas, emProp, type="b", col="cyan", pch=pchs[6], lwd=lwd, cex=cex)

if(plotImpRT) points(betas, impRTProp,  type="b", col="red", pch=pchs[2], lwd=lwd, cex=cex)

points(betas, impProp,  type="b", col="magenta", pch=pchs[3], lwd=lwd, cex=cex)


abline(h=0.5, lty=2)




#legend("topleft", lty=c(2,1,1,1), col=c("red", "red", "green", "orange"), legend=c("complete only", "imputed", "full", "randomly imputed"), bg="white", lwd=lwd, cex=cexleg)
#legend("topleft", lty=c(1,1,2,1), col=c("green", "red", "red", "orange"), legend=c("full", "imputed", "reduced", "random"), bg="white", lwd=lwd, cex=cexleg)

legend("topleft", legend=leg, pch=pchs, lwd=lwd, cex=cexleg, col=cols, lty=ltys)


} ## end drawing graphs

if(png>0) dev.off()


#legend("topleft", lty=c(2,1,1,1), col=c("red", "red", "green"), legend=c("complete data only", "imputed data", "full data"), bg="white", cex=1.2, lwd=2)

#fullProp
#impProp
#missProp
#rimpProp
