cmd_args<-commandArgs()

model<-as.numeric(cmd_args[4])
betaX<-as.numeric(cmd_args[5])
missingVar<-cmd_args[6]
noMissing<-as.numeric(cmd_args[7])
n<-as.numeric(cmd_args[8])
it<-cmd_args[9] ##iteration



if(model==1)
{
A<-rnorm(n, 10 , 1)
C<-rnorm(n, 10 , 1)
B<-rnorm(n, 10 + betaX*A + betaX*C, 1)
} else if(model==2) {
B<-rnorm(n, 10)
A<-rnorm(n, 10 + betaX*B)
C<-rnorm(n, 10 + betaX*B)
} else {
A<-rnorm(n, 10 , 1)
B<-rnorm(n, 10 + betaX*A, 1)
C<-rnorm(n, 10 + betaX*B, 1)
}



allData<-cbind(A,B,C)
colnames(allData)<-c("a", "b", "c")

write.table(allData, paste("dataFullGen",model,"-",betaX,"-",missingVar,"-",noMissing,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)



if(missingVar == "A")
{
 A[1:noMissing]<-NA
} else if(missingVar == "B") {
 B[1:noMissing]<-NA
} else if(missingVar == "C") {
 C[1:noMissing]<-NA
} else if(missingVar == "X") {
 A[1:600]<-NA
 B[601:1200]<-NA
 C[1201:1800]<-NA
} else if(missingVar == "Y") {
 A[1:900]<-NA 
 C[901:1800]<-NA
}


allData<-cbind(A,B,C)

write.table(allData, paste("dataGen",model,"-",betaX,"-",missingVar,"-",noMissing,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)

################################################

##do structural EM

library("bnlearn")


bn<-structural.em(as.data.frame(allData))

arcs<-bn$arcs[order(bn$arcs[,1],bn$arcs[,2]),]

#write.table(arcs, paste("resEM-test--",betaX,"-",noMissing,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=FALSE, quote=FALSE)


write.table(arcs, paste("resultsSub90Paper2-",model,"-",missingVar,"/resEM-",betaX,"-",noMissing,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=FALSE, quote=FALSE)


if(model==1) startBN<-model2network("[A][C][B|A:C]") else if(model==3) startBN<-model2network("[A][B|A][C|B]")

bn2<-structural.em(as.data.frame(allData), start=startBN)

arcs<-bn2$arcs[order(bn2$arcs[,1],bn2$arcs[,2]),]

write.table(arcs, paste("resultsSub90Paper2-",model,"-",missingVar,"/resEM2-",betaX,"-",noMissing,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=FALSE, quote=FALSE)

################################################

##do random imp now

if(missingVar == "A")
{
 A[1:noMissing]<-sample(A[-(1:noMissing)], noMissing, replace=TRUE)
} else if(missingVar == "B") {
 B[1:noMissing]<-sample(B[-(1:noMissing)], noMissing, replace=TRUE)
} else if(missingVar == "C") {
 C[1:noMissing]<-sample(C[-(1:noMissing)], noMissing, replace=TRUE)
} else if(missingVar == "X") {
 A[1:600]<-sample(A[-(1:600)], 600, replace=TRUE)
 B[601:1200]<-sample(B[-(601:1200)], 600, replace=TRUE)
 C[1201:1800]<-sample(C[-(1201:1800)], 600, replace=TRUE)
} else if(missingVar == "Y") {
 A[1:900]<-sample(A[-(1:900)], 900, replace=TRUE) 
 C[901:1800]<-sample(C[-(901:1800)], 900, replace=TRUE)
}



allData<-cbind(A,B,C)
colnames(allData)<-c("ar", "br", "cr")

write.table(allData, paste("dataRanImpGen",model,"-",betaX,"-",missingVar,"-",noMissing,"-",n,"-",it,".dat", sep=""), row.names=FALSE, col.names=TRUE, quote=FALSE)


